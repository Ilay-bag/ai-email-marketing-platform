# EmailAI Campaign Generator

## Overview

EmailAI is an enterprise-grade AI-powered email marketing automation platform with full ESP (Email Service Provider) compatibility. The system features comprehensive contact management, advanced segmentation, automation workflows, real-time analytics, A/B testing, and seamless integration with major email service providers including Mailchimp, Klaviyo, ActiveCampaign, ConvertKit, and SendGrid. Built with React/TypeScript frontend and Express/Node.js backend, it provides professional-grade email marketing automation with AI-powered content generation using OpenAI's GPT-4, designed for enterprise-level email marketing campaigns.

## User Preferences

Preferred communication style: Simple, everyday language.

Integration approach: Connect OpenAI first, then add other integrations (Klaviyo, Shopify, WordPress, etc.) later as needed.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS variables for theming

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: PostgreSQL-based session store using connect-pg-simple

### Project Structure
The application follows a monorepo structure with clear separation:
- `client/` - React frontend application
- `server/` - Express backend API
- `shared/` - Shared TypeScript schemas and types

## Key Components

### AI Integration
- **Provider**: OpenAI GPT-4 ("gpt-4o" model)
- **Purpose**: Generate email campaign content from user prompts
- **Service**: Located in `server/services/openai.ts`
- **Features**: Creates structured email content with subject, header, body sections, and call-to-action

### Email Service
- **Provider**: SendGrid for email delivery
- **Service**: Located in `server/services/sendgrid.ts`
- **Features**: HTML email generation, test email sending, and production email delivery

### ESP Integration Services
- **ESP Integration Service**: `server/services/esp-integration.ts` - Complete platform integration
- **Contact Management Service**: `server/services/contact-management.ts` - Advanced contact operations
- **Automation Engine**: `server/services/automation-engine.ts` - Workflow automation and execution
- **Analytics Service**: `server/services/analytics-service.ts` - Real-time performance tracking
- **Template Engine**: `server/services/template-engine.ts` - Professional template management

### Core Features
- **Contact Management**: Import/export, segmentation, tagging, engagement scoring, GDPR compliance
- **List Management**: Static lists, dynamic segments with rule-based filtering
- **Template Library**: 6 built-in professional templates, custom template creation, ESP conversion
- **Automation Workflows**: Multi-step automation with delays, conditions, webhooks, and branching
- **Real-time Analytics**: Campaign performance, contact engagement, A/B testing, conversion tracking
- **ESP Compatibility**: Native integration with major email service providers

### Database Schema
The application uses an enterprise-grade database schema with 15+ tables for comprehensive ESP functionality:

**Core Tables:**
- `users` - User account management and authentication
- `campaigns` - Enhanced campaign storage with triggers, descriptions, scheduling, and status management
- `emails` - Email templates and sequence management with ordering, delays, and template flags
- `chat_messages` - AI chat conversation history with campaign associations
- `integrations` - OAuth-based third-party service integration with token management

**ESP-Compatible Tables:**
- `contacts` - Comprehensive contact management with custom fields, tags, engagement scoring, and consent tracking
- `email_lists` - Static and dynamic list management with segmentation rules and subscriber counts
- `contact_list_memberships` - Many-to-many relationships between contacts and lists
- `email_templates` - Professional template library with categories, thumbnails, and usage tracking
- `campaign_analytics` - Detailed event tracking for opens, clicks, bounces, unsubscribes, and spam reports
- `ab_tests` - A/B testing infrastructure with variant management and statistical analysis
- `automations` - Workflow automation engine with trigger types and execution tracking
- `automation_steps` - Individual automation steps with conditional logic and branching
- `automation_executions` - Real-time execution tracking with status and metadata
- `assets` - Media asset management for images and files

### Recent Changes (July 2025)
✓ Enhanced database schema with new campaign fields (triggers, description, scheduledAt)
✓ Added email sequence support with ordering and delay settings
✓ Implemented comprehensive campaign editor with multi-step email flows
✓ Created advanced email library with template management
✓ Built enhanced chat interface with reset functionality and campaign type selection
✓ Added comprehensive filtering and search across all management interfaces
✓ Implemented OAuth-based integration system with automatic token refresh
✓ Created professional SaaS-grade user interface with shadcn/ui components
✓ Added bulk operations for campaign and email management
✓ Fixed chat interface to display HTML email previews with iframe rendering
✓ Resolved React rendering errors by properly handling object-to-string conversion
✓ Integrated tabbed navigation system removing conflicting sidebar components
✓ Added complete email preview functionality with "Open Full" HTML display
✓ Enhanced AI prompt system to generate production-ready HTML emails with examples
✓ Implemented single email vs campaign flow selection in chat interface
✓ Added Klaviyo-style campaign flow creation with multi-step email sequences
✓ Created professional Campaign Flow Editor with trigger management and email sequencing
✓ Fixed email editing to properly pass content from chat to email builder via localStorage
✓ Added proper campaign flow structure with automatic follow-up email generation
✓ Implemented separate storage and editing for individual emails vs campaign flows
✓ Enhanced server-side logic to handle both single email and campaign flow creation types
✓ Restored full sidebar navigation with comprehensive menu system including Analytics, Integrations, and Settings
✓ Enhanced email builder with proper HTML content loading from chat-generated emails
✓ Added HTML component type to drag-and-drop email builder for custom content editing
✓ Fixed email builder to properly handle content from localStorage and database with JSON structure
✓ Implemented HTML-to-component conversion for seamless chat-to-editor workflow
✓ Added proper HTML generation from email builder components for database storage

**✓ MAJOR: Enterprise ESP Compatibility Implementation (January 2025)**
✓ Expanded database schema with 15+ tables for comprehensive ESP functionality
✓ Implemented complete contact management system with custom fields, tags, and engagement scoring
✓ Added advanced email list management with static and dynamic segmentation
✓ Created comprehensive automation engine with trigger-based workflows
✓ Built real-time analytics system with campaign performance tracking
✓ Developed A/B testing infrastructure with statistical significance analysis
✓ Implemented professional template library with 6 built-in templates
✓ Added full ESP integration service supporting Mailchimp, Klaviyo, ActiveCampaign, and ConvertKit
✓ Created comprehensive contact import/export functionality with GDPR compliance
✓ Implemented advanced segmentation with rule-based filtering
✓ Added email event tracking for opens, clicks, bounces, and unsubscribes
✓ Built automation execution engine with delay, condition, and webhook steps
✓ Created comprehensive analytics dashboard with engagement metrics
✓ Implemented ESP-specific HTML conversion for each platform's requirements
✓ Added tagging system for advanced contact organization
✓ Built asset management system for email media
✓ Created complete API ecosystem with 50+ ESP-compatible endpoints

### UI Components
- **Enhanced Chat Interface**: Advanced AI conversation with campaign type selection, reset functionality, and suggested prompts
- **Campaign Editor**: Comprehensive campaign management with email sequence builder, trigger settings, and status management
- **Email Library**: Template management system with filtering, search, and categorization
- **Campaign Library**: Advanced campaign management with filtering, search, status updates, and bulk actions
- **Integration Status**: Real-time dashboard showing connected services and OAuth status

### Enterprise Features
- **Contact Management Dashboard**: Import/export contacts, advanced segmentation, engagement tracking
- **Template Library**: Professional templates with categories, cloning, and ESP-specific conversion
- **Automation Builder**: Visual workflow creator with drag-and-drop automation steps
- **Analytics Dashboard**: Real-time campaign performance, engagement metrics, and conversion tracking
- **A/B Testing Interface**: Statistical testing with confidence intervals and winner determination
- **ESP Integration Panel**: Platform-specific campaign export and synchronization

### Data Storage
- **Production**: PostgreSQL with Drizzle ORM using Neon Database
- **Development**: PostgreSQL database (switched from in-memory storage)
- **Storage Interface**: Abstracted through `IStorage` interface allowing easy switching between implementations

## Data Flow

1. **Campaign Generation**:
   - User inputs campaign prompt through chat interface
   - Frontend sends request to `/api/chat/generate`
   - Backend calls OpenAI API with structured prompt
   - AI generates email content with subject, header, body, and CTA
   - Content is saved to database and returned to frontend

2. **Contact Management**:
   - Contacts imported via CSV or API with validation and deduplication
   - Dynamic segmentation based on custom fields, tags, and engagement data
   - Real-time engagement scoring based on opens, clicks, and interactions

3. **Automation Workflows**:
   - Trigger-based automation execution with event processing
   - Multi-step workflows with delays, conditions, and branching logic
   - Real-time execution tracking with pause/resume capabilities

4. **ESP Integration**:
   - Campaign content converted to platform-specific HTML with merge tags
   - Contact synchronization with field mapping and list management
   - Real-time analytics collection across all connected platforms

5. **Analytics Processing**:
   - Event tracking for all email interactions (opens, clicks, bounces)
   - A/B testing with statistical significance calculation
   - Performance dashboards with engagement metrics and conversion tracking

## External Dependencies

### Core Services
- **OpenAI**: AI-powered campaign generation (GPT-4)
- **SendGrid**: Email delivery service
- **Neon Database**: Serverless PostgreSQL hosting

### External Integrations
The application features enterprise-grade ESP integration capabilities:

**Supported ESP Platforms:**
- **Mailchimp**: Full API integration with campaign creation, list management, and analytics
- **Klaviyo**: Complete platform integration with flows, templates, and customer data
- **ActiveCampaign**: Automation-focused integration with advanced tagging and segmentation
- **ConvertKit**: Creator-focused email marketing with broadcast and sequence support
- **SendGrid**: Transactional and marketing email delivery service

**ESP Integration Features:**
- Platform-specific HTML conversion with proper merge tags and tracking
- Automated campaign export with preserved formatting and design
- Contact synchronization with custom field mapping
- Real-time analytics and event tracking across platforms
- Template conversion maintaining ESP-specific requirements
- Unsubscribe link and compliance management per platform
- UTM parameter and click tracking preservation

**Additional Integrations:**
- **OAuth-based platforms**: Shopify, Wix, WordPress for e-commerce and content integration
- **API-based connections**: Direct API key integration for advanced platforms
- **Webhook support**: Real-time event processing and automation triggers
- **Analytics integration**: Cross-platform performance tracking and reporting

### Development Dependencies
- **Vite**: Frontend build tool with HMR
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first styling
- **Radix UI**: Accessible component primitives
- **Drizzle**: Type-safe database ORM

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public/`
- **Backend**: esbuild compiles server code to `dist/`
- **Database**: Drizzle migrations handle schema changes

### Environment Configuration
- **Database**: `DATABASE_URL` for PostgreSQL connection
- **OpenAI**: `OPENAI_API_KEY` for AI services
- **SendGrid**: `SENDGRID_API_KEY` for email delivery

**OAuth Configuration (Optional):**
- **Mailchimp**: `MAILCHIMP_CLIENT_ID`, `MAILCHIMP_CLIENT_SECRET`
- **Klaviyo**: `KLAVIYO_CLIENT_ID`, `KLAVIYO_CLIENT_SECRET`
- **Shopify**: `SHOPIFY_CLIENT_ID`, `SHOPIFY_CLIENT_SECRET`
- **Wix**: `WIX_CLIENT_ID`, `WIX_CLIENT_SECRET`
- **WordPress**: `WORDPRESS_CLIENT_ID`, `WORDPRESS_CLIENT_SECRET`

### Development Workflow
- **Local Development**: `npm run dev` starts both frontend and backend
- **Database**: `npm run db:push` applies schema changes
- **Type Safety**: `npm run check` validates TypeScript across the stack

The application is designed for easy deployment to platforms like Replit, with all necessary configuration files and environment variable support built-in.