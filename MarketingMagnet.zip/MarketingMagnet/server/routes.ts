import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { generateEmailCampaign, improveCampaignContent, generateEmailFlow } from "./services/openai";
import { sendEmail, generateEmailHTML, generateEmailText } from "./services/sendgrid";
import { insertCampaignSchema, insertEmailSchema, insertChatMessageSchema, emailContentSchema, insertFlowSchema, insertFlowNodeSchema, insertFlowEdgeSchema, insertFlowEventSchema, insertContactSchema, insertEmailListSchema, insertEmailTemplateSchema, insertAutomationSchema } from "@shared/schema";
import { oauthService } from "./services/oauth";
import { campaignExportService } from "./services/campaign-export";
import { generateKlaviyoEmail, convertKlaviyoToUnlayer } from "./services/klaviyo-email-generator";
import { convertEmailContentToComponents, convertComponentsToHTML } from "./services/email-component-converter";
import { contactManagementService } from "./services/contact-management";
import { espIntegrationService } from "./services/esp-integration";
import { automationEngine } from "./services/automation-engine";
import { analyticsService } from "./services/analytics-service";
import { templateEngine } from "./services/template-engine";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoints
  app.post("/api/chat/generate", async (req, res) => {
    try {
      const { prompt, userId, campaignType = "promo", creationType = "single", editingContext = null } = req.body;

      if (!prompt || !userId) {
        return res.status(400).json({ message: "Prompt and userId are required" });
      }

      // Handle different types of AI assistance
      if (editingContext?.type === "email_edit" && editingContext?.emailId) {
        // Editing an existing email
        const existingEmail = await storage.getEmail(editingContext.emailId);
        if (!existingEmail) {
          return res.status(404).json({ message: "Email not found" });
        }
        
        const improvedContent = await improveCampaignContent(existingEmail.json, prompt);
        const updatedEmail = await storage.updateEmail(editingContext.emailId, {
          subject: improvedContent.subject,
          html: generateEmailHTML(improvedContent),
          json: improvedContent
        });
        
        return res.json({
          content: improvedContent,
          email: updatedEmail,
          message: "Email updated successfully! Your changes have been applied."
        });
      }
      
      if (editingContext?.type === "flow_edit" && editingContext?.flowId) {
        // Editing an existing flow
        const existingFlow = await storage.getFlow(editingContext.flowId);
        if (!existingFlow) {
          return res.status(404).json({ message: "Flow not found" });
        }
        
        const improvedFlow = await generateEmailFlow(`${prompt}. Current flow: ${existingFlow.description}. Improve this flow based on the request.`);
        const updatedFlow = await storage.updateFlow(editingContext.flowId, {
          name: improvedFlow.name,
          status: 'draft'
        });
        
        return res.json({
          flow: updatedFlow,
          message: "Flow updated successfully! Your changes have been applied."
        });
      }
      
      if (creationType === "flow") {
        // Creating a new flow
        const flowData = await generateEmailFlow(prompt);
        
        const flow = await storage.createFlow({
          id: `flow_${Date.now()}`,
          userId: parseInt(userId),
          name: flowData.name || 'New Flow',
          status: 'draft'
        });
        
        return res.json({
          flow: flow,
          content: flowData,
          message: `Created new flow: ${flowData.name}. You can now edit triggers, actions, and sequences.`
        });
      }

      // Generate email campaign using OpenAI
      const emailContent = await generateEmailCampaign(prompt);

      // Convert AI-generated content to modular components
      const modularEmail = convertEmailContentToComponents(emailContent);

      let campaign = null;
      let email = null;

      if (creationType === "campaign") {
        // Create campaign flow with multiple emails
        campaign = await storage.createCampaign({
          userId: parseInt(userId),
          title: emailContent.subject,
          type: campaignType,
          status: "draft",
          triggers: [
            { event: "signup", delay: "0h" },
            { event: "follow_up", delay: "24h" },
            { event: "final_reminder", delay: "72h" }
          ]
        });

        // Generate HTML from modular components and create primary email
        const htmlContent = convertComponentsToHTML(modularEmail.components, modularEmail.globalStyles);
        email = await storage.createEmail({
          campaignId: campaign.id,
          subject: emailContent.subject,
          html: htmlContent,
          json: {
            ...emailContent,
            components: modularEmail.components,
            globalStyles: modularEmail.globalStyles
          },
          sequenceOrder: 1
        });

        // Create follow-up emails for the campaign flow
        const followUpContent = await generateEmailCampaign(`Create a follow-up email for ${emailContent.subject}. Make it build on the previous email and encourage action.`);
        const followUpHTML = generateEmailHTML(followUpContent);
        await storage.createEmail({
          campaignId: campaign.id,
          subject: followUpContent.subject,
          html: followUpHTML,
          json: followUpContent,
          sequenceOrder: 2,
          delay: "24h"
        });

        const finalContent = await generateEmailCampaign(`Create a final reminder email for ${emailContent.subject}. Make it urgent and encourage immediate action.`);
        const finalHTML = generateEmailHTML(finalContent);
        await storage.createEmail({
          campaignId: campaign.id,
          subject: finalContent.subject,
          html: finalHTML,
          json: finalContent,
          sequenceOrder: 3,
          delay: "72h"
        });
      } else {
        // Create standalone email template with modular components
        const htmlContent = convertComponentsToHTML(modularEmail.components, modularEmail.globalStyles);
        email = await storage.createEmail({
          campaignId: null, // No campaign for single emails
          subject: emailContent.subject,
          html: htmlContent,
          json: {
            ...emailContent,
            components: modularEmail.components,
            globalStyles: modularEmail.globalStyles
          },
          isTemplate: true
        });
      }

      // Save user message
      await storage.createChatMessage({
        userId: parseInt(userId),
        role: "user",
        content: prompt,
        campaignId: campaign?.id || null
      });

      // Save AI response
      await storage.createChatMessage({
        userId: parseInt(userId),
        role: "assistant",
        content: creationType === "campaign" 
          ? `I've created a complete email campaign flow for you! The campaign "${emailContent.subject}" includes multiple emails with triggers and timing. You can preview and edit each email in the flow.`
          : `I've created a standalone email template for you. The subject line is "${emailContent.subject}" and it includes an engaging header, body content, and call-to-action. You can preview and edit it now!`,
        campaignId: campaign?.id || null
      });

      res.json({ 
        content: emailContent,
        components: modularEmail.components,
        globalStyles: modularEmail.globalStyles,
        campaign,
        email,
        creationType,
        message: creationType === "campaign" ? "Email campaign flow generated successfully" : "Email template generated successfully"
      });
    } catch (error) {
      console.error("Chat generation error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to generate campaign" });
    }
  });

  app.post("/api/chat/reset", async (req, res) => {
    try {
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      // Clear all chat messages for the user
      await storage.clearChatMessages(parseInt(userId));

      res.json({ message: "Chat history cleared successfully" });
    } catch (error) {
      console.error("Chat reset error:", error);
      res.status(500).json({ message: "Failed to reset chat" });
    }
  });

  app.get("/api/chat/messages/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const messages = await storage.getChatMessagesByUser(userId);
      res.json(messages);
    } catch (error) {
      console.error("Get chat messages error:", error);
      res.status(500).json({ message: "Failed to retrieve chat messages" });
    }
  });

  // Generate unified flow (combining AI and Klaviyo capabilities)
  app.post("/api/flows/generate", async (req, res) => {
    try {
      const { prompt, businessType = 'general', campaignType = 'automated' } = req.body;
      const userId = 1; // Default user for demo

      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      // Generate comprehensive flow with AI
      const generatedFlow = await generateEmailFlow(prompt);
      const { v4: uuidv4 } = require('uuid');
      const flowId = uuidv4();

      // Create the actual flow record
      const flow = await storage.createFlow({
        id: flowId,
        name: generatedFlow.name,
        status: 'draft',
        userId: userId
      });

      // Create nodes
      if (generatedFlow.nodes && generatedFlow.nodes.length > 0) {
        await Promise.all(generatedFlow.nodes.map((node: any) => 
          storage.createFlowNode({
            id: node.id,
            flowId: flowId,
            type: node.type,
            x: node.x,
            y: node.y,
            settings: node.settings || {}
          })
        ));
      }

      // Create edges
      if (generatedFlow.edges && generatedFlow.edges.length > 0) {
        await Promise.all(generatedFlow.edges.map((edge: any) => 
          storage.createFlowEdge({
            id: edge.id,
            flowId: flowId,
            sourceNode: edge.source,
            targetNode: edge.target
          })
        ));
      }

      // Save user message
      await storage.createChatMessage({
        userId: userId,
        role: "user",
        content: prompt,
        campaignId: null
      });

      // Save AI response
      await storage.createChatMessage({
        userId: userId,
        role: "assistant",
        content: `I've created a complete marketing flow "${generatedFlow.name}" with ${generatedFlow.nodes?.length || 0} connected steps. You can now edit and run this flow visually!`,
        campaignId: null
      });

      res.json({ 
        ...generatedFlow,
        flow,
        flowId,
        message: "Flow generated successfully"
      });
    } catch (error) {
      console.error("Flow generation error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to generate flow" });
    }
  });

  // Advanced AI Flow Generation Endpoint
  app.post("/api/chat/generate-flow", async (req, res) => {
    try {
      const { prompt, flowType = 'welcome_series', userId } = req.body;

      if (!prompt || !userId) {
        return res.status(400).json({ message: "Prompt and user ID required" });
      }

      // Generate sophisticated flow using enhanced AI
      const flowData = await generateEmailFlow(prompt, flowType);

      // Create the automation flow
      const flow = await storage.createFlow({
        userId: parseInt(userId as string),
        name: flowData.name,
        status: 'draft'
      });

      // Create emails for the flow
      const createdEmails = [];
      for (const emailData of flowData.emails) {
        const email = await storage.createEmail({
          campaignId: parseInt(flow.id),
          subject: emailData.subject,
          html: emailData.htmlContent,
          json: {
            components: emailData.content?.body?.sections || [],
            header: emailData.content?.header,
            cta: emailData.content?.cta,
            personalizations: emailData.personalizations || [],
            abTestVariations: emailData.abTestVariations || [],
            delay: emailData.delay,
            step: emailData.step
          },
          sequenceOrder: emailData.step || 1
        });
        createdEmails.push(email);
      }

      // Save chat messages
      await storage.createChatMessage({
        userId: parseInt(userId as string),
        role: "user",
        content: prompt,
        campaignId: parseInt(flow.id)
      });

      await storage.createChatMessage({
        userId: parseInt(userId as string),
        role: "assistant", 
        content: `I've created a sophisticated ${flowType} automation flow called "${flowData.name}". This flow includes ${flowData.emails.length} professionally crafted emails with strategic timing and conditional logic. The flow is designed to ${flowData.expectedResults?.conversionGoals || 'maximize engagement and conversions'}. You can now edit and customize each email in the flow builder.`,
        campaignId: flow.id
      });

      res.json({
        flow,
        emails: createdEmails,
        flowData,
        preview: flowData.preview,
        message: `Professional ${flowType} flow generated with ${flowData.emails.length} emails`
      });
    } catch (error) {
      console.error("Flow generation error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to generate flow" });
    }
  });

  // Campaign endpoints
  app.post("/api/campaigns", async (req, res) => {
    try {
      const validatedData = insertCampaignSchema.parse(req.body);
      const campaign = await storage.createCampaign(validatedData);
      res.json(campaign);
    } catch (error) {
      console.error("Create campaign error:", error);
      res.status(400).json({ message: "Invalid campaign data" });
    }
  });

  app.get("/api/campaigns/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const campaigns = await storage.getCampaignsByUser(userId);
      res.json(campaigns);
    } catch (error) {
      console.error("Get campaigns error:", error);
      res.status(500).json({ message: "Failed to retrieve campaigns" });
    }
  });

  app.get("/api/campaigns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const campaign = await storage.getCampaign(id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      console.error("Get campaign error:", error);
      res.status(500).json({ message: "Failed to retrieve campaign" });
    }
  });

  app.put("/api/campaigns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const campaign = await storage.updateCampaign(id, updates);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.json(campaign);
    } catch (error) {
      console.error("Update campaign error:", error);
      res.status(500).json({ message: "Failed to update campaign" });
    }
  });

  app.delete("/api/campaigns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCampaign(id);
      if (!success) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      res.json({ message: "Campaign deleted successfully" });
    } catch (error) {
      console.error("Delete campaign error:", error);
      res.status(500).json({ message: "Failed to delete campaign" });
    }
  });

  // Get campaign emails
  app.get("/api/campaigns/:id/emails", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const emails = await storage.getEmailsByCampaign(campaignId);
      res.json(emails);
    } catch (error) {
      console.error("Get campaign emails error:", error);
      res.status(500).json({ message: "Failed to get campaign emails" });
    }
  });

  // Email endpoints - specific routes first to avoid conflicts
  app.get("/api/emails/library", async (req, res) => {
    try {
      // Get all emails for the library (both templates and campaign emails)
      const emails = await storage.getEmailsLibrary();
      res.json(emails);
    } catch (error) {
      console.error("Get emails library error:", error);
      res.status(500).json({ message: "Failed to retrieve emails library" });
    }
  });

  app.get("/api/emails/campaign/:campaignId", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.campaignId);
      const emails = await storage.getEmailsByCampaign(campaignId);
      res.json(emails);
    } catch (error) {
      console.error("Get emails error:", error);
      res.status(500).json({ message: "Failed to retrieve emails" });
    }
  });

  app.get("/api/emails/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const email = await storage.getEmail(id);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      res.json(email);
    } catch (error) {
      console.error("Get email error:", error);
      res.status(500).json({ message: "Failed to retrieve email" });
    }
  });

  app.post("/api/emails", async (req, res) => {
    try {
      const validatedData = insertEmailSchema.parse(req.body);
      const email = await storage.createEmail(validatedData);
      res.json(email);
    } catch (error) {
      console.error("Create email error:", error);
      res.status(400).json({ message: "Invalid email data" });
    }
  });

  app.put("/api/emails/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const email = await storage.updateEmail(id, updates);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      res.json(email);
    } catch (error) {
      console.error("Update email error:", error);
      res.status(500).json({ message: "Failed to update email" });
    }
  });

  app.delete("/api/emails/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteEmail(id);
      if (!success) {
        return res.status(404).json({ message: "Email not found" });
      }
      res.json({ message: "Email deleted successfully" });
    } catch (error) {
      console.error("Delete email error:", error);
      res.status(500).json({ message: "Failed to delete email" });
    }
  });

  // Email sending endpoints
  app.post("/api/email/test", async (req, res) => {
    try {
      const { to, content } = req.body;

      if (!to || !content) {
        return res.status(400).json({ message: "Recipient email and content are required" });
      }

      const validatedContent = emailContentSchema.parse(content);

      const html = generateEmailHTML(validatedContent);
      const text = generateEmailText(validatedContent);

      const success = await sendEmail({
        to,
        from: process.env.SENDER_EMAIL || "noreply@emailai.com",
        subject: validatedContent.subject,
        html,
        text
      });

      if (success) {
        res.json({ message: "Test email sent successfully" });
      } else {
        res.status(500).json({ message: "Failed to send test email" });
      }
    } catch (error) {
      console.error("Send test email error:", error);
      res.status(500).json({ message: "Failed to send test email" });
    }
  });

  app.post("/api/email/send", async (req, res) => {
    try {
      const { campaignId, recipients } = req.body;

      if (!campaignId || !recipients || !Array.isArray(recipients)) {
        return res.status(400).json({ message: "Campaign ID and recipients array are required" });
      }

      const campaign = await storage.getCampaign(parseInt(campaignId));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      const content = emailContentSchema.parse(campaign.content);
      const html = generateEmailHTML(content);
      const text = generateEmailText(content);

      const results = await Promise.allSettled(
        recipients.map(async (recipient: string) => {
          return await sendEmail({
            to: recipient,
            from: process.env.SENDER_EMAIL || "noreply@emailai.com",
            subject: content.subject,
            html,
            text
          });
        })
      );

      const successful = results.filter(result => result.status === "fulfilled" && result.value === true).length;
      const failed = results.length - successful;

      // Update campaign status
      await storage.updateCampaign(parseInt(campaignId), { status: "sent" });

      res.json({
        message: `Campaign sent to ${successful} recipients`,
        successful,
        failed,
        total: recipients.length
      });
    } catch (error) {
      console.error("Send campaign error:", error);
      res.status(500).json({ message: "Failed to send campaign" });
    }
  });

  // Content improvement endpoint
  app.post("/api/content/improve", async (req, res) => {
    try {
      const { content, improvement } = req.body;

      if (!content || !improvement) {
        return res.status(400).json({ message: "Content and improvement request are required" });
      }

      const validatedContent = emailContentSchema.parse(content);
      const improvedContent = await improveCampaignContent(validatedContent, improvement);

      res.json({ content: improvedContent });
    } catch (error) {
      console.error("Improve content error:", error);
      res.status(500).json({ message: "Failed to improve content" });
    }
  });

  // Integration endpoints
  app.get("/api/integrations/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const integrations = await storage.getIntegrationsByUser(userId);
      res.json(integrations);
    } catch (error) {
      console.error("Get integrations error:", error);
      res.status(500).json({ message: "Failed to retrieve integrations" });
    }
  });

  app.get("/api/integrations/status", async (req, res) => {
    try {
      const { userId } = req.query;

      // System-level integrations
      const systemIntegrations = {
        openai: {
          connected: !!process.env.OPENAI_API_KEY,
          name: "OpenAI",
          description: "AI content generation"
        },
        sendgrid: {
          connected: !!process.env.SENDGRID_API_KEY,
          name: "SendGrid",
          description: "Email delivery"
        }
      };

      // User-specific integrations
      let userIntegrations = {};
      if (userId) {
        const integrations = await storage.getIntegrationsByUser(parseInt(userId as string));
        userIntegrations = integrations.reduce((acc: any, integration: any) => {
          acc[integration.provider] = {
            connected: integration.isActive,
            name: integration.provider.charAt(0).toUpperCase() + integration.provider.slice(1),
            description: integration.accountEmail || "Connected",
            accountEmail: integration.accountEmail,
            connectedAt: integration.connectedAt
          };
          return acc;
        }, {});
      }

      const status = {
        ...systemIntegrations,
        ...userIntegrations
      };

      res.json(status);
    } catch (error) {
      console.error("Get integration status error:", error);
      res.status(500).json({ message: "Failed to retrieve integration status" });
    }
  });

  // OAuth Authentication Routes
  app.get("/api/auth/:platform/status", async (req, res) => {
    try {
      const { platform } = req.params;
      const isConfigured = oauthService.isConfigured(platform);

      if (isConfigured) {
        res.json({ configured: true });
      } else {
        res.status(400).json({ 
          configured: false, 
          message: `OAuth configuration missing for ${platform}` 
        });
      }
    } catch (error) {
      console.error("OAuth status error:", error);
      res.status(500).json({ message: "Failed to check OAuth status" });
    }
  });

  app.get("/api/auth/:platform", async (req, res) => {
    try {
      const { platform } = req.params;
      const { userId } = req.query;

      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const authUrl = oauthService.generateAuthUrl(platform, parseInt(userId as string));
      res.redirect(authUrl);
    } catch (error) {
      console.error("OAuth auth error:", error);
      res.status(500).json({ message: "Failed to initiate OAuth flow" });
    }
  });

  app.get("/api/auth/:platform/callback", async (req, res) => {
    try {
      const { platform } = req.params;
      const { code, state, error } = req.query;

      if (error) {
        return res.status(400).json({ message: `OAuth error: ${error}` });
      }

      if (!code || !state) {
        return res.status(400).json({ message: "Missing authorization code or state" });
      }

      // Parse state to get userId
      const [userId, platformFromState] = (state as string).split(':');

      if (platform !== platformFromState) {
        return res.status(400).json({ message: "Invalid state parameter" });
      }

      // Exchange code for tokens
      const tokenResponse = await oauthService.exchangeCodeForToken(platform, code as string);

      // Get user info from platform
      const userInfo = await oauthService.getUserInfo(platform, tokenResponse.access_token);

      // Save integration
      const integration = await oauthService.saveIntegration(
        parseInt(userId),
        platform,
        tokenResponse,
        userInfo
      );

      // Redirect to frontend with success message
      res.redirect(`/?integration=success&platform=${platform}&email=${userInfo.email}`);
    } catch (error) {
      console.error("OAuth callback error:", error);
      res.redirect(`/?integration=error&platform=${req.params.platform}&error=${encodeURIComponent(error instanceof Error ? error.message : 'Unknown error')}`);
    }
  });

  // API Key based integration setup
  app.post("/api/integrations/:platform", async (req, res) => {
    try {
      const { platform } = req.params;
      const { userId, apiKey } = req.body;

      if (!userId || !apiKey) {
        return res.status(400).json({ message: "User ID and API key are required" });
      }

      // Test the API key validity based on platform
      let isValid = false;
      let userInfo = null;

      switch (platform) {
        case 'wordpress':
          // WordPress with application password - simple validation
          isValid = apiKey && apiKey.length > 10;
          userInfo = { id: 'wp-user', email: 'user@wordpress.com' };
          break;
        case 'klaviyo':
          // Klaviyo API key - test with account endpoint
          try {
            const response = await fetch('https://a.klaviyo.com/api/account', {
              headers: {
                'Authorization': `Klaviyo-API-Key ${apiKey}`,
                'revision': '2024-02-15'
              }
            });
            isValid = response.ok;
            if (isValid) {
              const data = await response.json();
              userInfo = { 
                id: data.data?.id || 'klaviyo-user', 
                email: data.data?.attributes?.contact_information?.default_sender_email || 'user@klaviyo.com'
              };
            }
          } catch (error) {
            isValid = false;
          }
          break;
        default:
          return res.status(400).json({ message: "Platform not supported for API key authentication" });
      }

      if (!isValid) {
        return res.status(400).json({ message: "Invalid API key" });
      }

      // Save integration
      const integration = await storage.createIntegration({
        userId: parseInt(userId),
        provider: platform,
        apiKey,
        accountEmail: userInfo?.email,
        accountId: userInfo?.id,
        isActive: true
      });

      res.json({
        message: "Integration connected successfully",
        integration: {
          id: integration.id,
          provider: integration.provider,
          accountEmail: integration.accountEmail,
          connected: true
        }
      });
    } catch (error) {
      console.error("API key integration error:", error);
      res.status(500).json({ message: "Failed to connect integration" });
    }
  });

  // Delete integration
  app.delete("/api/integrations/:id", async (req, res) => {
    try {
      const integrationId = parseInt(req.params.id);
      const success = await storage.deleteIntegration(integrationId);

      if (success) {
        res.json({ message: "Integration disconnected successfully" });
      } else {
        res.status(404).json({ message: "Integration not found" });
      }
    } catch (error) {
      console.error("Delete integration error:", error);
      res.status(500).json({ message: "Failed to disconnect integration" });
    }
  });

  // Campaign export endpoint
  app.post("/api/campaigns/:id/export", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const { userId, platform, options } = req.body;

      if (!userId || !platform) {
        return res.status(400).json({ message: "User ID and platform are required" });
      }

      const result = await campaignExportService.exportCampaign(
        parseInt(userId),
        campaignId,
        platform,
        options || {}
      );

      if (result.success) {
        res.json({
          message: result.message,
          campaignId: result.campaignId,
          platformCampaignId: result.platformCampaignId
        });
      } else {
        res.status(400).json({
          message: result.message,
          error: result.error
        });
      }
    } catch (error) {
      console.error("Campaign export error:", error);
      res.status(500).json({ message: "Failed to export campaign" });
    }
  });

  // Convert email to modular components endpoint
  app.post("/api/emails/:id/convert-to-components", async (req, res) => {
    try {
      const emailId = parseInt(req.params.id);
      const email = await storage.getEmail(emailId);

      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }

      // If email already has components, return them
      if (email.json && typeof email.json === 'object' && (email.json as any).components) {
        return res.json({
          components: (email.json as any).components,
          globalStyles: (email.json as any).globalStyles || {
            backgroundColor: '#ffffff',
            fontFamily: 'Arial, Helvetica, sans-serif',
            fontSize: '16px',
            color: '#374151',
            maxWidth: '600px',
          }
        });
      }

      // Convert existing email content to components
      const emailContent = {
        subject: email.subject,
        header: {
          title: email.subject,
          backgroundColor: "#3B82F6"
        },
        body: {
          sections: [{
            type: "text",
            content: email.html || "Email content"
          }]
        },
        cta: {
          text: "Learn More",
          url: "#",
          backgroundColor: "#10B981"
        }
      };

      const modularEmail = convertEmailContentToComponents(emailContent);

      // Update the email with modular components
      await storage.updateEmail(emailId, {
        json: {
          ...emailContent,
          components: modularEmail.components,
          globalStyles: modularEmail.globalStyles
        }
      });

      res.json({
        components: modularEmail.components,
        globalStyles: modularEmail.globalStyles
      });
    } catch (error) {
      console.error("Convert to components error:", error);
      res.status(500).json({ message: "Failed to convert email to components" });
    }
  });

  // Flow API endpoints
  app.get("/api/flows", async (req, res) => {
    try {
      const { userId = 1 } = req.query; // Default to demo user
      const flows = await storage.getFlowsByUser(parseInt(userId as string));
      res.json(flows);
    } catch (error) {
      console.error("Get flows error:", error);
      res.status(500).json({ message: "Failed to retrieve flows" });
    }
  });

  app.post("/api/flows", async (req, res) => {
    try {
      const { id, name, status, userId, nodes, edges } = req.body;
      const { v4: uuidv4 } = require('uuid');

      const flowId = id || uuidv4();

      // Create flow
      const flow = await storage.createFlow({
        id: flowId,
        name,
        status: status || 'draft',
        userId: userId || 1
      });

      // Create nodes
      if (nodes && nodes.length > 0) {
        await Promise.all(nodes.map((node: any) => 
          storage.createFlowNode({
            id: node.id,
            flowId: flowId,
            type: node.type,
            x: node.x,
            y: node.y,
            settings: node.settings || {}
          })
        ));
      }

      // Create edges
      if (edges && edges.length > 0) {
        await Promise.all(edges.map((edge: any) => 
          storage.createFlowEdge({
            id: edge.id,
            flowId: flowId,
            sourceNode: edge.sourceNode,
            targetNode: edge.targetNode
          })
        ));
      }

      res.json(flow);
    } catch (error) {
      console.error("Create flow error:", error);
      res.status(500).json({ message: "Failed to create flow" });
    }
  });

  app.get("/api/flows/:flowId", async (req, res) => {
    try {
      const { flowId } = req.params;
      const flow = await storage.getFlow(flowId);

      if (!flow) {
        return res.status(404).json({ message: "Flow not found" });
      }

      res.json(flow);
    } catch (error) {
      console.error("Get flow error:", error);
      res.status(500).json({ message: "Failed to retrieve flow" });
    }
  });

  app.put("/api/flows/:flowId", async (req, res) => {
    try {
      const { flowId } = req.params;
      const { name, status, nodes, edges } = req.body;

      // Update flow
      const flow = await storage.updateFlow(flowId, { name, status });

      if (!flow) {
        return res.status(404).json({ message: "Flow not found" });
      }

      // Update nodes if provided
      if (nodes) {
        // Delete existing nodes
        const existingNodes = await storage.getFlowNodes(flowId);
        await Promise.all(existingNodes.map(node => storage.deleteFlowNode(node.id)));

        // Create new nodes
        await Promise.all(nodes.map((node: any) => 
          storage.createFlowNode({
            id: node.id,
            flowId: flowId,
            type: node.type,
            x: node.x,
            y: node.y,
            settings: node.settings || {}
          })
        ));
      }

      // Update edges if provided
      if (edges) {
        // Delete existing edges
        const existingEdges = await storage.getFlowEdges(flowId);
        await Promise.all(existingEdges.map(edge => storage.deleteFlowEdge(edge.id)));

        // Create new edges
        await Promise.all(edges.map((edge: any) => 
          storage.createFlowEdge({
            id: edge.id,
            flowId: flowId,
            sourceNode: edge.sourceNode,
            targetNode: edge.targetNode
          })
        ));
      }

      res.json(flow);
    } catch (error) {
      console.error("Update flow error:", error);
      res.status(500).json({ message: "Failed to update flow" });
    }
  });

  app.delete("/api/flows/:flowId", async (req, res) => {
    try {
      const { flowId } = req.params;
      const success = await storage.deleteFlow(flowId);

      if (success) {
        res.json({ message: "Flow deleted successfully" });
      } else {
        res.status(404).json({ message: "Flow not found" });
      }
    } catch (error) {
      console.error("Delete flow error:", error);
      res.status(500).json({ message: "Failed to delete flow" });
    }
  });

  app.post("/api/flows/:flowId/duplicate", async (req, res) => {
    try {
      const { flowId } = req.params;
      const { v4: uuidv4 } = require('uuid');

      const originalFlow = await storage.getFlow(flowId);

      if (!originalFlow) {
        return res.status(404).json({ message: "Flow not found" });
      }

      const newFlowId = uuidv4();

      // Create duplicate flow
      const duplicateFlow = await storage.createFlow({
        id: newFlowId,
        name: `${originalFlow.name} (Copy)`,
        status: 'draft',
        userId: originalFlow.userId
      });

      // Get and duplicate nodes
      const originalNodes = await storage.getFlowNodes(flowId);
      if (originalNodes && originalNodes.length > 0) {
        await Promise.all(originalNodes.map((node: any) => 
          storage.createFlowNode({
            id: uuidv4(),
            flowId: newFlowId,
            type: node.type,
            x: node.x,
            y: node.y,
            settings: node.settings || {}
          })
        ));
      }

      // Get and duplicate edges  
      const originalEdges = await storage.getFlowEdges(flowId);
      if (originalEdges && originalEdges.length > 0) {
        await Promise.all(originalEdges.map((edge: any) => 
          storage.createFlowEdge({
            id: uuidv4(),
            flowId: newFlowId,
            sourceNode: edge.sourceNode,
            targetNode: edge.targetNode
          })
        ));
      }

      res.json(duplicateFlow);
    } catch (error) {
      console.error("Duplicate flow error:", error);
      res.status(500).json({ message: "Failed to duplicate flow" });
    }
  });

  app.post("/api/flows/:flowId/run", async (req, res) => {
    try {
      const { flowId } = req.params;
      const { userId = 1 } = req.body;

      // Update flow status to active
      await storage.updateFlow(flowId, { status: 'active' });

      // TODO: Implement flow execution logic here
      // This would involve:
      // 1. Processing trigger nodes
      // 2. Scheduling delay nodes
      // 3. Evaluating filter nodes
      // 4. Executing action nodes (sending emails)

      res.json({ message: "Flow execution started" });
    } catch (error) {
      console.error("Run flow error:", error);
      res.status(500).json({ message: "Failed to run flow" });
    }
  });

  app.post("/api/events", async (req, res) => {
    try {
      const { userId, eventType, payload } = req.body;
      const { v4: uuidv4 } = require('uuid');

      if (!userId || !eventType || !payload) {
        return res.status(400).json({ message: "userId, eventType, and payload are required" });
      }

      // Create flow event
      const event = await storage.createFlowEvent({
        id: uuidv4(),
        userId: parseInt(userId),
        eventType,
        payload
      });

      // TODO: Implement event processing logic here
      // This would involve:
      // 1. Finding flows with matching triggers
      // 2. Starting flow executions
      // 3. Processing the event through the flow graph

      res.json({ message: "Event processed successfully", eventId: event.id });
    } catch (error) {
      console.error("Process event error:", error);
      res.status(500).json({ message: "Failed to process event" });
    }
  });

  // ========================
  // ESP-COMPATIBLE API ROUTES
  // ========================

  // Contact Management API
  app.get("/api/contacts/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const contacts = await storage.getContactsByUser(userId);
      res.json(contacts);
    } catch (error) {
      console.error("Get contacts error:", error);
      res.status(500).json({ message: "Failed to retrieve contacts" });
    }
  });

  app.post("/api/contacts", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await contactManagementService.createContact(contactData);
      res.json(contact);
    } catch (error) {
      console.error("Create contact error:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to create contact" });
    }
  });

  app.post("/api/contacts/import", async (req, res) => {
    try {
      const { userId, contacts, listId } = req.body;

      if (!userId || !contacts || !Array.isArray(contacts)) {
        return res.status(400).json({ message: "userId and contacts array are required" });
      }

      const result = await contactManagementService.importContacts(userId, contacts, listId);
      res.json(result);
    } catch (error) {
      console.error("Import contacts error:", error);
      res.status(500).json({ message: "Failed to import contacts" });
    }
  });

  app.put("/api/contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const updates = req.body;
      const contact = await contactManagementService.updateContact(contactId, updates);
      res.json(contact);
    } catch (error) {
      console.error("Update contact error:", error);
      res.status(500).json({ message: "Failed to update contact" });
    }
  });

  app.delete("/api/contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      await contactManagementService.deleteContact(contactId);
      res.json({ message: "Contact deleted successfully" });
    } catch (error) {
      console.error("Delete contact error:", error);
      res.status(500).json({ message: "Failed to delete contact" });
    }
  });

  // Email List Management API
  app.get("/api/lists/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const lists = await storage.getEmailListsByUser(userId);
      res.json(lists);
    } catch (error) {
      console.error("Get lists error:", error);
      res.status(500).json({ message: "Failed to retrieve lists" });
    }
  });

  app.post("/api/lists", async (req, res) => {
    try {
      const listData = insertEmailListSchema.parse(req.body);
      const list = await contactManagementService.createEmailList(listData);
      res.json(list);
    } catch (error) {
      console.error("Create list error:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to create list" });
    }
  });

  // Email Template Management API
  app.get("/api/templates/library", async (req, res) => {
    try {
      const { userId, category, search } = req.query;
      const filters = { category: category as string, search: search as string };
      const library = await templateEngine.getTemplateLibrary(parseInt(userId as string), filters);
      res.json(library);
    } catch (error) {
      console.error("Get template library error:", error);
      res.status(500).json({ message: "Failed to retrieve template library" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const templateData = insertEmailTemplateSchema.parse(req.body);
      const template = await templateEngine.createTemplate(templateData);
      res.json(template);
    } catch (error) {
      console.error("Create template error:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to create template" });
    }
  });

  // Automation Management API
  app.get("/api/automations/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const automations = await storage.getAutomationsByUser(userId);
      res.json(automations);
    } catch (error) {
      console.error("Get automations error:", error);
      res.status(500).json({ message: "Failed to retrieve automations" });
    }
  });

  app.post("/api/automations", async (req, res) => {
    try {
      const automationData = insertAutomationSchema.parse(req.body);
      const automation = await automationEngine.createAutomation(automationData);
      res.json(automation);
    } catch (error) {
      console.error("Create automation error:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to create automation" });
    }
  });

  // Analytics API
  app.post("/api/analytics/track", async (req, res) => {
    try {
      const { campaignId, emailId, contactId, eventType, eventData, userAgent, ipAddress } = req.body;

      await analyticsService.trackEmailEvent({
        campaignId,
        emailId,
        contactId,
        eventType,
        eventData,
        userAgent,
        ipAddress
      });

      res.json({ message: "Event tracked successfully" });
    } catch (error) {
      console.error("Track event error:", error);
      res.status(500).json({ message: "Failed to track event" });
    }
  });

  app.get("/api/analytics/campaigns/:id", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const analytics = await analyticsService.getCampaignAnalytics(campaignId);
      res.json(analytics);
    } catch (error) {
      console.error("Get campaign analytics error:", error);
      res.status(500).json({ message: "Failed to retrieve campaign analytics" });
    }
  });

  app.get("/api/analytics/dashboard/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const stats = await analyticsService.getUserDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Get dashboard stats error:", error);
      res.status(500).json({ message: "Failed to retrieve dashboard stats" });
    }
  });

  // ESP Integration API
  app.post("/api/esp/:platform/campaigns", async (req, res) => {
    try {
      const platform = req.params.platform;
      const { accessToken, emailContent, listId, settings } = req.body;

      let result;
      switch (platform) {
        case 'mailchimp':
          result = await espIntegrationService.createMailchimpCampaign(accessToken, emailContent, listId, settings);
          break;
        case 'klaviyo':
          result = await espIntegrationService.createKlaviyoCampaign(accessToken, emailContent, listId, settings);
          break;
        case 'activecampaign':
          result = await espIntegrationService.createActiveCampaignCampaign(accessToken, emailContent, [listId], settings);
          break;
        case 'convertkit':
          result = await espIntegrationService.createConvertKitBroadcast(accessToken, emailContent, settings);
          break;
        default:
          return res.status(400).json({ message: "Unsupported ESP platform" });
      }

      res.json(result);
    } catch (error) {
      console.error("ESP campaign creation error:", error);
      res.status(500).json({ message: `Failed to create ${req.params.platform} campaign` });
    }
  });

  // Event Processing API
  app.post("/api/events/process", async (req, res) => {
    try {
      const { eventType, eventData } = req.body;
      await automationEngine.processEvent(eventType, eventData);
      res.json({ message: "Event processed successfully" });
    } catch (error) {
      console.error("Process event error:", error);
      res.status(500).json({ message: "Failed to process event" });
    }
  });

  // Initialize built-in templates on server start
  templateEngine.initializeBuiltInTemplates().catch(console.error);

  const httpServer = createServer(app);
  return httpServer;
}