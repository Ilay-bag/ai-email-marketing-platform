import { storage } from "../storage";
import { EmailTemplate, EnhancedEmailContent } from "@shared/schema";

// Professional Email Template Engine with ESP compatibility
export class TemplateEngine {
  
  // Create template from email content
  async createTemplate(templateData: {
    userId: number;
    name: string;
    category?: string;
    content: EnhancedEmailContent;
    subject?: string;
    preheader?: string;
    isPublic?: boolean;
  }): Promise<EmailTemplate> {
    // Generate thumbnail from content
    const thumbnail = await this.generateTemplateThumbnail(templateData.content);
    
    return await storage.createEmailTemplate({
      userId: templateData.userId,
      name: templateData.name,
      category: templateData.category || 'custom',
      thumbnail,
      subject: templateData.subject,
      preheader: templateData.preheader,
      content: templateData.content,
      isPublic: templateData.isPublic || false,
      usageCount: 0
    });
  }

  // Get template library with categories
  async getTemplateLibrary(userId: number, filters?: {
    category?: string;
    isPublic?: boolean;
    search?: string;
  }): Promise<{
    templates: EmailTemplate[];
    categories: Array<{ name: string; count: number }>;
    featured: EmailTemplate[];
  }> {
    let templates = await storage.getEmailTemplatesByUser(userId);
    
    // Include public templates
    if (!filters?.isPublic || filters.isPublic) {
      const publicTemplates = await storage.getPublicEmailTemplates();
      templates = [...templates, ...publicTemplates];
    }

    // Apply filters
    if (filters?.category) {
      templates = templates.filter(t => t.category === filters.category);
    }

    if (filters?.search) {
      const searchTerm = filters.search.toLowerCase();
      templates = templates.filter(t => 
        t.name.toLowerCase().includes(searchTerm) ||
        (t.subject && t.subject.toLowerCase().includes(searchTerm))
      );
    }

    // Get categories with counts
    const categoryMap = new Map<string, number>();
    templates.forEach(t => {
      const category = t.category || 'custom';
      categoryMap.set(category, (categoryMap.get(category) || 0) + 1);
    });

    const categories = Array.from(categoryMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    // Featured templates (most used public templates)
    const featured = templates
      .filter(t => t.isPublic)
      .sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0))
      .slice(0, 6);

    return {
      templates: templates.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()),
      categories,
      featured
    };
  }

  // Clone template for user
  async cloneTemplate(templateId: number, userId: number, customizations?: {
    name?: string;
    subject?: string;
    preheader?: string;
  }): Promise<EmailTemplate> {
    const originalTemplate = await storage.getEmailTemplate(templateId);
    if (!originalTemplate) {
      throw new Error('Template not found');
    }

    // Increment usage count if it's a public template
    if (originalTemplate.isPublic) {
      await storage.updateEmailTemplate(templateId, {
        usageCount: (originalTemplate.usageCount || 0) + 1
      });
    }

    // Create cloned template
    return await storage.createEmailTemplate({
      userId,
      name: customizations?.name || `Copy of ${originalTemplate.name}`,
      category: originalTemplate.category,
      thumbnail: originalTemplate.thumbnail,
      subject: customizations?.subject || originalTemplate.subject,
      preheader: customizations?.preheader || originalTemplate.preheader,
      content: originalTemplate.content,
      isPublic: false,
      usageCount: 0
    });
  }

  // Update template
  async updateTemplate(templateId: number, updates: Partial<EmailTemplate>): Promise<EmailTemplate> {
    const template = await storage.getEmailTemplate(templateId);
    if (!template) {
      throw new Error('Template not found');
    }

    // Regenerate thumbnail if content changed
    if (updates.content) {
      updates.thumbnail = await this.generateTemplateThumbnail(updates.content as EnhancedEmailContent);
    }

    return await storage.updateEmailTemplate(templateId, {
      ...updates,
      updatedAt: new Date()
    });
  }

  // Built-in professional templates
  async initializeBuiltInTemplates(): Promise<void> {
    const builtInTemplates = [
      {
        name: "Welcome Series - Modern",
        category: "welcome",
        subject: "Welcome to {{company}}! 🎉",
        preheader: "We're excited to have you on board",
        content: this.createWelcomeTemplate()
      },
      {
        name: "Newsletter - Clean Design",
        category: "newsletter",
        subject: "{{company}} Weekly Update",
        preheader: "The latest news and updates from our team",
        content: this.createNewsletterTemplate()
      },
      {
        name: "Product Launch - Bold",
        category: "promotion",
        subject: "🚀 Introducing {{product_name}}",
        preheader: "The feature you've been waiting for is here",
        content: this.createProductLaunchTemplate()
      },
      {
        name: "Cart Abandonment - Persuasive",
        category: "ecommerce",
        subject: "Don't forget about your cart",
        preheader: "Complete your purchase before items sell out",
        content: this.createCartAbandonmentTemplate()
      },
      {
        name: "Event Invitation - Professional",
        category: "event",
        subject: "You're invited: {{event_name}}",
        preheader: "Join us for an exclusive event",
        content: this.createEventInvitationTemplate()
      },
      {
        name: "Re-engagement - Friendly",
        category: "reengagement",
        subject: "We miss you at {{company}}",
        preheader: "Come back and see what's new",
        content: this.createReengagementTemplate()
      }
    ];

    // Create templates as public system templates
    for (const template of builtInTemplates) {
      await storage.createEmailTemplate({
        userId: 0, // System user
        name: template.name,
        category: template.category,
        subject: template.subject,
        preheader: template.preheader,
        content: template.content,
        thumbnail: await this.generateTemplateThumbnail(template.content),
        isPublic: true,
        usageCount: 0
      });
    }
  }

  // Template content creators
  private createWelcomeTemplate(): EnhancedEmailContent {
    return {
      subject: "Welcome to {{company}}! 🎉",
      preheader: "We're excited to have you on board",
      fromName: "{{company}} Team",
      components: [
        {
          id: "header",
          type: "header",
          content: {
            title: "Welcome to {{company}}!",
            subtitle: "We're thrilled to have you join our community"
          },
          styles: {
            backgroundColor: "#f8f9fa",
            padding: "40px 20px",
            textAlign: "center"
          }
        },
        {
          id: "intro",
          type: "text",
          content: {
            html: "<p>Hi {{first_name}},</p><p>Welcome aboard! We're excited to help you get the most out of {{company}}. Here's what you can expect from us:</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "16px",
            lineHeight: "1.6"
          }
        },
        {
          id: "features",
          type: "list",
          content: {
            items: [
              { text: "📧 Professional email marketing tools" },
              { text: "📊 Detailed analytics and reporting" },
              { text: "🤖 AI-powered content generation" },
              { text: "🎯 Advanced segmentation and targeting" }
            ]
          },
          styles: {
            padding: "20px",
            fontSize: "16px"
          }
        },
        {
          id: "cta",
          type: "button",
          content: {
            text: "Get Started Now",
            url: "{{dashboard_url}}"
          },
          styles: {
            backgroundColor: "#007bff",
            color: "#ffffff",
            padding: "12px 24px",
            borderRadius: "6px",
            textDecoration: "none",
            display: "inline-block",
            fontWeight: "bold"
          }
        },
        {
          id: "footer",
          type: "footer",
          content: {
            text: "If you have any questions, feel free to reply to this email. We're here to help!",
            companyInfo: "{{company}} | {{address}}"
          },
          styles: {
            padding: "20px",
            backgroundColor: "#f8f9fa",
            fontSize: "14px",
            color: "#6c757d",
            textAlign: "center"
          }
        }
      ],
      globalStyles: {
        backgroundColor: "#ffffff",
        fontFamily: "Arial, sans-serif",
        fontSize: "16px",
        color: "#333333",
        maxWidth: "600px"
      }
    };
  }

  private createNewsletterTemplate(): EnhancedEmailContent {
    return {
      subject: "{{company}} Weekly Update",
      preheader: "The latest news and updates from our team",
      fromName: "{{company}} Newsletter",
      components: [
        {
          id: "header",
          type: "header",
          content: {
            title: "Weekly Update",
            subtitle: "{{current_date}}"
          },
          styles: {
            backgroundColor: "#2c3e50",
            color: "#ffffff",
            padding: "40px 20px",
            textAlign: "center"
          }
        },
        {
          id: "intro",
          type: "text",
          content: {
            html: "<p>Hello {{first_name}},</p><p>Here are the highlights from this week at {{company}}:</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "16px"
          }
        },
        {
          id: "feature-story",
          type: "text",
          content: {
            html: "<h2>🌟 Featured Story</h2><p>This week we're excited to share our latest product update that makes email marketing even easier...</p>"
          },
          styles: {
            padding: "20px",
            borderLeft: "4px solid #3498db"
          }
        },
        {
          id: "news-items",
          type: "list",
          content: {
            items: [
              { text: "📈 New analytics dashboard launched" },
              { text: "🔧 Bug fixes and performance improvements" },
              { text: "📚 Updated documentation and tutorials" },
              { text: "🎉 Customer success story spotlight" }
            ]
          },
          styles: {
            padding: "20px"
          }
        },
        {
          id: "cta",
          type: "button",
          content: {
            text: "Read Full Update",
            url: "{{blog_url}}"
          },
          styles: {
            backgroundColor: "#3498db",
            color: "#ffffff",
            padding: "12px 24px",
            borderRadius: "6px"
          }
        }
      ],
      globalStyles: {
        backgroundColor: "#f4f4f4",
        fontFamily: "Georgia, serif",
        fontSize: "16px",
        color: "#2c3e50",
        maxWidth: "600px"
      }
    };
  }

  private createProductLaunchTemplate(): EnhancedEmailContent {
    return {
      subject: "🚀 Introducing {{product_name}}",
      preheader: "The feature you've been waiting for is here",
      fromName: "{{company}} Team",
      components: [
        {
          id: "hero",
          type: "image",
          content: {
            src: "https://via.placeholder.com/600x300/007bff/ffffff?text=New+Product",
            alt: "{{product_name}} Launch"
          },
          styles: {
            width: "100%",
            display: "block"
          }
        },
        {
          id: "announcement",
          type: "header",
          content: {
            title: "{{product_name}} is Here!",
            subtitle: "The game-changing feature you've been waiting for"
          },
          styles: {
            backgroundColor: "#007bff",
            color: "#ffffff",
            padding: "40px 20px",
            textAlign: "center"
          }
        },
        {
          id: "description",
          type: "text",
          content: {
            html: "<p>Hi {{first_name}},</p><p>After months of development, we're thrilled to announce the launch of {{product_name}}. This revolutionary feature will transform how you approach email marketing.</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "18px",
            lineHeight: "1.6"
          }
        },
        {
          id: "benefits",
          type: "list",
          content: {
            items: [
              { text: "⚡ 3x faster campaign creation" },
              { text: "🎯 Advanced targeting capabilities" },
              { text: "📊 Real-time performance insights" },
              { text: "🔗 Seamless integration with existing tools" }
            ]
          },
          styles: {
            padding: "20px",
            backgroundColor: "#f8f9fa"
          }
        },
        {
          id: "early-access",
          type: "button",
          content: {
            text: "Get Early Access",
            url: "{{product_url}}"
          },
          styles: {
            backgroundColor: "#28a745",
            color: "#ffffff",
            padding: "16px 32px",
            borderRadius: "8px",
            fontSize: "18px",
            fontWeight: "bold"
          }
        }
      ],
      globalStyles: {
        backgroundColor: "#ffffff",
        fontFamily: "Helvetica, Arial, sans-serif",
        fontSize: "16px",
        color: "#333333",
        maxWidth: "600px"
      }
    };
  }

  private createCartAbandonmentTemplate(): EnhancedEmailContent {
    return {
      subject: "Don't forget about your cart",
      preheader: "Complete your purchase before items sell out",
      fromName: "{{company}} Store",
      components: [
        {
          id: "header",
          type: "header",
          content: {
            title: "You left something behind...",
            subtitle: "Complete your purchase before it's too late"
          },
          styles: {
            padding: "30px 20px",
            textAlign: "center",
            backgroundColor: "#ffc107",
            color: "#212529"
          }
        },
        {
          id: "personal-message",
          type: "text",
          content: {
            html: "<p>Hi {{first_name}},</p><p>We noticed you were interested in some great items but didn't complete your purchase. No worries - we've saved them for you!</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "16px"
          }
        },
        {
          id: "cart-items",
          type: "text",
          content: {
            html: "<h3>Your Cart Items:</h3><div style='border: 1px solid #ddd; padding: 15px; margin: 10px 0;'>{{cart_items}}</div>"
          },
          styles: {
            padding: "20px"
          }
        },
        {
          id: "urgency",
          type: "text",
          content: {
            html: "<p><strong>⏰ Hurry!</strong> Items in your cart are selling fast. Complete your purchase now to avoid disappointment.</p>"
          },
          styles: {
            padding: "20px",
            backgroundColor: "#fff3cd",
            border: "1px solid #ffeaa7",
            borderRadius: "4px"
          }
        },
        {
          id: "complete-purchase",
          type: "button",
          content: {
            text: "Complete Your Purchase",
            url: "{{cart_url}}"
          },
          styles: {
            backgroundColor: "#dc3545",
            color: "#ffffff",
            padding: "15px 30px",
            borderRadius: "6px",
            fontSize: "18px",
            fontWeight: "bold"
          }
        },
        {
          id: "incentive",
          type: "text",
          content: {
            html: "<p>🎁 <strong>Special Offer:</strong> Use code SAVE10 for 10% off your purchase!</p>"
          },
          styles: {
            padding: "20px",
            textAlign: "center",
            backgroundColor: "#d4edda",
            border: "1px solid #c3e6cb",
            borderRadius: "4px"
          }
        }
      ],
      globalStyles: {
        backgroundColor: "#ffffff",
        fontFamily: "Arial, sans-serif",
        fontSize: "16px",
        color: "#333333",
        maxWidth: "600px"
      }
    };
  }

  private createEventInvitationTemplate(): EnhancedEmailContent {
    return {
      subject: "You're invited: {{event_name}}",
      preheader: "Join us for an exclusive event",
      fromName: "{{company}} Events",
      components: [
        {
          id: "invitation-header",
          type: "header",
          content: {
            title: "You're Invited!",
            subtitle: "{{event_name}}"
          },
          styles: {
            backgroundColor: "#6f42c1",
            color: "#ffffff",
            padding: "40px 20px",
            textAlign: "center"
          }
        },
        {
          id: "event-details",
          type: "text",
          content: {
            html: "<p>Dear {{first_name}},</p><p>We're excited to invite you to our upcoming event: <strong>{{event_name}}</strong></p><p>📅 <strong>Date:</strong> {{event_date}}<br>🕐 <strong>Time:</strong> {{event_time}}<br>📍 <strong>Location:</strong> {{event_location}}</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "16px",
            lineHeight: "1.6"
          }
        },
        {
          id: "event-description",
          type: "text",
          content: {
            html: "<h3>What to Expect:</h3><p>{{event_description}}</p>"
          },
          styles: {
            padding: "20px",
            backgroundColor: "#f8f9fa"
          }
        },
        {
          id: "speakers",
          type: "text",
          content: {
            html: "<h3>Featured Speakers:</h3><ul><li>{{speaker_1}}</li><li>{{speaker_2}}</li><li>{{speaker_3}}</li></ul>"
          },
          styles: {
            padding: "20px"
          }
        },
        {
          id: "rsvp",
          type: "button",
          content: {
            text: "RSVP Now",
            url: "{{rsvp_url}}"
          },
          styles: {
            backgroundColor: "#6f42c1",
            color: "#ffffff",
            padding: "15px 30px",
            borderRadius: "6px",
            fontSize: "18px",
            fontWeight: "bold"
          }
        },
        {
          id: "contact-info",
          type: "text",
          content: {
            html: "<p>Questions? Contact us at {{contact_email}} or {{contact_phone}}</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "14px",
            color: "#6c757d",
            textAlign: "center"
          }
        }
      ],
      globalStyles: {
        backgroundColor: "#ffffff",
        fontFamily: "Georgia, serif",
        fontSize: "16px",
        color: "#333333",
        maxWidth: "600px"
      }
    };
  }

  private createReengagementTemplate(): EnhancedEmailContent {
    return {
      subject: "We miss you at {{company}}",
      preheader: "Come back and see what's new",
      fromName: "{{company}} Team",
      components: [
        {
          id: "miss-you-header",
          type: "header",
          content: {
            title: "We Miss You!",
            subtitle: "Come back and see what's new"
          },
          styles: {
            backgroundColor: "#e91e63",
            color: "#ffffff",
            padding: "40px 20px",
            textAlign: "center"
          }
        },
        {
          id: "personal-message",
          type: "text",
          content: {
            html: "<p>Hi {{first_name}},</p><p>It's been a while since we've seen you at {{company}}. We've missed having you as part of our community!</p>"
          },
          styles: {
            padding: "20px",
            fontSize: "16px"
          }
        },
        {
          id: "whats-new",
          type: "text",
          content: {
            html: "<h3>Here's what you've missed:</h3>"
          },
          styles: {
            padding: "20px 20px 0 20px"
          }
        },
        {
          id: "updates-list",
          type: "list",
          content: {
            items: [
              { text: "🆕 Brand new features and improvements" },
              { text: "📚 Fresh content and resources" },
              { text: "🎉 Exclusive member benefits" },
              { text: "💬 Vibrant community discussions" }
            ]
          },
          styles: {
            padding: "0 20px 20px 20px"
          }
        },
        {
          id: "comeback-offer",
          type: "text",
          content: {
            html: "<div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;'><h3 style='margin: 0 0 10px 0;'>Welcome Back Offer!</h3><p style='margin: 0; font-size: 18px;'>Get 30% off your next purchase</p><p style='margin: 5px 0 0 0; font-size: 14px;'>Use code: WELCOME30</p></div>"
          },
          styles: {
            padding: "20px"
          }
        },
        {
          id: "comeback-button",
          type: "button",
          content: {
            text: "Welcome Me Back",
            url: "{{reactivation_url}}"
          },
          styles: {
            backgroundColor: "#28a745",
            color: "#ffffff",
            padding: "15px 30px",
            borderRadius: "6px",
            fontSize: "18px",
            fontWeight: "bold"
          }
        },
        {
          id: "unsubscribe-option",
          type: "text",
          content: {
            html: "<p style='font-size: 12px; color: #6c757d;'>Not interested anymore? <a href='{{unsubscribe_url}}' style='color: #6c757d;'>Unsubscribe here</a></p>"
          },
          styles: {
            padding: "20px",
            textAlign: "center"
          }
        }
      ],
      globalStyles: {
        backgroundColor: "#f8f9fa",
        fontFamily: "Arial, sans-serif",
        fontSize: "16px",
        color: "#333333",
        maxWidth: "600px"
      }
    };
  }

  // Generate template thumbnail (simplified - would use screenshot service in production)
  private async generateTemplateThumbnail(content: EnhancedEmailContent): Promise<string> {
    // Generate a simple SVG thumbnail based on the template structure
    const components = content.components || [];
    const hasHeader = components.some(c => c.type === 'header');
    const hasImage = components.some(c => c.type === 'image');
    const hasButton = components.some(c => c.type === 'button');
    
    const svgContent = `
      <svg width="150" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="150" height="200" fill="${content.globalStyles?.backgroundColor || '#ffffff'}" stroke="#ddd" stroke-width="1"/>
        ${hasHeader ? '<rect x="10" y="10" width="130" height="30" fill="#007bff" rx="2"/>' : ''}
        ${hasImage ? '<rect x="10" y="50" width="130" height="60" fill="#f8f9fa" stroke="#ddd" rx="2"/>' : ''}
        <rect x="10" y="120" width="130" height="8" fill="#e9ecef" rx="1"/>
        <rect x="10" y="135" width="100" height="8" fill="#e9ecef" rx="1"/>
        <rect x="10" y="150" width="120" height="8" fill="#e9ecef" rx="1"/>
        ${hasButton ? '<rect x="40" y="170" width="70" height="20" fill="#28a745" rx="3"/>' : ''}
      </svg>
    `;
    
    return `data:image/svg+xml;base64,${Buffer.from(svgContent).toString('base64')}`;
  }

  // Convert template to ESP format
  async convertTemplateForESP(templateId: number, platform: 'mailchimp' | 'klaviyo' | 'activecampaign' | 'convertkit'): Promise<string> {
    const template = await storage.getEmailTemplate(templateId);
    if (!template) {
      throw new Error('Template not found');
    }

    const content = template.content as EnhancedEmailContent;
    
    // Use the ESP integration service to convert
    const espIntegration = await import('./esp-integration');
    const service = espIntegration.espIntegrationService;
    
    switch (platform) {
      case 'mailchimp':
        return (service as any).convertComponentsToMailchimpHTML(content);
      case 'klaviyo':
        return (service as any).convertComponentsToKlaviyoHTML(content);
      case 'activecampaign':
        return (service as any).convertComponentsToActiveCampaignHTML(content);
      case 'convertkit':
        return (service as any).convertComponentsToConvertKitHTML(content);
      default:
        throw new Error('Unsupported ESP platform');
    }
  }
}

export const templateEngine = new TemplateEngine();