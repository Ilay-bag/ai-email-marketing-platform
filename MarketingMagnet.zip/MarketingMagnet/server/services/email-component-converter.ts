import { EmailContent } from "@shared/schema";
import { v4 as uuidv4 } from 'uuid';

// Email builder component structure
interface EmailBuilderComponent {
  id: string;
  type: string;
  content: any;
  styles: Record<string, any>;
}

/**
 * Converts AI-generated EmailContent into modular email builder components
 * Each section becomes a separate, editable block
 */
export function convertEmailContentToComponents(emailContent: EmailContent): {
  components: EmailBuilderComponent[];
  subject: string;
  globalStyles: any;
} {
  const components: EmailBuilderComponent[] = [];

  // 1. Header Component
  if (emailContent.header?.title) {
    const headerComponent: EmailBuilderComponent = {
      id: uuidv4(),
      type: 'header',
      content: {
        title: emailContent.header.title,
        subtitle: emailContent.header.subtitle || '',
      },
      styles: {
        backgroundColor: emailContent.header.backgroundColor || '#3B82F6',
        color: '#ffffff',
        padding: '32px 24px',
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: '28px',
        lineHeight: '1.2',
      },
    };
    components.push(headerComponent);
  }

  // 2. Hero Image Component (if exists)
  if (emailContent.header?.image) {
    const imageComponent: EmailBuilderComponent = {
      id: uuidv4(),
      type: 'image',
      content: {
        src: emailContent.header.image,
        alt: emailContent.header.title || 'Hero Image',
        url: emailContent.cta?.url || '',
      },
      styles: {
        width: '100%',
        maxWidth: '600px',
        height: 'auto',
        margin: '0 auto',
        display: 'block',
      },
    };
    components.push(imageComponent);
  }

  // 3. Body Content Components
  if (emailContent.body?.sections) {
    emailContent.body.sections.forEach((section, index) => {
      switch (section.type) {
        case 'text':
          const textComponent: EmailBuilderComponent = {
            id: uuidv4(),
            type: 'text',
            content: {
              text: section.content,
              html: section.content,
            },
            styles: {
              padding: '16px 24px',
              fontSize: '16px',
              lineHeight: '1.6',
              color: '#374151',
              fontFamily: 'Arial, sans-serif',
            },
          };
          components.push(textComponent);
          break;

        case 'features':
          const featuresComponent: EmailBuilderComponent = {
            id: uuidv4(),
            type: 'list',
            content: {
              items: Array.isArray(section.content) 
                ? section.content.map(item => ({ text: item }))
                : [{ text: section.content }],
              listType: 'bullet',
            },
            styles: {
              padding: '16px 24px',
              fontSize: '16px',
              lineHeight: '1.8',
              color: '#374151',
              fontFamily: 'Arial, sans-serif',
            },
          };
          components.push(featuresComponent);
          break;

        case 'image':
          const sectionImageComponent: EmailBuilderComponent = {
            id: uuidv4(),
            type: 'image',
            content: {
              src: section.content,
              alt: `Image ${index + 1}`,
              url: '',
            },
            styles: {
              width: '100%',
              maxWidth: '500px',
              height: 'auto',
              margin: '16px auto',
              display: 'block',
              padding: '0 24px',
            },
          };
          components.push(sectionImageComponent);
          break;

        case 'button':
          const buttonComponent: EmailBuilderComponent = {
            id: uuidv4(),
            type: 'button',
            content: {
              text: section.content.text || section.content,
              url: section.content.url || emailContent.cta?.url || '#',
            },
            styles: {
              backgroundColor: section.content.backgroundColor || emailContent.cta?.backgroundColor || '#10B981',
              color: '#ffffff',
              padding: '12px 32px',
              fontSize: '16px',
              fontWeight: 'bold',
              textDecoration: 'none',
              borderRadius: '6px',
              display: 'inline-block',
              margin: '24px auto',
              textAlign: 'center',
            },
          };
          components.push(buttonComponent);
          break;

        default:
          // Fallback: treat as text
          const fallbackComponent: EmailBuilderComponent = {
            id: uuidv4(),
            type: 'text',
            content: {
              text: typeof section.content === 'string' ? section.content : JSON.stringify(section.content),
              html: typeof section.content === 'string' ? section.content : JSON.stringify(section.content),
            },
            styles: {
              padding: '16px 24px',
              fontSize: '16px',
              lineHeight: '1.6',
              color: '#374151',
              fontFamily: 'Arial, sans-serif',
            },
          };
          components.push(fallbackComponent);
      }
    });
  }

  // 4. Call-to-Action Component
  if (emailContent.cta?.text) {
    const ctaComponent: EmailBuilderComponent = {
      id: uuidv4(),
      type: 'button',
      content: {
        text: emailContent.cta.text,
        url: emailContent.cta.url || '#',
      },
      styles: {
        backgroundColor: emailContent.cta.backgroundColor || '#10B981',
        color: '#ffffff',
        padding: '16px 40px',
        fontSize: '18px',
        fontWeight: 'bold',
        textDecoration: 'none',
        borderRadius: '8px',
        display: 'inline-block',
        margin: '32px auto',
        textAlign: 'center',
        width: '100%',
        maxWidth: '250px',
      },
    };
    components.push(ctaComponent);
  }

  // 5. Footer Component
  const footerComponent: EmailBuilderComponent = {
    id: uuidv4(),
    type: 'footer',
    content: {
      text: 'Thank you for being part of our community!',
      unsubscribeText: 'Unsubscribe',
      unsubscribeUrl: '#unsubscribe',
      companyInfo: '{{company}} | {{address}}',
    },
    styles: {
      backgroundColor: '#f9fafb',
      color: '#6b7280',
      padding: '24px',
      fontSize: '14px',
      textAlign: 'center',
      borderTop: '1px solid #e5e7eb',
    },
  };
  components.push(footerComponent);

  return {
    components,
    subject: emailContent.subject,
    globalStyles: {
      backgroundColor: '#ffffff',
      fontFamily: 'Arial, Helvetica, sans-serif',
      fontSize: '16px',
      color: '#374151',
      maxWidth: '600px',
    },
  };
}



/**
 * Converts email builder components back to HTML for email sending
 */
export function convertComponentsToHTML(components: EmailBuilderComponent[], globalStyles: any): string {
  const componentHTML = components.map(component => {
    const styles = { ...component.styles };
    const styleString = Object.entries(styles)
      .map(([key, value]) => `${key.replace(/([A-Z])/g, '-$1').toLowerCase()}: ${value}`)
      .join('; ');

    switch (component.type) {
      case 'header':
        return `
          <div style="${styleString}">
            <h1 style="margin: 0; font-size: inherit; font-weight: inherit;">
              ${component.content.title}
            </h1>
            ${component.content.subtitle ? `
              <p style="margin: 8px 0 0 0; font-size: 18px; opacity: 0.9;">
                ${component.content.subtitle}
              </p>
            ` : ''}
          </div>
        `;

      case 'text':
        return `
          <div style="${styleString}">
            ${component.content.html || component.content.text}
          </div>
        `;

      case 'image':
        return `
          <div style="text-align: center; ${styleString}">
            <img src="${component.content.src}" 
                 alt="${component.content.alt || ''}" 
                 style="max-width: 100%; height: auto; display: block; margin: 0 auto;"
                 ${component.content.url ? `onclick="window.open('${component.content.url}')"` : ''} />
          </div>
        `;

      case 'button':
        return `
          <div style="text-align: center; padding: 24px;">
            <a href="${component.content.url || '#'}" 
               style="${styleString}; border: none; cursor: pointer;">
              ${component.content.text}
            </a>
          </div>
        `;

      case 'list':
        const listItems = component.content.items?.map((item: any) => 
          `<li style="margin: 8px 0;">${item.text}</li>`
        ).join('') || '';
        
        return `
          <div style="${styleString}">
            <ul style="margin: 0; padding-left: 24px;">
              ${listItems}
            </ul>
          </div>
        `;

      case 'footer':
        return `
          <div style="${styleString}">
            <p style="margin: 0 0 16px 0;">${component.content.text}</p>
            <p style="margin: 0; font-size: 12px;">
              ${component.content.companyInfo}
            </p>
            <p style="margin: 8px 0 0 0; font-size: 12px;">
              <a href="${component.content.unsubscribeUrl || '#'}" 
                 style="color: inherit; text-decoration: underline;">
                ${component.content.unsubscribeText || 'Unsubscribe'}
              </a>
            </p>
          </div>
        `;

      default:
        return `<div style="${styleString}">${component.content.text || component.content.html || ''}</div>`;
    }
  }).join('');

  // Wrap in complete HTML email structure
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Email</title>
      <style>
        body { 
          margin: 0; 
          padding: 0; 
          font-family: ${globalStyles.fontFamily}; 
          font-size: ${globalStyles.fontSize}; 
          color: ${globalStyles.color}; 
          background-color: #f5f5f5;
        }
        .email-container { 
          max-width: ${globalStyles.maxWidth}; 
          margin: 0 auto; 
          background-color: ${globalStyles.backgroundColor}; 
        }
      </style>
    </head>
    <body>
      <div class="email-container">
        ${componentHTML}
      </div>
    </body>
    </html>
  `;
}
export function generateModularEmailPrompt(originalPrompt: string, isHebrew: boolean = false): string {
  const languageContext = isHebrew ? 
    `התחשב שהתוכן יהיה בעברית. השתמש בסגנון כתיבה ישראלי טבעי ומקצועי.` :
    `Write in clear, professional English appropriate for the target audience.`;

  const analysisPrompt = `
${languageContext}

ENHANCED CONTEXT ANALYSIS:
Before creating the email, analyze these aspects of the request:

1. BUSINESS TYPE DETECTION:
   - E-commerce, SaaS, Professional Services, Non-profit, etc.
   - Industry-specific messaging and tone requirements

2. CAMPAIGN PURPOSE IDENTIFICATION:
   - Welcome/Onboarding, Promotional, Educational, Re-engagement
   - Transactional, Seasonal, Event-based, Lifecycle marketing

3. AUDIENCE ANALYSIS:
   - Demographics (age, location, profession)
   - Psychographics (interests, values, pain points)
   - Customer journey stage (awareness, consideration, decision, retention)

4. TONE & BRAND VOICE:
   - Professional vs. Casual vs. Friendly vs. Authoritative
   - Formal vs. Conversational language
   - Emotional tone (excited, urgent, helpful, reassuring)

5. CONVERSION GOALS:
   - Primary action desired (purchase, sign-up, download, visit)
   - Secondary goals (brand awareness, education, engagement)

ORIGINAL REQUEST: ${originalPrompt}

Based on this analysis, create a high-converting email that addresses the specific context identified.

QUALITY REQUIREMENTS:
- Subject line must create curiosity or immediate value (test 3 variations)
- Opening must hook the reader within first 2 sentences
- Value proposition must be crystal clear and benefit-focused
- Social proof elements when relevant (testimonials, stats, urgency)
- Clear, action-oriented CTA that stands out visually
- Mobile-optimized design with proper spacing and typography
- Personalization opportunities beyond just {{first_name}}
- Email copy should follow proven frameworks (AIDA, PAS, Problem-Solution)

PERSONALIZATION CONTEXT:
Include merge tags for relevant personalization:
- {{first_name}}, {{last_name}} for personal touch
- {{company}} for B2B communications  
- {{product_name}} for product-specific messaging
- {{location}} for geo-targeted content
- {{last_purchase}} for post-purchase flows
- {{engagement_score}} for segmented messaging

Make every element work together to drive the desired action with production-ready quality.`;

  return analysisPrompt;
}
