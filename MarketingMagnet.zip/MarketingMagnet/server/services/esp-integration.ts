import { EnhancedEmailContent, Contact, EmailList, CampaignAnalytics } from "@shared/schema";
import { oauthService } from "./oauth";

// Enhanced ESP Integration Service supporting major platforms
export class ESPIntegrationService {
  
  // Mailchimp API Integration
  async createMailchimpCampaign(
    accessToken: string,
    emailContent: EnhancedEmailContent,
    listId: string,
    settings: any = {}
  ) {
    const baseUrl = await this.getMailchimpApiUrl(accessToken);
    
    const campaign = {
      type: 'regular',
      recipients: {
        list_id: listId,
        segment_opts: settings.segment || {}
      },
      settings: {
        subject_line: emailContent.subject,
        preview_text: emailContent.preheader || '',
        title: settings.campaignName || emailContent.subject,
        from_name: emailContent.fromName || 'Your Company',
        reply_to: emailContent.replyTo || 'noreply@yourcompany.com',
        auto_footer: false,
        inline_css: true,
        ...settings.campaignSettings
      },
      tracking: {
        opens: true,
        html_clicks: true,
        text_clicks: true,
        goal_tracking: false,
        ecomm360: true,
        google_analytics: emailContent.utmParams?.source || '',
        clicktale: ''
      }
    };

    const response = await fetch(`${baseUrl}/campaigns`, {
      method: 'POST',
      headers: {
        'Authorization': `OAuth ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(campaign)
    });

    if (!response.ok) {
      throw new Error(`Mailchimp API error: ${response.statusText}`);
    }

    const campaignData = await response.json();
    
    // Set campaign content
    const htmlContent = this.convertComponentsToMailchimpHTML(emailContent);
    await this.setMailchimpCampaignContent(accessToken, campaignData.id, htmlContent);
    
    return campaignData;
  }

  async createKlaviyoCampaign(
    accessToken: string,
    emailContent: EnhancedEmailContent,
    listId: string,
    settings: any = {}
  ) {
    const campaign = {
      data: {
        type: 'campaign',
        attributes: {
          name: settings.campaignName || emailContent.subject,
          subject: emailContent.subject,
          from_email: emailContent.replyTo || 'noreply@yourcompany.com',
          from_label: emailContent.fromName || 'Your Company',
          template_id: null,
          status: 'draft'
        },
        relationships: {
          lists: {
            data: [{ type: 'list', id: listId }]
          }
        }
      }
    };

    const response = await fetch('https://a.klaviyo.com/api/campaigns/', {
      method: 'POST',
      headers: {
        'Authorization': `Klaviyo-API-Key ${accessToken}`,
        'Content-Type': 'application/json',
        'revision': '2024-05-15'
      },
      body: JSON.stringify(campaign)
    });

    if (!response.ok) {
      throw new Error(`Klaviyo API error: ${response.statusText}`);
    }

    const campaignData = await response.json();
    
    // Set campaign template content
    const htmlContent = this.convertComponentsToKlaviyoHTML(emailContent);
    await this.setKlaviyoCampaignContent(accessToken, campaignData.data.id, htmlContent);
    
    return campaignData;
  }

  // ActiveCampaign Integration
  async createActiveCampaignCampaign(
    accessToken: string,
    emailContent: EnhancedEmailContent,
    listIds: string[],
    settings: any = {}
  ) {
    const campaign = {
      campaign: {
        type: 'single',
        name: settings.campaignName || emailContent.subject,
        subject: emailContent.subject,
        fromname: emailContent.fromName || 'Your Company',
        fromemail: emailContent.replyTo || 'noreply@yourcompany.com',
        reply2: emailContent.replyTo || 'noreply@yourcompany.com',
        format: 'html',
        htmlcontent: this.convertComponentsToActiveCampaignHTML(emailContent),
        textcontent: this.extractTextFromComponents(emailContent.components),
        status: 0, // Draft
        public: 1,
        tracklinks: 'all',
        trackreads: 1,
        analytics_campaign_name: emailContent.utmParams?.campaign || '',
        track_linkclicks: 1,
        track_reads: 1,
        segmentid: 0,
        bounceid: -1,
        realcid: 0,
        waitpreview: 0
      }
    };

    const response = await fetch(`${settings.apiUrl}/api/3/campaigns`, {
      method: 'POST',
      headers: {
        'Api-Token': accessToken,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(campaign)
    });

    if (!response.ok) {
      throw new Error(`ActiveCampaign API error: ${response.statusText}`);
    }

    return await response.json();
  }

  // ConvertKit Integration
  async createConvertKitBroadcast(
    apiKey: string,
    emailContent: EnhancedEmailContent,
    settings: any = {}
  ) {
    const broadcast = {
      email_address: emailContent.replyTo || 'noreply@yourcompany.com',
      name: emailContent.fromName || 'Your Company',
      subject: emailContent.subject,
      content: this.convertComponentsToConvertKitHTML(emailContent),
      description: settings.description || emailContent.preheader || '',
      public: false
    };

    const response = await fetch(`https://api.convertkit.com/v3/broadcasts?api_key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(broadcast)
    });

    if (!response.ok) {
      throw new Error(`ConvertKit API error: ${response.statusText}`);
    }

    return await response.json();
  }

  // Utility: Get Mailchimp API URL
  private async getMailchimpApiUrl(accessToken: string): Promise<string> {
    const response = await fetch('https://login.mailchimp.com/oauth2/metadata', {
      headers: {
        'Authorization': `OAuth ${accessToken}`
      }
    });
    
    const metadata = await response.json();
    return metadata.api_endpoint;
  }

  // Utility: Set Mailchimp campaign content
  private async setMailchimpCampaignContent(
    accessToken: string,
    campaignId: string,
    htmlContent: string
  ) {
    const baseUrl = await this.getMailchimpApiUrl(accessToken);
    
    const content = {
      html: htmlContent
    };

    const response = await fetch(`${baseUrl}/campaigns/${campaignId}/content`, {
      method: 'PUT',
      headers: {
        'Authorization': `OAuth ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(content)
    });

    if (!response.ok) {
      throw new Error(`Mailchimp content update error: ${response.statusText}`);
    }

    return await response.json();
  }

  // Utility: Set Klaviyo campaign content
  private async setKlaviyoCampaignContent(
    accessToken: string,
    campaignId: string,
    htmlContent: string
  ) {
    const template = {
      data: {
        type: 'template',
        attributes: {
          name: `Template_${campaignId}`,
          editor_type: 'SYSTEM',
          html: htmlContent,
          text: this.stripHtmlTags(htmlContent)
        }
      }
    };

    // Create template first
    const templateResponse = await fetch('https://a.klaviyo.com/api/templates/', {
      method: 'POST',
      headers: {
        'Authorization': `Klaviyo-API-Key ${accessToken}`,
        'Content-Type': 'application/json',
        'revision': '2024-05-15'
      },
      body: JSON.stringify(template)
    });

    if (!templateResponse.ok) {
      throw new Error(`Klaviyo template creation error: ${templateResponse.statusText}`);
    }

    const templateData = await templateResponse.json();

    // Assign template to campaign
    const assignTemplate = {
      data: {
        type: 'campaign',
        id: campaignId,
        attributes: {
          template_id: templateData.data.id
        }
      }
    };

    const assignResponse = await fetch(`https://a.klaviyo.com/api/campaigns/${campaignId}/`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Klaviyo-API-Key ${accessToken}`,
        'Content-Type': 'application/json',
        'revision': '2024-05-15'
      },
      body: JSON.stringify(assignTemplate)
    });

    if (!assignResponse.ok) {
      throw new Error(`Klaviyo template assignment error: ${assignResponse.statusText}`);
    }

    return await assignResponse.json();
  }

  // HTML Conversion for different ESPs
  private convertComponentsToMailchimpHTML(emailContent: EnhancedEmailContent): string {
    let html = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${emailContent.subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: ${emailContent.globalStyles.backgroundColor}; font-family: ${emailContent.globalStyles.fontFamily};">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td align="center">
                <table width="${emailContent.globalStyles.maxWidth}" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff;">`;

    emailContent.components.forEach(component => {
      html += this.renderComponentToHTML(component, 'mailchimp');
    });

    html += `</table>
            </td>
        </tr>
    </table>
    <!-- Mailchimp Merge Tags -->
    <div style="display: none;">
        *|IF:REWARDS|* *|REWARDS_TEXT|* *|END:IF|*
        *|LIST:DESCRIPTION|*
        *|UNSUB|*
        *|UPDATE_PROFILE|*
        *|FORWARD|*
    </div>
</body>
</html>`;

    return html;
  }

  private convertComponentsToKlaviyoHTML(emailContent: EnhancedEmailContent): string {
    let html = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${emailContent.subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: ${emailContent.globalStyles.backgroundColor}; font-family: ${emailContent.globalStyles.fontFamily};">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td align="center">
                <table width="${emailContent.globalStyles.maxWidth}" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff;">`;

    emailContent.components.forEach(component => {
      html += this.renderComponentToHTML(component, 'klaviyo');
    });

    html += `</table>
            </td>
        </tr>
    </table>
    <!-- Klaviyo Unsubscribe -->
    {% unsubscribe_link 'Unsubscribe' %}
</body>
</html>`;

    return html;
  }

  private convertComponentsToActiveCampaignHTML(emailContent: EnhancedEmailContent): string {
    let html = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${emailContent.subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: ${emailContent.globalStyles.backgroundColor}; font-family: ${emailContent.globalStyles.fontFamily};">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td align="center">
                <table width="${emailContent.globalStyles.maxWidth}" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff;">`;

    emailContent.components.forEach(component => {
      html += this.renderComponentToHTML(component, 'activecampaign');
    });

    html += `</table>
            </td>
        </tr>
    </table>
    <!-- ActiveCampaign Merge Tags -->
    <p style="font-size: 12px; text-align: center; color: #666;">
        %UNSUBSCRIBELINK% | %UPDATEPROFILELINK%
    </p>
</body>
</html>`;

    return html;
  }

  private convertComponentsToConvertKitHTML(emailContent: EnhancedEmailContent): string {
    let html = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${emailContent.subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: ${emailContent.globalStyles.backgroundColor}; font-family: ${emailContent.globalStyles.fontFamily};">
    <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td align="center">
                <table width="${emailContent.globalStyles.maxWidth}" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff;">`;

    emailContent.components.forEach(component => {
      html += this.renderComponentToHTML(component, 'convertkit');
    });

    html += `</table>
            </td>
        </tr>
    </table>
    <!-- ConvertKit Unsubscribe -->
    {{ unsubscribe_link }}
</body>
</html>`;

    return html;
  }

  private renderComponentToHTML(component: any, platform: string): string {
    const styles = component.styles || {};
    const styleString = Object.entries(styles)
      .map(([key, value]) => `${key.replace(/([A-Z])/g, '-$1').toLowerCase()}: ${value}`)
      .join('; ');

    switch (component.type) {
      case 'header':
        return `
          <tr>
            <td style="${styleString}">
              <h1 style="margin: 0; font-size: 28px; font-weight: bold;">
                ${this.addPersonalization(component.content.title, platform)}
              </h1>
              ${component.content.subtitle ? `
                <p style="margin: 8px 0 0 0; font-size: 18px; opacity: 0.9;">
                  ${this.addPersonalization(component.content.subtitle, platform)}
                </p>
              ` : ''}
            </td>
          </tr>
        `;

      case 'text':
        return `
          <tr>
            <td style="${styleString}">
              ${this.addPersonalization(component.content.html || component.content.text, platform)}
            </td>
          </tr>
        `;

      case 'button':
        return `
          <tr>
            <td style="text-align: center; padding: 24px;">
              <a href="${component.content.url || '#'}" 
                 style="${styleString}; text-decoration: none; display: inline-block;"
                 ${this.addUTMTracking(component.content.url, platform)}>
                ${component.content.text}
              </a>
            </td>
          </tr>
        `;

      case 'image':
        return `
          <tr>
            <td style="text-align: center; ${styleString}">
              <img src="${component.content.src}" 
                   alt="${component.content.alt || ''}" 
                   style="max-width: 100%; height: auto; display: block; margin: 0 auto;" />
            </td>
          </tr>
        `;

      case 'list':
        const listItems = component.content.items?.map((item: any) => 
          `<li style="margin: 8px 0;">${this.addPersonalization(item.text, platform)}</li>`
        ).join('') || '';
        
        return `
          <tr>
            <td style="${styleString}">
              <ul style="margin: 0; padding-left: 24px;">
                ${listItems}
              </ul>
            </td>
          </tr>
        `;

      case 'footer':
        return `
          <tr>
            <td style="${styleString}">
              <p style="margin: 0 0 16px 0;">
                ${this.addPersonalization(component.content.text, platform)}
              </p>
              <p style="margin: 0; font-size: 12px;">
                ${this.addPersonalization(component.content.companyInfo || '{{company}} | {{address}}', platform)}
              </p>
              ${this.getUnsubscribeLink(platform)}
            </td>
          </tr>
        `;

      default:
        return `
          <tr>
            <td style="${styleString}">
              ${component.content.text || component.content.html || ''}
            </td>
          </tr>
        `;
    }
  }

  private addPersonalization(content: string, platform: string): string {
    const mergeTags: Record<string, Record<string, string>> = {
      mailchimp: {
        '{{first_name}}': '*|FNAME|*',
        '{{last_name}}': '*|LNAME|*',
        '{{email}}': '*|EMAIL|*',
        '{{company}}': '*|COMPANY|*',
        '{{address}}': '*|LIST:ADDRESS|*'
      },
      klaviyo: {
        '{{first_name}}': '{{ person.first_name|default:"there" }}',
        '{{last_name}}': '{{ person.last_name }}',
        '{{email}}': '{{ person.email }}',
        '{{company}}': '{{ person.organization }}',
        '{{address}}': '{{ organization.address }}'
      },
      activecampaign: {
        '{{first_name}}': '%FIRSTNAME%',
        '{{last_name}}': '%LASTNAME%',
        '{{email}}': '%EMAIL%',
        '{{company}}': '%COMPANY%',
        '{{address}}': '%ADDRESS%'
      },
      convertkit: {
        '{{first_name}}': '{{ subscriber.first_name }}',
        '{{last_name}}': '{{ subscriber.last_name }}',
        '{{email}}': '{{ subscriber.email_address }}',
        '{{company}}': '{{ subscriber.company }}',
        '{{address}}': '{{ subscriber.address }}'
      }
    };

    let processedContent = content;
    const platformTags = mergeTags[platform] || {};
    
    Object.entries(platformTags).forEach(([generic, specific]) => {
      processedContent = processedContent.replace(new RegExp(generic.replace(/[{}]/g, '\\$&'), 'g'), specific);
    });

    return processedContent;
  }

  private addUTMTracking(url: string, platform: string): string {
    if (!url || url === '#') return '';
    
    // Add platform-specific tracking
    const trackingParams = {
      utm_source: platform,
      utm_medium: 'email',
      utm_campaign: 'auto_generated'
    };
    
    const separator = url.includes('?') ? '&' : '?';
    const utmString = Object.entries(trackingParams)
      .map(([key, value]) => `${key}=${encodeURIComponent(value)}`)
      .join('&');
      
    return `data-tracked-url="${url}${separator}${utmString}"`;
  }

  private getUnsubscribeLink(platform: string): string {
    const unsubscribeLinks = {
      mailchimp: '<p style="margin: 8px 0 0 0; font-size: 12px;"><a href="*|UNSUB|*" style="color: inherit;">Unsubscribe</a></p>',
      klaviyo: '<p style="margin: 8px 0 0 0; font-size: 12px;">{% unsubscribe_link "Unsubscribe" %}</p>',
      activecampaign: '<p style="margin: 8px 0 0 0; font-size: 12px;"><a href="%UNSUBSCRIBELINK%" style="color: inherit;">Unsubscribe</a></p>',
      convertkit: '<p style="margin: 8px 0 0 0; font-size: 12px;">{{ unsubscribe_link }}</p>'
    };
    
    return unsubscribeLinks[platform] || '<p style="margin: 8px 0 0 0; font-size: 12px;"><a href="#unsubscribe" style="color: inherit;">Unsubscribe</a></p>';
  }

  private extractTextFromComponents(components: any[]): string {
    return components.map(component => {
      switch (component.type) {
        case 'header':
          return `${component.content.title}\n${component.content.subtitle || ''}`;
        case 'text':
          return this.stripHtmlTags(component.content.text || component.content.html || '');
        case 'button':
          return `${component.content.text}: ${component.content.url || ''}`;
        case 'list':
          return component.content.items?.map((item: any) => `• ${item.text}`).join('\n') || '';
        case 'footer':
          return component.content.text || '';
        default:
          return '';
      }
    }).filter(text => text.trim()).join('\n\n');
  }

  private stripHtmlTags(html: string): string {
    return html.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
  }
}

export const espIntegrationService = new ESPIntegrationService();