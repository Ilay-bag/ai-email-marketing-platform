import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

export interface KlaviyoEmailModule {
  type: string;
  settings: any;
  content?: any;
  styling?: any;
}

export interface KlaviyoEmailDesign {
  subject: string;
  preheader?: string;
  modules: KlaviyoEmailModule[];
  globalSettings: {
    backgroundColor: string;
    contentWidth: number;
    fontFamily: string;
    fontSize: number;
    lineHeight: number;
    textColor: string;
    linkColor: string;
    padding: {
      top: number;
      bottom: number;
      left: number;
      right: number;
    };
  };
  personalization: {
    firstNameTag: string;
    locationTag: string;
    customFields: string[];
  };
  utmParameters: {
    source: string;
    medium: string;
    campaign: string;
  };
}

export interface UnlayerDesign {
  displayMode: string;
  counters: {
    u_column: number;
    u_row: number;
    u_content_text: number;
    u_content_image: number;
    u_content_button: number;
    u_content_divider: number;
    u_content_html: number;
    u_content_video: number;
    u_content_social: number;
  };
  body: {
    id: string;
    rows: UnlayerRow[];
    values: {
      backgroundColor: string;
      backgroundImage: {
        url: string;
        fullWidth: boolean;
        repeat: string;
        size: string;
        position: string;
      };
      contentWidth: string;
      fontFamily: {
        label: string;
        value: string;
      };
      fontSize: string;
      textColor: string;
      linkColor: string;
      _meta: {
        htmlID: string;
        htmlClassNames: string;
      };
    };
  };
  schemaVersion: number;
}

export interface UnlayerRow {
  id: string;
  cells: number[];
  columns: UnlayerColumn[];
  values: {
    backgroundColor: string;
    backgroundImage: any;
    padding: string;
    anchor: string;
    hideDesktop: boolean;
    displayCondition: string;
    columnsBackgroundColor: string;
    _meta: {
      htmlID: string;
      htmlClassNames: string;
    };
  };
}

export interface UnlayerColumn {
  id: string;
  contents: UnlayerContent[];
  values: {
    backgroundColor: string;
    border: any;
    borderRadius: string;
    padding: string;
    _meta: {
      htmlID: string;
      htmlClassNames: string;
    };
  };
}

export interface UnlayerContent {
  id: string;
  type: string;
  values: any;
}

/**
 * Comprehensive Klaviyo Email Module System
 * 
 * SUPPORTED KLAVIYO EMAIL MODULES & FEATURES:
 * 
 * Basic Content Blocks:
 * - Text Block
 * - Image Block (single, full-width, side-by-side)
 * - Button Block (CTA)
 * - Divider / Spacer
 * - HTML & Code Block
 * - Video Block
 * - Social Links Block
 * - Columns (1-4 columns)
 * 
 * E-commerce & Dynamic Blocks:
 * - Product Recommendation Block (cross-sell, up-sell)
 * - Abandoned Cart Product List
 * - Dynamic Profile Data (first name, location, custom fields)
 * - Countdown Timer Block
 * - Promotion Banner / Announcement Bar
 * - Coupon Code Block
 * - Gift Box / Bundle Block
 * 
 * Styling & Layout Options:
 * - Background Color / Image for Section
 * - Padding, Margin, Border Radius, Shadows
 * - Custom Fonts & Font Sizes
 * - Text Alignment & Line Height
 * - Button Styles (color, padding, border)
 * - Section Settings (width, background image, overlay)
 * 
 * Advanced Features:
 * - A/B Test Variants
 * - Personalization Tags ({{ first_name }}, {{ product_name }})
 * - Conditional Display (show/hide blocks based on profile data)
 * - Template Variables & Snippets
 * - Link Tracking & UTM Parameters
 * - Preview in Desktop/Mobile
 * - Export to HTML / MJML
 */

const KLAVIYO_EMAIL_SYSTEM_PROMPT = `You are an expert email marketing AI that generates sophisticated email campaigns using Klaviyo's comprehensive email builder system. You must create emails that utilize ALL available Klaviyo modules and features.

KLAVIYO EMAIL MODULES YOU MUST SUPPORT:

**Basic Content Blocks:**
- Text Block: Rich text with formatting, personalization tags
- Image Block: Single, full-width, side-by-side configurations
- Button Block: CTA buttons with custom styling and tracking
- Divider/Spacer: Visual separators with custom styling
- HTML & Code Block: Custom HTML/CSS for advanced layouts
- Video Block: Embedded videos with thumbnails and play buttons
- Social Links Block: Social media icons with custom styling
- Columns: 1-4 column layouts with responsive design

**E-commerce & Dynamic Blocks:**
- Product Recommendation Block: Cross-sell, up-sell with dynamic product data
- Abandoned Cart Product List: Dynamic cart recovery with product details
- Dynamic Profile Data: {{ first_name }}, {{ location }}, custom fields
- Countdown Timer Block: Urgency timers for sales and promotions
- Promotion Banner: Announcement bars with dismissible options
- Coupon Code Block: Stylized discount codes with copy functionality
- Gift Box/Bundle Block: Product bundles with special styling

**Styling & Layout Options:**
- Background Color/Image for each section
- Padding, Margin, Border Radius, Box Shadows
- Custom Fonts & Font Sizes (Google Fonts, web-safe fonts)
- Text Alignment & Line Height controls
- Button Styles: colors, padding, borders, hover effects
- Section Settings: width constraints, background overlays

**Advanced Features:**
- A/B Test Variants: Multiple subject lines and content versions
- Personalization Tags: Dynamic content based on user profile
- Conditional Display: Show/hide blocks based on profile data
- Template Variables & Snippets: Reusable content blocks
- Link Tracking & UTM Parameters: Campaign tracking
- Responsive Design: Desktop/mobile optimization
- Export Options: HTML/MJML output

GENERATION REQUIREMENTS:
1. Always use personalization tags like {{ first_name }} and {{ last_name }}
2. Include at least 3-5 different module types per email
3. Apply consistent brand styling with custom colors and fonts
4. Include UTM parameters for all links
5. Use dynamic product recommendations when applicable
6. Add countdown timers for urgency
7. Include social proof elements
8. Optimize for mobile responsiveness
9. Use conditional display for personalization
10. Include A/B testing variants for key elements

OUTPUT FORMAT:
Provide a complete Klaviyo email design in JSON format that can be converted to Unlayer format for visual editing.`;

export async function generateKlaviyoEmail(prompt: string, businessType?: string, campaignType?: string): Promise<KlaviyoEmailDesign> {
  try {
    const enhancedPrompt = `${KLAVIYO_EMAIL_SYSTEM_PROMPT}

CAMPAIGN REQUEST: ${prompt}
BUSINESS TYPE: ${businessType || 'E-commerce'}
CAMPAIGN TYPE: ${campaignType || 'promotional'}

Generate a comprehensive Klaviyo email design that incorporates multiple module types, personalization, and advanced features. The email should be production-ready and optimized for conversions.

Respond with a complete JSON object following the KlaviyoEmailDesign interface.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: enhancedPrompt
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 4000
    });

    const emailDesign = JSON.parse(response.choices[0].message.content);
    
    // Validate and ensure required fields exist
    if (!emailDesign.subject) {
      emailDesign.subject = "Your Email Subject";
    }
    
    if (!emailDesign.modules || !Array.isArray(emailDesign.modules)) {
      emailDesign.modules = [];
    }
    
    if (!emailDesign.globalSettings) {
      emailDesign.globalSettings = {
        backgroundColor: "#f8f9fa",
        contentWidth: 600,
        fontFamily: "Arial, sans-serif",
        fontSize: 14,
        lineHeight: 1.5,
        textColor: "#333333",
        linkColor: "#007bff",
        padding: {
          top: 20,
          bottom: 20,
          left: 20,
          right: 20
        }
      };
    }
    
    if (!emailDesign.personalization) {
      emailDesign.personalization = {
        firstNameTag: "{{ first_name }}",
        locationTag: "{{ location }}",
        customFields: []
      };
    }
    
    if (!emailDesign.utmParameters) {
      emailDesign.utmParameters = {
        source: "klaviyo",
        medium: "email",
        campaign: campaignType || "promotional"
      };
    }
    
    return emailDesign;
  } catch (error) {
    console.error("Klaviyo email generation error:", error);
    throw new Error("Failed to generate Klaviyo email design");
  }
}

export function convertKlaviyoToUnlayer(klaviyoDesign: KlaviyoEmailDesign): UnlayerDesign {
  let counters = {
    u_column: 1,
    u_row: 1,
    u_content_text: 1,
    u_content_image: 1,
    u_content_button: 1,
    u_content_divider: 1,
    u_content_html: 1,
    u_content_video: 1,
    u_content_social: 1
  };

  const unlayerRows: UnlayerRow[] = [];

  // Convert each Klaviyo module to Unlayer format
  if (klaviyoDesign.modules && Array.isArray(klaviyoDesign.modules)) {
    klaviyoDesign.modules.forEach((module) => {
      const row = convertModuleToUnlayerRow(module, counters);
      unlayerRows.push(row);
    });
  }

  // Provide default values if globalSettings is missing
  const defaultGlobalSettings = {
    backgroundColor: "#f8f9fa",
    contentWidth: 600,
    fontFamily: "Arial, sans-serif",
    fontSize: 14,
    lineHeight: 1.5,
    textColor: "#333333",
    linkColor: "#007bff",
    padding: {
      top: 20,
      bottom: 20,
      left: 20,
      right: 20
    }
  };

  const globalSettings = klaviyoDesign.globalSettings || defaultGlobalSettings;

  const unlayerDesign: UnlayerDesign = {
    displayMode: "email",
    counters,
    body: {
      id: "body",
      rows: unlayerRows,
      values: {
        backgroundColor: globalSettings.backgroundColor,
        backgroundImage: {
          url: "",
          fullWidth: true,
          repeat: "no-repeat",
          size: "cover",
          position: "center"
        },
        contentWidth: `${globalSettings.contentWidth}px`,
        fontFamily: {
          label: globalSettings.fontFamily,
          value: globalSettings.fontFamily
        },
        fontSize: `${globalSettings.fontSize}px`,
        textColor: globalSettings.textColor,
        linkColor: globalSettings.linkColor,
        _meta: {
          htmlID: "u_body",
          htmlClassNames: ""
        }
      }
    },
    schemaVersion: 16
  };

  return unlayerDesign;
}

function convertModuleToUnlayerRow(module: KlaviyoEmailModule, counters: any): UnlayerRow {
  const rowId = `u_row_${counters.u_row++}`;
  const columnId = `u_column_${counters.u_column++}`;
  
  let unlayerContent: UnlayerContent;

  switch (module.type) {
    case 'text':
      unlayerContent = {
        id: `u_content_text_${counters.u_content_text++}`,
        type: 'text',
        values: {
          containerPadding: "20px",
          anchor: "",
          fontSize: module.styling?.fontSize || "14px",
          textAlign: module.styling?.textAlign || "left",
          lineHeight: module.styling?.lineHeight || "1.6",
          linkStyle: {
            inherit: true,
            linkColor: "#0000ee",
            linkHoverColor: "#0000ee",
            linkUnderline: true,
            linkHoverUnderline: true
          },
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null,
          text: module.content?.html || module.content?.text || ""
        }
      };
      break;

    case 'image':
      unlayerContent = {
        id: `u_content_image_${counters.u_content_image++}`,
        type: 'image',
        values: {
          containerPadding: "20px",
          anchor: "",
          src: {
            url: module.content?.src || "",
            width: module.settings?.width || 600,
            height: module.settings?.height || 400
          },
          textAlign: module.styling?.textAlign || "center",
          altText: module.content?.altText || "",
          linkStyle: {
            inherit: true,
            linkColor: "#0000ee",
            linkHoverColor: "#0000ee",
            linkUnderline: true,
            linkHoverUnderline: true
          },
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null
        }
      };
      break;

    case 'button':
      unlayerContent = {
        id: `u_content_button_${counters.u_content_button++}`,
        type: 'button',
        values: {
          containerPadding: "20px",
          anchor: "",
          href: {
            name: "web",
            values: {
              href: module.content?.href || "",
              target: "_blank"
            }
          },
          buttonColors: {
            color: module.styling?.textColor || "#FFFFFF",
            backgroundColor: module.styling?.backgroundColor || "#3AAEE0",
            hoverColor: "#FFFFFF",
            hoverBackgroundColor: "#3AAEE0"
          },
          size: {
            autoWidth: true,
            width: "100%"
          },
          fontSize: module.styling?.fontSize || "14px",
          textAlign: module.styling?.textAlign || "center",
          lineHeight: "120%",
          padding: module.styling?.padding || "15px 30px",
          border: module.styling?.border || {},
          borderRadius: module.styling?.borderRadius || "4px",
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null,
          text: module.content?.text || "Click Here"
        }
      };
      break;

    case 'divider':
      unlayerContent = {
        id: `u_content_divider_${counters.u_content_divider++}`,
        type: 'divider',
        values: {
          containerPadding: "20px",
          anchor: "",
          width: module.settings?.width || "100%",
          border: {
            borderTopWidth: module.styling?.height || "1px",
            borderTopStyle: "solid",
            borderTopColor: module.styling?.color || "#CCC"
          },
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null
        }
      };
      break;

    case 'html':
      unlayerContent = {
        id: `u_content_html_${counters.u_content_html++}`,
        type: 'html',
        values: {
          containerPadding: "20px",
          anchor: "",
          html: module.content?.html || "",
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null
        }
      };
      break;

    case 'video':
      unlayerContent = {
        id: `u_content_video_${counters.u_content_video++}`,
        type: 'video',
        values: {
          containerPadding: "20px",
          anchor: "",
          src: {
            url: module.content?.src || "",
            thumbnailUrl: module.content?.thumbnailUrl || ""
          },
          textAlign: module.styling?.textAlign || "center",
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null
        }
      };
      break;

    case 'social':
      unlayerContent = {
        id: `u_content_social_${counters.u_content_social++}`,
        type: 'social',
        values: {
          containerPadding: "20px",
          anchor: "",
          icons: {
            iconType: "circle",
            iconSize: 32,
            iconSpacing: 10
          },
          align: module.styling?.textAlign || "center",
          socialLinks: module.content?.links || [],
          hideDesktop: false,
          displayCondition: module.settings?.displayCondition || null
        }
      };
      break;

    default:
      unlayerContent = {
        id: `u_content_text_${counters.u_content_text++}`,
        type: 'text',
        values: {
          containerPadding: "20px",
          text: "<p>Unsupported module type</p>"
        }
      };
  }

  return {
    id: rowId,
    cells: [1],
    columns: [
      {
        id: columnId,
        contents: [unlayerContent],
        values: {
          backgroundColor: module.styling?.backgroundColor || "",
          border: module.styling?.border || {},
          borderRadius: module.styling?.borderRadius || "0px",
          padding: module.styling?.padding || "0px",
          _meta: {
            htmlID: columnId,
            htmlClassNames: ""
          }
        }
      }
    ],
    values: {
      backgroundColor: module.styling?.sectionBackgroundColor || "",
      backgroundImage: module.styling?.backgroundImage || {},
      padding: module.styling?.sectionPadding || "0px",
      anchor: "",
      hideDesktop: false,
      displayCondition: module.settings?.displayCondition || "",
      columnsBackgroundColor: "",
      _meta: {
        htmlID: rowId,
        htmlClassNames: ""
      }
    }
  };
}

export default {
  generateKlaviyoEmail,
  convertKlaviyoToUnlayer
};