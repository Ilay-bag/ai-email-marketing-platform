import { storage } from "../storage";
import type { Integration } from "@shared/schema";

export interface OAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  scopes: string[];
  authUrl: string;
  tokenUrl: string;
}

export interface OAuthTokenResponse {
  access_token: string;
  refresh_token?: string;
  expires_in?: number;
  token_type?: string;
  scope?: string;
}

export interface UserInfo {
  id: string;
  email: string;
  name?: string;
}

export class OAuthService {
  private configs: Record<string, OAuthConfig> = {
    mailchimp: {
      clientId: process.env.MAILCHIMP_CLIENT_ID || '',
      clientSecret: process.env.MAILCHIMP_CLIENT_SECRET || '',
      redirectUri: `${process.env.REPLIT_DOMAIN || 'http://localhost:5000'}/api/auth/mailchimp/callback`,
      scopes: ['read', 'write'],
      authUrl: 'https://login.mailchimp.com/oauth2/authorize',
      tokenUrl: 'https://login.mailchimp.com/oauth2/token'
    },
    klaviyo: {
      clientId: process.env.KLAVIYO_CLIENT_ID || '',
      clientSecret: process.env.KLAVIYO_CLIENT_SECRET || '',
      redirectUri: `${process.env.REPLIT_DOMAIN || 'http://localhost:5000'}/api/auth/klaviyo/callback`,
      scopes: ['read-only', 'write-only'],
      authUrl: 'https://a.klaviyo.com/oauth/authorize',
      tokenUrl: 'https://a.klaviyo.com/oauth/token'
    },
    shopify: {
      clientId: process.env.SHOPIFY_CLIENT_ID || '',
      clientSecret: process.env.SHOPIFY_CLIENT_SECRET || '',
      redirectUri: `${process.env.REPLIT_DOMAIN || 'http://localhost:5000'}/api/auth/shopify/callback`,
      scopes: ['read_products', 'read_customers', 'read_orders', 'write_customers'],
      authUrl: 'https://accounts.shopify.com/oauth/authorize',
      tokenUrl: 'https://accounts.shopify.com/oauth/token'
    },
    wix: {
      clientId: process.env.WIX_CLIENT_ID || '',
      clientSecret: process.env.WIX_CLIENT_SECRET || '',
      redirectUri: `${process.env.REPLIT_DOMAIN || 'http://localhost:5000'}/api/auth/wix/callback`,
      scopes: ['offline_access'],
      authUrl: 'https://www.wix.com/oauth/authorize',
      tokenUrl: 'https://www.wix.com/oauth/access_token'
    },
    wordpress: {
      clientId: process.env.WORDPRESS_CLIENT_ID || '',
      clientSecret: process.env.WORDPRESS_CLIENT_SECRET || '',
      redirectUri: `${process.env.REPLIT_DOMAIN || 'http://localhost:5000'}/api/auth/wordpress/callback`,
      scopes: ['read', 'write'],
      authUrl: 'https://public-api.wordpress.com/oauth2/authorize',
      tokenUrl: 'https://public-api.wordpress.com/oauth2/token'
    }
  };

  isConfigured(platform: string): boolean {
    const config = this.configs[platform];
    if (!config) {
      return false;
    }
    return config.clientId && config.clientSecret && config.clientId !== '' && config.clientSecret !== '';
  }

  generateAuthUrl(platform: string, userId: number): string {
    const config = this.configs[platform];
    if (!config) {
      throw new Error(`Unsupported platform: ${platform}`);
    }
    
    if (!this.isConfigured(platform)) {
      throw new Error(`OAuth not configured for ${platform}`);
    }

    const params = new URLSearchParams({
      client_id: config.clientId,
      redirect_uri: config.redirectUri,
      response_type: 'code',
      scope: config.scopes.join(' '),
      state: `${userId}:${platform}:${Date.now()}` // Include userId in state for security
    });

    return `${config.authUrl}?${params.toString()}`;
  }

  async exchangeCodeForToken(platform: string, code: string): Promise<OAuthTokenResponse> {
    const config = this.configs[platform];
    if (!config) {
      throw new Error(`Unsupported platform: ${platform}`);
    }

    const tokenPayload = {
      client_id: config.clientId,
      client_secret: config.clientSecret,
      code,
      grant_type: 'authorization_code',
      redirect_uri: config.redirectUri
    };

    const response = await fetch(config.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: new URLSearchParams(tokenPayload).toString()
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Token exchange failed: ${error}`);
    }

    return await response.json();
  }

  async refreshToken(platform: string, refreshToken: string): Promise<OAuthTokenResponse> {
    const config = this.configs[platform];
    if (!config) {
      throw new Error(`Unsupported platform: ${platform}`);
    }

    const tokenPayload = {
      client_id: config.clientId,
      client_secret: config.clientSecret,
      refresh_token: refreshToken,
      grant_type: 'refresh_token'
    };

    const response = await fetch(config.tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: new URLSearchParams(tokenPayload).toString()
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Token refresh failed: ${error}`);
    }

    return await response.json();
  }

  async getUserInfo(platform: string, accessToken: string): Promise<UserInfo> {
    // Platform-specific user info endpoints
    const userInfoUrls: Record<string, string> = {
      mailchimp: 'https://login.mailchimp.com/oauth2/metadata',
      klaviyo: 'https://a.klaviyo.com/api/account',
      shopify: 'https://shopify.dev/api/admin/rest/reference/store/shop',
      wix: 'https://www.wix.com/api/v1/user',
      wordpress: 'https://public-api.wordpress.com/rest/v1/me'
    };

    const url = userInfoUrls[platform];
    if (!url) {
      throw new Error(`User info not supported for platform: ${platform}`);
    }

    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch user info: ${response.statusText}`);
    }

    const data = await response.json();
    
    // Platform-specific response parsing
    switch (platform) {
      case 'mailchimp':
        return {
          id: data.accountname || data.user_id,
          email: data.email || data.login?.email,
          name: data.accountname
        };
      case 'klaviyo':
        return {
          id: data.account_id || data.id,
          email: data.contact_information?.default_sender_email || data.email,
          name: data.account_name || data.name
        };
      case 'shopify':
        return {
          id: data.shop?.id || data.id,
          email: data.shop?.email || data.email,
          name: data.shop?.name || data.name
        };
      case 'wix':
        return {
          id: data.user?.id || data.id,
          email: data.user?.email || data.email,
          name: data.user?.name || data.name
        };
      case 'wordpress':
        return {
          id: data.ID || data.id,
          email: data.email,
          name: data.display_name || data.username
        };
      default:
        return {
          id: data.id || data.user_id,
          email: data.email,
          name: data.name
        };
    }
  }

  async saveIntegration(
    userId: number,
    platform: string,
    tokenResponse: OAuthTokenResponse,
    userInfo: UserInfo
  ): Promise<Integration> {
    const expiresAt = tokenResponse.expires_in
      ? new Date(Date.now() + tokenResponse.expires_in * 1000)
      : null;

    // Check if integration already exists
    const existingIntegration = await storage.getIntegrationByProvider(userId, platform);
    
    if (existingIntegration) {
      // Update existing integration
      const updatedIntegration = await storage.updateIntegration(existingIntegration.id, {
        accessToken: tokenResponse.access_token,
        refreshToken: tokenResponse.refresh_token,
        expiresAt,
        accountEmail: userInfo.email,
        accountId: userInfo.id,
        isActive: true,
        connectedAt: new Date()
      });
      
      if (!updatedIntegration) {
        throw new Error('Failed to update integration');
      }
      
      return updatedIntegration;
    } else {
      // Create new integration
      return await storage.createIntegration({
        userId,
        provider: platform,
        accessToken: tokenResponse.access_token,
        refreshToken: tokenResponse.refresh_token,
        expiresAt,
        accountEmail: userInfo.email,
        accountId: userInfo.id,
        isActive: true
      });
    }
  }

  async isTokenExpired(integration: Integration): Promise<boolean> {
    if (!integration.expiresAt) return false;
    return new Date() >= new Date(integration.expiresAt);
  }

  async getValidToken(integration: Integration): Promise<string> {
    if (!integration.accessToken) {
      throw new Error('No access token available');
    }

    if (await this.isTokenExpired(integration)) {
      if (!integration.refreshToken) {
        throw new Error('Token expired and no refresh token available');
      }

      const tokenResponse = await this.refreshToken(integration.provider, integration.refreshToken);
      
      const expiresAt = tokenResponse.expires_in
        ? new Date(Date.now() + tokenResponse.expires_in * 1000)
        : null;

      await storage.updateIntegration(integration.id, {
        accessToken: tokenResponse.access_token,
        refreshToken: tokenResponse.refresh_token || integration.refreshToken,
        expiresAt
      });

      return tokenResponse.access_token;
    }

    return integration.accessToken;
  }
}

export const oauthService = new OAuthService();