import { storage } from "../storage";
import { Contact, EmailList, InsertContact, InsertEmailList } from "@shared/schema";

// Comprehensive Contact and List Management Service
export class ContactManagementService {
  
  // Contact Management
  async createContact(contactData: InsertContact): Promise<Contact> {
    // Validate email format
    if (!this.isValidEmail(contactData.email)) {
      throw new Error('Invalid email address');
    }

    // Check for existing contact
    const existingContact = await storage.getContactByEmail(contactData.userId, contactData.email);
    if (existingContact) {
      throw new Error('Contact with this email already exists');
    }

    // Create contact with engagement scoring
    const newContact = await storage.createContact({
      ...contactData,
      engagementScore: 0,
      lastActivityAt: new Date(),
      consentTimestamp: new Date()
    });

    return newContact;
  }

  async updateContact(contactId: number, updates: Partial<Contact>): Promise<Contact> {
    const contact = await storage.getContact(contactId);
    if (!contact) {
      throw new Error('Contact not found');
    }

    return await storage.updateContact(contactId, {
      ...updates,
      updatedAt: new Date()
    });
  }

  async importContacts(userId: number, contactsData: any[], listId?: number): Promise<{
    imported: number;
    errors: string[];
    duplicates: number;
  }> {
    const results = {
      imported: 0,
      errors: [] as string[],
      duplicates: 0
    };

    for (const contactData of contactsData) {
      try {
        // Validate required fields
        if (!contactData.email) {
          results.errors.push(`Row missing email: ${JSON.stringify(contactData)}`);
          continue;
        }

        if (!this.isValidEmail(contactData.email)) {
          results.errors.push(`Invalid email: ${contactData.email}`);
          continue;
        }

        // Check for existing contact
        const existingContact = await storage.getContactByEmail(userId, contactData.email);
        if (existingContact) {
          results.duplicates++;
          continue;
        }

        // Create contact
        const contact = await storage.createContact({
          userId,
          email: contactData.email,
          firstName: contactData.firstName || contactData.first_name || '',
          lastName: contactData.lastName || contactData.last_name || '',
          phone: contactData.phone || '',
          organization: contactData.organization || contactData.company || '',
          customFields: this.extractCustomFields(contactData),
          tags: contactData.tags || [],
          isSubscribed: contactData.isSubscribed !== false,
          consentTimestamp: new Date(),
          engagementScore: 0
        });

        // Add to list if specified
        if (listId && contact) {
          await storage.addContactToList(contact.id, listId);
        }

        results.imported++;
      } catch (error) {
        results.errors.push(`Error importing ${contactData.email}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }

    return results;
  }

  async addContactToList(contactId: number, listId: number): Promise<void> {
    const contact = await storage.getContact(contactId);
    const list = await storage.getEmailList(listId);
    
    if (!contact || !list) {
      throw new Error('Contact or list not found');
    }

    if (contact.userId !== list.userId) {
      throw new Error('Contact and list must belong to the same user');
    }

    await storage.addContactToList(contactId, listId);
    
    // Update list subscriber count
    await this.updateListSubscriberCount(listId);
  }

  async removeContactFromList(contactId: number, listId: number): Promise<void> {
    await storage.removeContactFromList(contactId, listId);
    await this.updateListSubscriberCount(listId);
  }

  async updateEngagementScore(contactId: number, action: 'open' | 'click' | 'unsubscribe' | 'bounce'): Promise<void> {
    const contact = await storage.getContact(contactId);
    if (!contact) return;

    let scoreChange = 0;
    switch (action) {
      case 'open':
        scoreChange = 1;
        break;
      case 'click':
        scoreChange = 5;
        break;
      case 'unsubscribe':
        scoreChange = -10;
        break;
      case 'bounce':
        scoreChange = -5;
        break;
    }

    const newScore = Math.max(0, Math.min(100, (contact.engagementScore || 0) + scoreChange));
    
    await storage.updateContact(contactId, {
      engagementScore: newScore,
      lastActivityAt: new Date()
    });
  }

  // List Management
  async createEmailList(listData: InsertEmailList): Promise<EmailList> {
    return await storage.createEmailList({
      ...listData,
      subscriberCount: 0
    });
  }

  async createDynamicSegment(
    userId: number,
    name: string,
    description: string,
    rules: any
  ): Promise<EmailList> {
    return await storage.createEmailList({
      userId,
      name,
      description,
      type: 'dynamic',
      segmentRules: rules,
      subscriberCount: 0
    });
  }

  async getSegmentContacts(listId: number): Promise<Contact[]> {
    const list = await storage.getEmailList(listId);
    if (!list) {
      throw new Error('List not found');
    }

    if (list.type === 'static') {
      return await storage.getContactsByList(listId);
    }

    // Dynamic segment - apply rules
    return await this.applySegmentRules(list.userId, list.segmentRules);
  }

  private async applySegmentRules(userId: number, rules: any): Promise<Contact[]> {
    // Get all user contacts
    const allContacts = await storage.getContactsByUser(userId);
    
    if (!rules || Object.keys(rules).length === 0) {
      return allContacts;
    }

    return allContacts.filter(contact => {
      return this.evaluateSegmentRules(contact, rules);
    });
  }

  private evaluateSegmentRules(contact: Contact, rules: any): boolean {
    // Simple rule evaluation - can be extended for complex logic
    const conditions = rules.conditions || [];
    const operator = rules.operator || 'AND';

    const results = conditions.map((condition: any) => {
      const { field, operator: condOp, value } = condition;
      const contactValue = this.getContactFieldValue(contact, field);

      switch (condOp) {
        case 'equals':
          return contactValue === value;
        case 'contains':
          return String(contactValue).toLowerCase().includes(String(value).toLowerCase());
        case 'greater_than':
          return Number(contactValue) > Number(value);
        case 'less_than':
          return Number(contactValue) < Number(value);
        case 'exists':
          return contactValue !== null && contactValue !== undefined && contactValue !== '';
        case 'not_exists':
          return contactValue === null || contactValue === undefined || contactValue === '';
        case 'in_list':
          return Array.isArray(value) && value.includes(contactValue);
        case 'has_tag':
          return Array.isArray(contact.tags) && contact.tags.includes(value);
        default:
          return false;
      }
    });

    if (operator === 'OR') {
      return results.some(result => result);
    }
    
    return results.every(result => result);
  }

  private getContactFieldValue(contact: Contact, field: string): any {
    switch (field) {
      case 'email':
        return contact.email;
      case 'firstName':
        return contact.firstName;
      case 'lastName':
        return contact.lastName;
      case 'phone':
        return contact.phone;
      case 'organization':
        return contact.organization;
      case 'engagementScore':
        return contact.engagementScore;
      case 'isSubscribed':
        return contact.isSubscribed;
      case 'createdAt':
        return contact.createdAt;
      case 'lastActivityAt':
        return contact.lastActivityAt;
      default:
        // Check custom fields
        return contact.customFields?.[field];
    }
  }

  private async updateListSubscriberCount(listId: number): Promise<void> {
    const count = await storage.getListSubscriberCount(listId);
    await storage.updateEmailList(listId, { subscriberCount: count });
  }

  // Tagging System
  async addTagToContact(contactId: number, tag: string): Promise<void> {
    const contact = await storage.getContact(contactId);
    if (!contact) {
      throw new Error('Contact not found');
    }

    const currentTags = Array.isArray(contact.tags) ? contact.tags : [];
    if (!currentTags.includes(tag)) {
      currentTags.push(tag);
      await storage.updateContact(contactId, { tags: currentTags });
    }
  }

  async removeTagFromContact(contactId: number, tag: string): Promise<void> {
    const contact = await storage.getContact(contactId);
    if (!contact) {
      throw new Error('Contact not found');
    }

    const currentTags = Array.isArray(contact.tags) ? contact.tags : [];
    const updatedTags = currentTags.filter(t => t !== tag);
    
    await storage.updateContact(contactId, { tags: updatedTags });
  }

  async getContactsByTag(userId: number, tag: string): Promise<Contact[]> {
    const allContacts = await storage.getContactsByUser(userId);
    return allContacts.filter(contact => 
      Array.isArray(contact.tags) && contact.tags.includes(tag)
    );
  }

  async getAllTags(userId: number): Promise<string[]> {
    const contacts = await storage.getContactsByUser(userId);
    const allTags = new Set<string>();
    
    contacts.forEach(contact => {
      if (Array.isArray(contact.tags)) {
        contact.tags.forEach(tag => allTags.add(tag));
      }
    });
    
    return Array.from(allTags).sort();
  }

  // Subscription Management
  async unsubscribeContact(contactId: number, reason?: string): Promise<void> {
    await storage.updateContact(contactId, {
      isSubscribed: false,
      customFields: { unsubscribeReason: reason },
      lastActivityAt: new Date()
    });
    
    await this.updateEngagementScore(contactId, 'unsubscribe');
  }

  async resubscribeContact(contactId: number): Promise<void> {
    await storage.updateContact(contactId, {
      isSubscribed: true,
      consentTimestamp: new Date(),
      lastActivityAt: new Date()
    });
  }

  // Utility Methods
  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private extractCustomFields(data: any): Record<string, any> {
    const standardFields = ['email', 'firstName', 'first_name', 'lastName', 'last_name', 'phone', 'organization', 'company', 'tags', 'isSubscribed'];
    const customFields: Record<string, any> = {};
    
    Object.keys(data).forEach(key => {
      if (!standardFields.includes(key)) {
        customFields[key] = data[key];
      }
    });
    
    return customFields;
  }

  // GDPR Compliance
  async exportContactData(contactId: number): Promise<any> {
    const contact = await storage.getContact(contactId);
    if (!contact) {
      throw new Error('Contact not found');
    }

    // Get all related data
    const analytics = await storage.getContactAnalytics(contactId);
    const lists = await storage.getContactLists(contactId);

    return {
      personal_data: {
        email: contact.email,
        firstName: contact.firstName,
        lastName: contact.lastName,
        phone: contact.phone,
        organization: contact.organization,
        customFields: contact.customFields,
        createdAt: contact.createdAt,
        consentTimestamp: contact.consentTimestamp
      },
      engagement_data: {
        engagementScore: contact.engagementScore,
        lastActivityAt: contact.lastActivityAt,
        isSubscribed: contact.isSubscribed,
        tags: contact.tags
      },
      list_memberships: lists,
      email_activity: analytics
    };
  }

  async deleteContact(contactId: number): Promise<void> {
    // Remove from all lists first
    await storage.removeContactFromAllLists(contactId);
    
    // Delete contact (this should cascade delete related records)
    await storage.deleteContact(contactId);
  }
}

export const contactManagementService = new ContactManagementService();