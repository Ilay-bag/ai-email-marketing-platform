import { storage } from "../storage";
import { Automation, AutomationStep, AutomationExecution, Contact, EmailTemplate } from "@shared/schema";
import { contactManagementService } from "./contact-management";
import { espIntegrationService } from "./esp-integration";
import { sendEmail, generateEmailHTML, generateEmailText } from "./sendgrid";

// Advanced Email Marketing Automation Engine
export class AutomationEngine {
  
  // Create automation workflow
  async createAutomation(automation: {
    userId: number;
    name: string;
    description?: string;
    triggerType: string;
    triggerSettings?: any;
    steps: any[];
  }): Promise<Automation> {
    // Create automation
    const newAutomation = await storage.createAutomation({
      userId: automation.userId,
      name: automation.name,
      description: automation.description,
      triggerType: automation.triggerType as any,
      triggerSettings: automation.triggerSettings || {},
      isActive: false,
      totalEntered: 0,
      totalCompleted: 0
    });

    // Create automation steps
    for (let i = 0; i < automation.steps.length; i++) {
      const step = automation.steps[i];
      await storage.createAutomationStep({
        automationId: newAutomation.id,
        stepOrder: i + 1,
        stepType: step.type,
        stepSettings: step.settings,
        emailTemplateId: step.emailTemplateId,
        isActive: true
      });
    }

    return newAutomation;
  }

  // Trigger automation for contact
  async triggerAutomation(automationId: number, contactId: number, eventData?: any): Promise<void> {
    const automation = await storage.getAutomation(automationId);
    if (!automation || !automation.isActive) {
      return;
    }

    const contact = await storage.getContact(contactId);
    if (!contact || !contact.isSubscribed) {
      return;
    }

    // Check if contact already in this automation
    const existingExecution = await storage.getActiveAutomationExecution(automationId, contactId);
    if (existingExecution) {
      return; // Contact already in this automation
    }

    // Get first step
    const steps = await storage.getAutomationSteps(automationId);
    if (steps.length === 0) {
      return;
    }

    const firstStep = steps[0];

    // Create execution record
    const execution = await storage.createAutomationExecution({
      automationId,
      contactId,
      currentStepId: firstStep.id,
      status: 'active',
      enteredAt: new Date(),
      metadata: eventData || {}
    });

    // Update automation stats
    await storage.updateAutomation(automationId, {
      totalEntered: automation.totalEntered + 1
    });

    // Execute first step
    await this.executeStep(execution.id, firstStep);
  }

  // Execute automation step
  async executeStep(executionId: number, step: AutomationStep): Promise<void> {
    const execution = await storage.getAutomationExecution(executionId);
    if (!execution || execution.status !== 'active') {
      return;
    }

    const contact = await storage.getContact(execution.contactId);
    if (!contact) {
      return;
    }

    try {
      switch (step.stepType) {
        case 'email':
          await this.executeEmailStep(execution, step, contact);
          break;
        case 'delay':
          await this.executeDelayStep(execution, step);
          break;
        case 'condition':
          await this.executeConditionStep(execution, step, contact);
          break;
        case 'tag_action':
          await this.executeTagActionStep(execution, step, contact);
          break;
        case 'webhook':
          await this.executeWebhookStep(execution, step, contact);
          break;
        default:
          console.warn(`Unknown step type: ${step.stepType}`);
      }

      // Move to next step
      await this.moveToNextStep(execution.id, step);
      
    } catch (error) {
      console.error(`Error executing step ${step.id}:`, error);
      await storage.updateAutomationExecution(executionId, {
        status: 'failed',
        completedAt: new Date()
      });
    }
  }

  private async executeEmailStep(execution: AutomationExecution, step: AutomationStep, contact: Contact): Promise<void> {
    if (!step.emailTemplateId) {
      throw new Error('Email step missing template ID');
    }

    const template = await storage.getEmailTemplate(step.emailTemplateId);
    if (!template) {
      throw new Error('Email template not found');
    }

    // Personalize email content
    const personalizedContent = this.personalizeEmailContent(template.content, contact);
    const personalizedSubject = this.personalizeText(template.subject || '', contact);

    // Send email via SendGrid
    await sendgridService.sendEmail({
      to: contact.email,
      subject: personalizedSubject,
      html: this.convertToHTML(personalizedContent),
      from: step.stepSettings.fromEmail || 'noreply@yourcompany.com'
    });

    // Track email sent
    await storage.createCampaignAnalytics({
      campaignId: execution.automationId,
      contactId: contact.id,
      eventType: 'sent',
      eventData: {
        automationExecutionId: execution.id,
        stepId: step.id,
        templateId: template.id
      }
    });
  }

  private async executeDelayStep(execution: AutomationExecution, step: AutomationStep): Promise<void> {
    const delaySettings = step.stepSettings;
    const delayAmount = delaySettings.amount || 1;
    const delayUnit = delaySettings.unit || 'hours'; // minutes, hours, days, weeks

    let delayMs = 0;
    switch (delayUnit) {
      case 'minutes':
        delayMs = delayAmount * 60 * 1000;
        break;
      case 'hours':
        delayMs = delayAmount * 60 * 60 * 1000;
        break;
      case 'days':
        delayMs = delayAmount * 24 * 60 * 60 * 1000;
        break;
      case 'weeks':
        delayMs = delayAmount * 7 * 24 * 60 * 60 * 1000;
        break;
    }

    const scheduledAt = new Date(Date.now() + delayMs);
    
    // Update execution to be scheduled
    await storage.updateAutomationExecution(execution.id, {
      status: 'scheduled',
      lastStepAt: new Date()
    });

    // Schedule next step execution (in real implementation, use a job queue)
    setTimeout(() => {
      this.resumeScheduledExecution(execution.id);
    }, delayMs);
  }

  private async executeConditionStep(execution: AutomationExecution, step: AutomationStep, contact: Contact): Promise<void> {
    const condition = step.stepSettings.condition;
    const conditionMet = this.evaluateCondition(contact, condition);
    
    // Store condition result for next step routing
    await storage.updateAutomationExecution(execution.id, {
      metadata: {
        ...execution.metadata,
        lastConditionResult: conditionMet
      },
      lastStepAt: new Date()
    });
  }

  private async executeTagActionStep(execution: AutomationExecution, step: AutomationStep, contact: Contact): Promise<void> {
    const action = step.stepSettings.action; // 'add' or 'remove'
    const tag = step.stepSettings.tag;

    if (action === 'add') {
      await contactManagementService.addTagToContact(contact.id, tag);
    } else if (action === 'remove') {
      await contactManagementService.removeTagFromContact(contact.id, tag);
    }
  }

  private async executeWebhookStep(execution: AutomationExecution, step: AutomationStep, contact: Contact): Promise<void> {
    const webhookUrl = step.stepSettings.url;
    const payload = {
      contact: {
        id: contact.id,
        email: contact.email,
        firstName: contact.firstName,
        lastName: contact.lastName,
        customFields: contact.customFields
      },
      automation: {
        id: execution.automationId,
        executionId: execution.id
      },
      ...step.stepSettings.additionalData
    };

    await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(step.stepSettings.headers || {})
      },
      body: JSON.stringify(payload)
    });
  }

  private async moveToNextStep(executionId: number, currentStep: AutomationStep): Promise<void> {
    const execution = await storage.getAutomationExecution(executionId);
    if (!execution) return;

    const allSteps = await storage.getAutomationSteps(execution.automationId);
    const currentStepIndex = allSteps.findIndex(s => s.id === currentStep.id);
    
    // Handle conditional routing
    if (currentStep.stepType === 'condition') {
      const conditionResult = execution.metadata?.lastConditionResult;
      const truePath = currentStep.stepSettings.truePath;
      const falsePath = currentStep.stepSettings.falsePath;
      
      let nextStepId = null;
      if (conditionResult && truePath) {
        nextStepId = truePath;
      } else if (!conditionResult && falsePath) {
        nextStepId = falsePath;
      }
      
      if (nextStepId) {
        const nextStep = allSteps.find(s => s.id === nextStepId);
        if (nextStep) {
          await storage.updateAutomationExecution(executionId, {
            currentStepId: nextStep.id,
            lastStepAt: new Date()
          });
          
          // Execute next step immediately if not a delay
          if (nextStep.stepType !== 'delay') {
            await this.executeStep(executionId, nextStep);
          }
          return;
        }
      }
    }

    // Linear progression to next step
    if (currentStepIndex < allSteps.length - 1) {
      const nextStep = allSteps[currentStepIndex + 1];
      await storage.updateAutomationExecution(executionId, {
        currentStepId: nextStep.id,
        lastStepAt: new Date()
      });
      
      // Execute next step immediately if not a delay
      if (nextStep.stepType !== 'delay') {
        await this.executeStep(executionId, nextStep);
      }
    } else {
      // Automation completed
      await storage.updateAutomationExecution(executionId, {
        status: 'completed',
        completedAt: new Date()
      });
      
      // Update automation stats
      const automation = await storage.getAutomation(execution.automationId);
      if (automation) {
        await storage.updateAutomation(automation.id, {
          totalCompleted: automation.totalCompleted + 1
        });
      }
    }
  }

  // Event-driven automation triggers
  async processEvent(eventType: string, eventData: any): Promise<void> {
    const automations = await storage.getAutomationsByTrigger(eventType);
    
    for (const automation of automations) {
      if (!automation.isActive) continue;
      
      // Extract contact information from event
      const contactId = this.extractContactIdFromEvent(eventType, eventData);
      if (!contactId) continue;
      
      // Check trigger conditions
      if (this.evaluateTriggerConditions(automation.triggerSettings, eventData)) {
        await this.triggerAutomation(automation.id, contactId, eventData);
      }
    }
  }

  private extractContactIdFromEvent(eventType: string, eventData: any): number | null {
    // Extract contact ID based on event type
    switch (eventType) {
      case 'list_signup':
        return eventData.contactId;
      case 'cart_abandoned':
        return eventData.customerId;
      case 'purchase_completed':
        return eventData.customerId;
      case 'email_opened':
        return eventData.contactId;
      case 'email_clicked':
        return eventData.contactId;
      default:
        return eventData.contactId || null;
    }
  }

  private evaluateTriggerConditions(triggerSettings: any, eventData: any): boolean {
    if (!triggerSettings || !triggerSettings.conditions) {
      return true; // No conditions means always trigger
    }
    
    const conditions = triggerSettings.conditions;
    return conditions.every((condition: any) => {
      const eventValue = eventData[condition.field];
      
      switch (condition.operator) {
        case 'equals':
          return eventValue === condition.value;
        case 'greater_than':
          return Number(eventValue) > Number(condition.value);
        case 'contains':
          return String(eventValue).includes(condition.value);
        default:
          return true;
      }
    });
  }

  private evaluateCondition(contact: Contact, condition: any): boolean {
    const contactValue = this.getContactValue(contact, condition.field);
    
    switch (condition.operator) {
      case 'equals':
        return contactValue === condition.value;
      case 'not_equals':
        return contactValue !== condition.value;
      case 'contains':
        return String(contactValue).includes(condition.value);
      case 'greater_than':
        return Number(contactValue) > Number(condition.value);
      case 'less_than':
        return Number(contactValue) < Number(condition.value);
      case 'has_tag':
        return Array.isArray(contact.tags) && contact.tags.includes(condition.value);
      case 'not_has_tag':
        return !Array.isArray(contact.tags) || !contact.tags.includes(condition.value);
      case 'is_subscribed':
        return contact.isSubscribed === true;
      case 'is_unsubscribed':
        return contact.isSubscribed === false;
      default:
        return false;
    }
  }

  private getContactValue(contact: Contact, field: string): any {
    switch (field) {
      case 'email':
        return contact.email;
      case 'firstName':
        return contact.firstName;
      case 'lastName':
        return contact.lastName;
      case 'engagementScore':
        return contact.engagementScore;
      case 'isSubscribed':
        return contact.isSubscribed;
      default:
        return contact.customFields?.[field];
    }
  }

  private personalizeEmailContent(content: any, contact: Contact): any {
    // Clone content to avoid mutations
    const personalizedContent = JSON.parse(JSON.stringify(content));
    
    if (personalizedContent.components) {
      personalizedContent.components.forEach((component: any) => {
        if (component.content) {
          Object.keys(component.content).forEach(key => {
            if (typeof component.content[key] === 'string') {
              component.content[key] = this.personalizeText(component.content[key], contact);
            }
          });
        }
      });
    }
    
    return personalizedContent;
  }

  private personalizeText(text: string, contact: Contact): string {
    let personalizedText = text;
    
    // Replace common merge tags
    personalizedText = personalizedText.replace(/\{\{first_name\}\}/g, contact.firstName || 'there');
    personalizedText = personalizedText.replace(/\{\{last_name\}\}/g, contact.lastName || '');
    personalizedText = personalizedText.replace(/\{\{email\}\}/g, contact.email);
    personalizedText = personalizedText.replace(/\{\{organization\}\}/g, contact.organization || '');
    
    // Replace custom field tags
    if (contact.customFields) {
      Object.entries(contact.customFields).forEach(([key, value]) => {
        const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
        personalizedText = personalizedText.replace(regex, String(value));
      });
    }
    
    return personalizedText;
  }

  private convertToHTML(content: any): string {
    // Convert component-based content to HTML
    if (!content.components) {
      return content.html || '';
    }
    
    let html = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>';
    
    content.components.forEach((component: any) => {
      switch (component.type) {
        case 'header':
          html += `<h1>${component.content.title}</h1>`;
          if (component.content.subtitle) {
            html += `<p>${component.content.subtitle}</p>`;
          }
          break;
        case 'text':
          html += `<p>${component.content.text || component.content.html}</p>`;
          break;
        case 'button':
          html += `<a href="${component.content.url}" style="display: inline-block; padding: 12px 24px; background-color: #007bff; color: white; text-decoration: none; border-radius: 4px;">${component.content.text}</a>`;
          break;
        case 'image':
          html += `<img src="${component.content.src}" alt="${component.content.alt || ''}" style="max-width: 100%; height: auto;" />`;
          break;
      }
    });
    
    html += '</body></html>';
    return html;
  }

  // Resume scheduled executions (would be called by job queue)
  async resumeScheduledExecution(executionId: number): Promise<void> {
    const execution = await storage.getAutomationExecution(executionId);
    if (!execution || execution.status !== 'scheduled') {
      return;
    }

    // Update status back to active
    await storage.updateAutomationExecution(executionId, {
      status: 'active'
    });

    // Get current step and continue
    const currentStep = await storage.getAutomationStep(execution.currentStepId!);
    if (currentStep) {
      await this.moveToNextStep(executionId, currentStep);
    }
  }

  // Automation management
  async pauseAutomation(automationId: number): Promise<void> {
    await storage.updateAutomation(automationId, { isActive: false });
    
    // Pause all active executions
    await storage.pauseAutomationExecutions(automationId);
  }

  async resumeAutomation(automationId: number): Promise<void> {
    await storage.updateAutomation(automationId, { isActive: true });
    
    // Resume paused executions
    await storage.resumeAutomationExecutions(automationId);
  }

  async getAutomationStats(automationId: number): Promise<any> {
    const automation = await storage.getAutomation(automationId);
    if (!automation) return null;

    const executions = await storage.getAutomationExecutions(automationId);
    const completedCount = executions.filter(e => e.status === 'completed').length;
    const activeCount = executions.filter(e => e.status === 'active').length;
    const failedCount = executions.filter(e => e.status === 'failed').length;

    return {
      totalEntered: automation.totalEntered,
      totalCompleted: automation.totalCompleted,
      activeExecutions: activeCount,
      failedExecutions: failedCount,
      completionRate: automation.totalEntered > 0 ? (completedCount / automation.totalEntered) * 100 : 0
    };
  }
}

export const automationEngine = new AutomationEngine();