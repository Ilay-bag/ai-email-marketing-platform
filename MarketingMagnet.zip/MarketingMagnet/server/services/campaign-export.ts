import { storage } from "../storage";
import { oauthService } from "./oauth";
import { MailchimpIntegration } from "../integrations/mailchimp";
import { KlaviyoIntegration } from "../integrations/klaviyo";
import { ShopifyIntegration } from "../integrations/shopify";
import { WixIntegration } from "../integrations/wix";
import { WordPressIntegration } from "../integrations/wordpress";
import type { EmailContent } from "@shared/schema";

export interface ExportResult {
  success: boolean;
  campaignId?: string;
  platformCampaignId?: string;
  message: string;
  error?: string;
}

export class CampaignExportService {
  async exportCampaign(
    userId: number,
    campaignId: number,
    platform: string,
    additionalOptions: any = {}
  ): Promise<ExportResult> {
    try {
      // Get the campaign
      const campaign = await storage.getCampaign(campaignId);
      if (!campaign) {
        return {
          success: false,
          message: "Campaign not found",
          error: "CAMPAIGN_NOT_FOUND"
        };
      }

      // Get the integration
      const integration = await storage.getIntegrationByProvider(userId, platform);
      if (!integration || !integration.isActive) {
        return {
          success: false,
          message: `${platform} integration not found or inactive`,
          error: "INTEGRATION_NOT_FOUND"
        };
      }

      // Get a valid access token
      let accessToken = integration.accessToken;
      if (accessToken) {
        try {
          accessToken = await oauthService.getValidToken(integration);
        } catch (error) {
          return {
            success: false,
            message: "Failed to get valid access token",
            error: "TOKEN_INVALID"
          };
        }
      }

      // Parse email content
      const emailContent = campaign.content as EmailContent;
      
      // Export to specific platform
      const result = await this.exportToplatform(
        platform,
        emailContent,
        integration,
        accessToken,
        additionalOptions
      );

      return result;

    } catch (error) {
      console.error("Campaign export error:", error);
      return {
        success: false,
        message: "Failed to export campaign",
        error: error instanceof Error ? error.message : "UNKNOWN_ERROR"
      };
    }
  }

  private async exportToplatform(
    platform: string,
    emailContent: EmailContent,
    integration: any,
    accessToken: string | null,
    options: any
  ): Promise<ExportResult> {
    switch (platform) {
      case 'mailchimp':
        return this.exportToMailchimp(emailContent, integration, accessToken, options);
      case 'klaviyo':
        return this.exportToKlaviyo(emailContent, integration, accessToken, options);
      case 'shopify':
        return this.exportToShopify(emailContent, integration, accessToken, options);
      case 'wix':
        return this.exportToWix(emailContent, integration, accessToken, options);
      case 'wordpress':
        return this.exportToWordPress(emailContent, integration, options);
      default:
        return {
          success: false,
          message: `Unsupported platform: ${platform}`,
          error: "UNSUPPORTED_PLATFORM"
        };
    }
  }

  private async exportToMailchimp(
    emailContent: EmailContent,
    integration: any,
    accessToken: string | null,
    options: any
  ): Promise<ExportResult> {
    try {
      const mailchimpIntegration = new MailchimpIntegration({
        apiKey: integration.apiKey || '',
        serverPrefix: options.serverPrefix || 'us1',
        listId: options.listId
      });

      // Convert email content to Mailchimp format
      const campaignData = {
        type: 'regular',
        settings: {
          subject_line: emailContent.subject,
          title: emailContent.header.title,
          from_name: options.fromName || 'EmailAI',
          reply_to: options.replyTo || integration.accountEmail,
          to_name: '*|FNAME|*',
          folder_id: options.folderId,
          auto_footer: false,
          inline_css: true
        },
        content: {
          html: this.convertToHTML(emailContent),
          text: this.convertToText(emailContent)
        }
      };

      const result = await mailchimpIntegration.createCampaign(campaignData);
      
      return {
        success: true,
        campaignId: result.id,
        platformCampaignId: result.id,
        message: "Campaign exported to Mailchimp successfully"
      };

    } catch (error) {
      return {
        success: false,
        message: "Failed to export to Mailchimp",
        error: error instanceof Error ? error.message : "MAILCHIMP_ERROR"
      };
    }
  }

  private async exportToKlaviyo(
    emailContent: EmailContent,
    integration: any,
    accessToken: string | null,
    options: any
  ): Promise<ExportResult> {
    try {
      const klaviyoIntegration = new KlaviyoIntegration({
        apiKey: integration.apiKey || '',
        listId: options.listId
      });

      const campaignData = {
        name: emailContent.header.title,
        subject: emailContent.subject,
        from_email: options.fromEmail || integration.accountEmail,
        from_name: options.fromName || 'EmailAI',
        list_id: options.listId,
        template_id: options.templateId,
        content: {
          html: this.convertToHTML(emailContent),
          text: this.convertToText(emailContent)
        }
      };

      const result = await klaviyoIntegration.createCampaign(campaignData);
      
      return {
        success: true,
        campaignId: result.id,
        platformCampaignId: result.id,
        message: "Campaign exported to Klaviyo successfully"
      };

    } catch (error) {
      return {
        success: false,
        message: "Failed to export to Klaviyo",
        error: error instanceof Error ? error.message : "KLAVIYO_ERROR"
      };
    }
  }

  private async exportToShopify(
    emailContent: EmailContent,
    integration: any,
    accessToken: string | null,
    options: any
  ): Promise<ExportResult> {
    try {
      // For Shopify, we might create a blog post or email template
      const shopifyIntegration = new ShopifyIntegration({
        apiKey: integration.apiKey || '',
        shopDomain: options.shopDomain || integration.accountId,
        accessToken: accessToken || ''
      });

      // Create a blog post with email content
      const blogPostData = {
        title: emailContent.subject,
        body_html: this.convertToHTML(emailContent),
        author: options.author || 'EmailAI',
        tags: options.tags || 'email-campaign',
        published: options.published || false
      };

      const result = await shopifyIntegration.createCustomer(blogPostData); // Placeholder - would need actual blog post creation
      
      return {
        success: true,
        campaignId: result.id,
        platformCampaignId: result.id,
        message: "Campaign exported to Shopify successfully"
      };

    } catch (error) {
      return {
        success: false,
        message: "Failed to export to Shopify",
        error: error instanceof Error ? error.message : "SHOPIFY_ERROR"
      };
    }
  }

  private async exportToWix(
    emailContent: EmailContent,
    integration: any,
    accessToken: string | null,
    options: any
  ): Promise<ExportResult> {
    try {
      const wixIntegration = new WixIntegration({
        apiKey: integration.apiKey || '',
        siteId: options.siteId || integration.accountId,
        accountId: integration.accountId || ''
      });

      // Create content in Wix
      const contentData = {
        title: emailContent.subject,
        content: this.convertToHTML(emailContent),
        type: 'email-campaign',
        status: options.status || 'draft'
      };

      const result = await wixIntegration.createCustomer(contentData); // Placeholder - would need actual content creation
      
      return {
        success: true,
        campaignId: result.id,
        platformCampaignId: result.id,
        message: "Campaign exported to Wix successfully"
      };

    } catch (error) {
      return {
        success: false,
        message: "Failed to export to Wix",
        error: error instanceof Error ? error.message : "WIX_ERROR"
      };
    }
  }

  private async exportToWordPress(
    emailContent: EmailContent,
    integration: any,
    options: any
  ): Promise<ExportResult> {
    try {
      const wordpressIntegration = new WordPressIntegration({
        siteUrl: options.siteUrl || integration.accountId,
        username: options.username || integration.accountEmail,
        applicationPassword: integration.apiKey || ''
      });

      // Create a WordPress post
      const postData = {
        title: emailContent.subject,
        content: this.convertToHTML(emailContent),
        status: options.status || 'draft',
        categories: options.categories || [],
        tags: options.tags || ['email-campaign']
      };

      const result = await wordpressIntegration.createPost(postData);
      
      return {
        success: true,
        campaignId: result.id,
        platformCampaignId: result.id,
        message: "Campaign exported to WordPress successfully"
      };

    } catch (error) {
      return {
        success: false,
        message: "Failed to export to WordPress",
        error: error instanceof Error ? error.message : "WORDPRESS_ERROR"
      };
    }
  }

  private convertToHTML(emailContent: EmailContent): string {
    // Convert structured email content to HTML
    let html = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
            .header { background: ${emailContent.header.backgroundColor || '#f8f9fa'}; padding: 20px; text-align: center; }
            .header h1 { color: #333; margin: 0; }
            .header p { color: #666; margin: 10px 0 0 0; }
            .content { padding: 20px; }
            .section { margin: 20px 0; }
            .cta { text-align: center; margin: 30px 0; }
            .cta a { 
              background: ${emailContent.cta.backgroundColor || '#007bff'}; 
              color: white; 
              padding: 12px 24px; 
              text-decoration: none; 
              border-radius: 5px; 
              display: inline-block; 
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${emailContent.header.title}</h1>
            ${emailContent.header.subtitle ? `<p>${emailContent.header.subtitle}</p>` : ''}
          </div>
          <div class="content">
    `;

    // Add body sections
    emailContent.body.sections.forEach(section => {
      html += `<div class="section">`;
      switch (section.type) {
        case 'text':
          html += `<p>${section.content}</p>`;
          break;
        case 'image':
          html += `<img src="${section.content}" style="max-width: 100%; height: auto;" />`;
          break;
        case 'button':
          html += `<div class="cta"><a href="${section.content.url || '#'}">${section.content.text}</a></div>`;
          break;
        case 'features':
          html += `<ul>`;
          section.content.forEach((feature: string) => {
            html += `<li>${feature}</li>`;
          });
          html += `</ul>`;
          break;
      }
      html += `</div>`;
    });

    // Add CTA
    html += `
          <div class="cta">
            <a href="${emailContent.cta.url || '#'}">${emailContent.cta.text}</a>
          </div>
        </div>
      </body>
      </html>
    `;

    return html;
  }

  private convertToText(emailContent: EmailContent): string {
    let text = `${emailContent.header.title}\n\n`;
    
    if (emailContent.header.subtitle) {
      text += `${emailContent.header.subtitle}\n\n`;
    }

    emailContent.body.sections.forEach(section => {
      switch (section.type) {
        case 'text':
          text += `${section.content}\n\n`;
          break;
        case 'features':
          section.content.forEach((feature: string) => {
            text += `• ${feature}\n`;
          });
          text += '\n';
          break;
        case 'button':
          text += `${section.content.text}: ${section.content.url || '#'}\n\n`;
          break;
      }
    });

    text += `${emailContent.cta.text}: ${emailContent.cta.url || '#'}\n`;

    return text;
  }
}

export const campaignExportService = new CampaignExportService();