import { storage } from "../storage";
import { CampaignAnalytics, Contact, Campaign } from "@shared/schema";

// Comprehensive Email Marketing Analytics Service
export class AnalyticsService {
  
  // Track email events
  async trackEmailEvent(data: {
    campaignId?: number;
    emailId?: number;
    contactId: number;
    eventType: 'sent' | 'delivered' | 'opened' | 'clicked' | 'bounced' | 'unsubscribed' | 'marked_spam';
    eventData?: any;
    userAgent?: string;
    ipAddress?: string;
  }): Promise<void> {
    await storage.createCampaignAnalytics({
      campaignId: data.campaignId,
      emailId: data.emailId,
      contactId: data.contactId,
      eventType: data.eventType,
      eventData: data.eventData || {},
      userAgent: data.userAgent,
      ipAddress: data.ipAddress
    });

    // Update contact engagement score
    await this.updateContactEngagement(data.contactId, data.eventType);
  }

  // Campaign analytics overview
  async getCampaignAnalytics(campaignId: number): Promise<{
    sent: number;
    delivered: number;
    opened: number;
    clicked: number;
    bounced: number;
    unsubscribed: number;
    markedSpam: number;
    openRate: number;
    clickRate: number;
    bounceRate: number;
    unsubscribeRate: number;
    clickToOpenRate: number;
    topLinks: Array<{ url: string; clicks: number }>;
    deviceBreakdown: Record<string, number>;
    locationBreakdown: Record<string, number>;
    timeSeriesData: Array<{ date: string; opens: number; clicks: number }>;
  }> {
    const analytics = await storage.getCampaignAnalytics(campaignId);
    
    const sent = analytics.filter(a => a.eventType === 'sent').length;
    const delivered = analytics.filter(a => a.eventType === 'delivered').length;
    const opened = analytics.filter(a => a.eventType === 'opened').length;
    const clicked = analytics.filter(a => a.eventType === 'clicked').length;
    const bounced = analytics.filter(a => a.eventType === 'bounced').length;
    const unsubscribed = analytics.filter(a => a.eventType === 'unsubscribed').length;
    const markedSpam = analytics.filter(a => a.eventType === 'marked_spam').length;

    // Calculate rates
    const openRate = delivered > 0 ? (opened / delivered) * 100 : 0;
    const clickRate = delivered > 0 ? (clicked / delivered) * 100 : 0;
    const bounceRate = sent > 0 ? (bounced / sent) * 100 : 0;
    const unsubscribeRate = delivered > 0 ? (unsubscribed / delivered) * 100 : 0;
    const clickToOpenRate = opened > 0 ? (clicked / opened) * 100 : 0;

    // Top clicked links
    const linkClicks = analytics
      .filter(a => a.eventType === 'clicked' && a.eventData?.url)
      .reduce((acc, a) => {
        const url = a.eventData.url;
        acc[url] = (acc[url] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

    const topLinks = Object.entries(linkClicks)
      .map(([url, clicks]) => ({ url, clicks }))
      .sort((a, b) => b.clicks - a.clicks)
      .slice(0, 10);

    // Device breakdown
    const deviceBreakdown = analytics
      .filter(a => a.userAgent)
      .reduce((acc, a) => {
        const device = this.parseDeviceFromUserAgent(a.userAgent!);
        acc[device] = (acc[device] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

    // Location breakdown (simplified - would use IP geolocation in production)
    const locationBreakdown = analytics
      .filter(a => a.ipAddress)
      .reduce((acc, a) => {
        const location = this.parseLocationFromIP(a.ipAddress!);
        acc[location] = (acc[location] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

    // Time series data (daily aggregation)
    const timeSeriesData = this.aggregateTimeSeriesData(analytics);

    return {
      sent,
      delivered,
      opened,
      clicked,
      bounced,
      unsubscribed,
      markedSpam,
      openRate: Math.round(openRate * 100) / 100,
      clickRate: Math.round(clickRate * 100) / 100,
      bounceRate: Math.round(bounceRate * 100) / 100,
      unsubscribeRate: Math.round(unsubscribeRate * 100) / 100,
      clickToOpenRate: Math.round(clickToOpenRate * 100) / 100,
      topLinks,
      deviceBreakdown,
      locationBreakdown,
      timeSeriesData
    };
  }

  // User dashboard analytics
  async getUserDashboardStats(userId: number): Promise<{
    totalCampaigns: number;
    totalContacts: number;
    totalEmailsSent: number;
    averageOpenRate: number;
    averageClickRate: number;
    recentCampaigns: Array<{
      id: number;
      title: string;
      sent: number;
      openRate: number;
      clickRate: number;
      createdAt: Date;
    }>;
    engagementTrend: Array<{ date: string; opens: number; clicks: number; sends: number }>;
    topPerformingCampaigns: Array<{
      id: number;
      title: string;
      openRate: number;
      clickRate: number;
    }>;
  }> {
    const campaigns = await storage.getCampaignsByUser(userId);
    const contacts = await storage.getContactsByUser(userId);
    const allAnalytics = await storage.getAllAnalyticsByUser(userId);

    const totalEmailsSent = allAnalytics.filter(a => a.eventType === 'sent').length;
    
    // Calculate average rates across all campaigns
    const campaignRates = await Promise.all(
      campaigns.map(async (campaign) => {
        const analytics = await this.getCampaignAnalytics(campaign.id);
        return {
          openRate: analytics.openRate,
          clickRate: analytics.clickRate
        };
      })
    );

    const averageOpenRate = campaignRates.length > 0 
      ? campaignRates.reduce((sum, r) => sum + r.openRate, 0) / campaignRates.length 
      : 0;
    
    const averageClickRate = campaignRates.length > 0 
      ? campaignRates.reduce((sum, r) => sum + r.clickRate, 0) / campaignRates.length 
      : 0;

    // Recent campaigns with stats
    const recentCampaigns = await Promise.all(
      campaigns
        .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
        .slice(0, 5)
        .map(async (campaign) => {
          const analytics = await this.getCampaignAnalytics(campaign.id);
          return {
            id: campaign.id,
            title: campaign.title,
            sent: analytics.sent,
            openRate: analytics.openRate,
            clickRate: analytics.clickRate,
            createdAt: campaign.createdAt!
          };
        })
    );

    // Engagement trend (last 30 days)
    const engagementTrend = this.calculateEngagementTrend(allAnalytics, 30);

    // Top performing campaigns
    const topPerformingCampaigns = await Promise.all(
      campaigns.map(async (campaign) => {
        const analytics = await this.getCampaignAnalytics(campaign.id);
        return {
          id: campaign.id,
          title: campaign.title,
          openRate: analytics.openRate,
          clickRate: analytics.clickRate
        };
      })
    );

    topPerformingCampaigns.sort((a, b) => b.openRate - a.openRate);

    return {
      totalCampaigns: campaigns.length,
      totalContacts: contacts.length,
      totalEmailsSent,
      averageOpenRate: Math.round(averageOpenRate * 100) / 100,
      averageClickRate: Math.round(averageClickRate * 100) / 100,
      recentCampaigns,
      engagementTrend,
      topPerformingCampaigns: topPerformingCampaigns.slice(0, 10)
    };
  }

  // A/B Test analytics
  async getABTestResults(testId: number): Promise<{
    variantA: {
      sent: number;
      opened: number;
      clicked: number;
      openRate: number;
      clickRate: number;
    };
    variantB: {
      sent: number;
      opened: number;
      clicked: number;
      openRate: number;
      clickRate: number;
    };
    winner: 'A' | 'B' | 'tie';
    confidence: number;
    isSignificant: boolean;
  }> {
    const test = await storage.getABTest(testId);
    if (!test) {
      throw new Error('A/B test not found');
    }

    const analyticsA = await storage.getABTestAnalytics(testId, 'A');
    const analyticsB = await storage.getABTestAnalytics(testId, 'B');

    const variantA = this.calculateVariantStats(analyticsA);
    const variantB = this.calculateVariantStats(analyticsB);

    // Statistical significance testing (simplified)
    const { winner, confidence, isSignificant } = this.calculateABTestWinner(variantA, variantB);

    return {
      variantA,
      variantB,
      winner,
      confidence,
      isSignificant
    };
  }

  // Contact engagement analytics
  async getContactEngagementAnalytics(contactId: number): Promise<{
    totalEmailsReceived: number;
    totalOpens: number;
    totalClicks: number;
    openRate: number;
    clickRate: number;
    engagementScore: number;
    lastActivity: Date | null;
    emailHistory: Array<{
      campaignId: number;
      campaignTitle: string;
      sentAt: Date;
      opened: boolean;
      clicked: boolean;
      openedAt?: Date;
      clickedAt?: Date;
    }>;
  }> {
    const contact = await storage.getContact(contactId);
    if (!contact) {
      throw new Error('Contact not found');
    }

    const analytics = await storage.getContactAnalytics(contactId);
    
    const totalEmailsReceived = analytics.filter(a => a.eventType === 'sent').length;
    const totalOpens = analytics.filter(a => a.eventType === 'opened').length;
    const totalClicks = analytics.filter(a => a.eventType === 'clicked').length;

    const openRate = totalEmailsReceived > 0 ? (totalOpens / totalEmailsReceived) * 100 : 0;
    const clickRate = totalEmailsReceived > 0 ? (totalClicks / totalEmailsReceived) * 100 : 0;

    const lastActivity = contact.lastActivityAt;

    // Email history
    const emailHistory = await this.getContactEmailHistory(contactId);

    return {
      totalEmailsReceived,
      totalOpens,
      totalClicks,
      openRate: Math.round(openRate * 100) / 100,
      clickRate: Math.round(clickRate * 100) / 100,
      engagementScore: contact.engagementScore || 0,
      lastActivity,
      emailHistory
    };
  }

  // Automation analytics
  async getAutomationAnalytics(automationId: number): Promise<{
    totalEntered: number;
    totalCompleted: number;
    currentlyActive: number;
    dropoffByStep: Array<{ stepOrder: number; stepName: string; dropoffs: number }>;
    completionRate: number;
    averageTimeToComplete: number;
    conversionRate: number;
  }> {
    const automation = await storage.getAutomation(automationId);
    if (!automation) {
      throw new Error('Automation not found');
    }

    const executions = await storage.getAutomationExecutions(automationId);
    const steps = await storage.getAutomationSteps(automationId);

    const totalEntered = executions.length;
    const totalCompleted = executions.filter(e => e.status === 'completed').length;
    const currentlyActive = executions.filter(e => e.status === 'active').length;

    // Calculate dropoff by step
    const dropoffByStep = steps.map(step => {
      const executionsReachedStep = executions.filter(e => 
        e.currentStepId === step.id || e.status === 'completed'
      ).length;
      
      const executionsCompletedStep = executions.filter(e => {
        const stepIndex = steps.findIndex(s => s.id === step.id);
        const currentStepIndex = steps.findIndex(s => s.id === e.currentStepId);
        return currentStepIndex > stepIndex || e.status === 'completed';
      }).length;

      return {
        stepOrder: step.stepOrder,
        stepName: step.stepSettings.name || `Step ${step.stepOrder}`,
        dropoffs: executionsReachedStep - executionsCompletedStep
      };
    });

    const completionRate = totalEntered > 0 ? (totalCompleted / totalEntered) * 100 : 0;

    // Average time to complete
    const completedExecutions = executions.filter(e => e.status === 'completed' && e.completedAt);
    const averageTimeToComplete = completedExecutions.length > 0
      ? completedExecutions.reduce((sum, e) => {
          const duration = new Date(e.completedAt!).getTime() - new Date(e.enteredAt).getTime();
          return sum + duration;
        }, 0) / completedExecutions.length
      : 0;

    // Conversion rate (if automation has conversion goals)
    const conversionRate = this.calculateAutomationConversionRate(automationId, executions);

    return {
      totalEntered,
      totalCompleted,
      currentlyActive,
      dropoffByStep,
      completionRate: Math.round(completionRate * 100) / 100,
      averageTimeToComplete: Math.round(averageTimeToComplete / (1000 * 60 * 60)), // Convert to hours
      conversionRate
    };
  }

  // Private helper methods
  private async updateContactEngagement(contactId: number, eventType: string): Promise<void> {
    const contact = await storage.getContact(contactId);
    if (!contact) return;

    let scoreChange = 0;
    switch (eventType) {
      case 'opened':
        scoreChange = 1;
        break;
      case 'clicked':
        scoreChange = 5;
        break;
      case 'unsubscribed':
        scoreChange = -10;
        break;
      case 'bounced':
        scoreChange = -5;
        break;
      case 'marked_spam':
        scoreChange = -15;
        break;
    }

    if (scoreChange !== 0) {
      const newScore = Math.max(0, Math.min(100, (contact.engagementScore || 0) + scoreChange));
      await storage.updateContact(contactId, {
        engagementScore: newScore,
        lastActivityAt: new Date()
      });
    }
  }

  private parseDeviceFromUserAgent(userAgent: string): string {
    if (userAgent.includes('Mobile') || userAgent.includes('Android')) {
      return 'Mobile';
    }
    if (userAgent.includes('Tablet') || userAgent.includes('iPad')) {
      return 'Tablet';
    }
    return 'Desktop';
  }

  private parseLocationFromIP(ipAddress: string): string {
    // Simplified - in production, use a geolocation service
    if (ipAddress.startsWith('192.168.') || ipAddress.startsWith('127.')) {
      return 'Unknown';
    }
    return 'Unknown'; // Would implement proper geolocation
  }

  private aggregateTimeSeriesData(analytics: CampaignAnalytics[]): Array<{ date: string; opens: number; clicks: number }> {
    const dailyData: Record<string, { opens: number; clicks: number }> = {};

    analytics.forEach(a => {
      const date = new Date(a.createdAt!).toISOString().split('T')[0];
      
      if (!dailyData[date]) {
        dailyData[date] = { opens: 0, clicks: 0 };
      }

      if (a.eventType === 'opened') {
        dailyData[date].opens++;
      } else if (a.eventType === 'clicked') {
        dailyData[date].clicks++;
      }
    });

    return Object.entries(dailyData)
      .map(([date, data]) => ({ date, ...data }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  private calculateEngagementTrend(analytics: CampaignAnalytics[], days: number): Array<{ date: string; opens: number; clicks: number; sends: number }> {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - (days * 24 * 60 * 60 * 1000));

    const dailyData: Record<string, { opens: number; clicks: number; sends: number }> = {};

    // Initialize all dates
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split('T')[0];
      dailyData[dateStr] = { opens: 0, clicks: 0, sends: 0 };
    }

    // Aggregate data
    analytics
      .filter(a => new Date(a.createdAt!) >= startDate)
      .forEach(a => {
        const date = new Date(a.createdAt!).toISOString().split('T')[0];
        
        if (dailyData[date]) {
          if (a.eventType === 'sent') dailyData[date].sends++;
          if (a.eventType === 'opened') dailyData[date].opens++;
          if (a.eventType === 'clicked') dailyData[date].clicks++;
        }
      });

    return Object.entries(dailyData)
      .map(([date, data]) => ({ date, ...data }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  private calculateVariantStats(analytics: CampaignAnalytics[]) {
    const sent = analytics.filter(a => a.eventType === 'sent').length;
    const opened = analytics.filter(a => a.eventType === 'opened').length;
    const clicked = analytics.filter(a => a.eventType === 'clicked').length;

    return {
      sent,
      opened,
      clicked,
      openRate: sent > 0 ? (opened / sent) * 100 : 0,
      clickRate: sent > 0 ? (clicked / sent) * 100 : 0
    };
  }

  private calculateABTestWinner(variantA: any, variantB: any): { winner: 'A' | 'B' | 'tie'; confidence: number; isSignificant: boolean } {
    // Simplified statistical significance test
    const rateA = variantA.openRate;
    const rateB = variantB.openRate;
    
    if (Math.abs(rateA - rateB) < 0.1) {
      return { winner: 'tie', confidence: 0, isSignificant: false };
    }
    
    const winner = rateA > rateB ? 'A' : 'B';
    const improvement = Math.abs(rateA - rateB);
    const confidence = Math.min(95, improvement * 10); // Simplified confidence calculation
    const isSignificant = confidence >= 80 && Math.min(variantA.sent, variantB.sent) >= 100;
    
    return { winner, confidence, isSignificant };
  }

  private async getContactEmailHistory(contactId: number) {
    const analytics = await storage.getContactAnalytics(contactId);
    const campaigns = await storage.getAllCampaigns();
    
    const emailHistory: Record<number, any> = {};
    
    analytics.forEach(a => {
      if (!a.campaignId) return;
      
      if (!emailHistory[a.campaignId]) {
        const campaign = campaigns.find(c => c.id === a.campaignId);
        emailHistory[a.campaignId] = {
          campaignId: a.campaignId,
          campaignTitle: campaign?.title || 'Unknown Campaign',
          sentAt: null,
          opened: false,
          clicked: false
        };
      }
      
      const history = emailHistory[a.campaignId];
      
      if (a.eventType === 'sent') {
        history.sentAt = a.createdAt;
      } else if (a.eventType === 'opened') {
        history.opened = true;
        history.openedAt = a.createdAt;
      } else if (a.eventType === 'clicked') {
        history.clicked = true;
        history.clickedAt = a.createdAt;
      }
    });
    
    return Object.values(emailHistory)
      .filter(h => h.sentAt)
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
  }

  private calculateAutomationConversionRate(automationId: number, executions: any[]): number {
    // This would depend on how conversions are defined for the automation
    // For now, return completion rate as a proxy
    const completed = executions.filter(e => e.status === 'completed').length;
    return executions.length > 0 ? (completed / executions.length) * 100 : 0;
  }
}

export const analyticsService = new AnalyticsService();