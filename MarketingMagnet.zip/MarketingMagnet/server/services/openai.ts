import OpenAI from "openai";
import { EmailContent } from "@shared/schema";
import { emailExamples } from "../data/emailExamples";
import { generateModularEmailPrompt } from "./email-component-converter";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

export async function generateEmailCampaign(prompt: string): Promise<EmailContent> {
  try {
    // Detect Hebrew and enhance prompt accordingly
    const isHebrew = /[\u0590-\u05FF]/.test(prompt);
    const enhancedPrompt = generateModularEmailPrompt(prompt, isHebrew);

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert email marketing specialist focused on creating modular, editable email content. Generate email campaigns with clear, distinct sections that can be independently edited and rearranged.

          CRITICAL: Return a valid JSON object with this EXACT structure for modular email building:
          {
            "subject": "Compelling subject line that grabs attention (30-50 characters)",
            "header": {
              "title": "Main headline that hooks the reader",
              "subtitle": "Supporting headline that adds context (optional)",
              "backgroundColor": "#3B82F6"
            },
            "body": {
              "sections": [
                {
                  "type": "text",
                  "content": "Opening paragraph: Connect with reader, introduce value. Make this standalone and engaging."
                },
                {
                  "type": "features", 
                  "content": ["Specific benefit 1", "Specific benefit 2", "Specific benefit 3"]
                },
                {
                  "type": "text",
                  "content": "Supporting paragraph: Social proof, testimonials, or additional details. Keep this separate from opening."
                },
                {
                  "type": "text", 
                  "content": "Closing paragraph: Create urgency and lead to action. This should stand alone as final motivation."
                }
              ]
            },
            "cta": {
              "text": "Action-oriented button text (2-4 words)",
              "url": "https://example.com",
              "backgroundColor": "#10B981"
            },
            "htmlContent": "Complete HTML email document with proper structure"
          }

          MODULAR CONTENT RULES:
          - Each body section must be INDEPENDENT and self-contained
          - Text sections should be complete thoughts (50-150 words each)
          - Features/benefits should be specific and actionable
          - Keep sections distinct - avoid overlapping content
          - Each section should add unique value
          - Structure for easy editing: users should be able to remove any section without breaking flow

          HTML EMAIL REQUIREMENTS:
          - Generate complete HTML document with <!DOCTYPE html><html><head> and proper meta tags
          - Use table-based layouts for maximum email client compatibility
          - Inline all CSS styles - no external stylesheets
          - Include mobile-responsive media queries in <head>
          - Use web-safe fonts with fallbacks (Arial, Helvetica, sans-serif)
          - Keep email width at 600px for desktop
          - Include alt text for images
          - Use personalization tags: {{first_name}}, {{company}}, {{product_name}}, etc.
          - Ensure compatibility across major email clients

          EXAMPLE EMAIL STRUCTURE:
          ${emailExamples.slice(0, 1).map(example => `
          <!-- ${example.name} Example -->
          ${example.html.substring(0, 500)}...
          `).join('')}

          EMAIL MARKETING BEST PRACTICES:
          - Subject line: 30-50 characters, create curiosity or urgency
          - Header: Clear value proposition, benefit-focused
          - Body: Use storytelling, social proof, and emotional triggers
          - CTA: Use action verbs, create urgency, single clear action
          - Tone: Match the brand voice and target audience
          - Structure: Problem → Solution → Benefits → Action

          Make every element work together to drive the desired action with production-ready HTML code.`
        },
        {
          role: "user",
          content: enhancedPrompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    // Validate and ensure required fields
    return {
      subject: result.subject || "Your Email Campaign",
      header: {
        title: result.header?.title || "Welcome",
        subtitle: result.header?.subtitle,
        image: result.header?.image,
        backgroundColor: result.header?.backgroundColor || "#3B82F6"
      },
      body: {
        sections: result.body?.sections || [
          {
            type: "text",
            content: "Thank you for your interest in our product."
          }
        ]
      },
      cta: {
        text: result.cta?.text || "Learn More",
        url: result.cta?.url,
        backgroundColor: result.cta?.backgroundColor || "#10B981"
      },
      htmlContent: result.htmlContent || ""
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate email campaign. Please check your OpenAI API key and try again.");
  }
}

export async function improveCampaignContent(currentContent: EmailContent, improvement: string): Promise<EmailContent> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert email marketing specialist. Improve the existing email campaign based on the user's feedback.

          Return a JSON object with the same structure as the input, but with improvements applied.`
        },
        {
          role: "user",
          content: `Current email campaign: ${JSON.stringify(currentContent, null, 2)}

          Improvement request: ${improvement}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to improve campaign content. Please try again.");
  }
}

export async function generateEmailFlow(prompt: string): Promise<any> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an AI assistant that creates complete, connected email marketing flows with proper visual structure.

          Create flows that are visual, connected, and ready to use. Generate:
          1. A trigger that starts the flow
          2. Connected steps with delays between emails
          3. Email actions with subjects and content
          4. Proper node positioning and connections

          ALWAYS return a JSON object with this EXACT structure:
          {
            "name": "Flow Name (e.g., Welcome Series, Abandoned Cart Recovery)",
            "description": "What this flow does",
            "triggerType": "signup|abandoned_cart|purchase|custom",
            "nodes": [
              {
                "id": "trigger-1",
                "type": "trigger",
                "x": 100,
                "y": 100,
                "settings": {
                  "label": "When someone signs up",
                  "triggerType": "User Signup"
                }
              },
              {
                "id": "delay-1", 
                "type": "delay",
                "x": 100,
                "y": 250,
                "settings": {
                  "label": "Wait",
                  "delayTime": "1 hour"
                }
              },
              {
                "id": "email-1",
                "type": "action", 
                "x": 100,
                "y": 400,
                "settings": {
                  "label": "Welcome Email",
                  "actionType": "Send Email",
                  "subject": "Welcome to our community!",
                  "tone": "friendly"
                }
              }
            ],
            "edges": [
              {
                "id": "edge-1",
                "source": "trigger-1",
                "target": "delay-1"
              },
              {
                "id": "edge-2",
                "source": "delay-1", 
                "target": "email-1"
              }
            ]
          }

          Create 3-5 connected steps total. Position nodes vertically with 150px spacing. Always connect nodes with edges.`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 2000
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    // Ensure proper structure
    const nodes = result.nodes || [
      {
        id: "trigger-1",
        type: "trigger", 
        x: 100,
        y: 100,
        settings: {
          label: "Flow Start",
          triggerType: "Manual"
        }
      }
    ];

    const edges = result.edges || [];

    return {
      name: result.name || 'AI Generated Flow',
      description: result.description || prompt.substring(0, 200),
      triggerType: result.triggerType || 'custom',
      nodes,
      edges,
      emails: extractEmailsFromNodes(nodes)
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate email flow. Please try again.");
  }
}

// Helper function to extract emails from nodes
function extractEmailsFromNodes(nodes: any[]): any[] {
  return nodes
    .filter(node => node.type === 'action')
    .map((node, index) => ({
      subject: node.settings.subject || 'Email Subject',
      sequenceOrder: index + 1,
      delay: '1h',
      step: index + 1
    }));
}

// Helper functions for flow generation
function generateDefaultNodes(emails: any[]): any[] {
  const nodes = [
    {
      id: 'trigger-1',
      type: 'trigger',
      position: { x: 100, y: 100 },
      data: { label: 'Flow Trigger', triggerType: 'User Signup' }
    }
  ];

  emails.forEach((email, index) => {
    if (index > 0) {
      nodes.push({
        id: `delay-${index}`,
        type: 'delay',
        position: { x: 100, y: 200 + (index - 1) * 200 },
        data: { label: 'Wait', triggerType: 'delay' }
      });
    }

    nodes.push({
      id: `email-${index + 1}`,
      type: 'action',
      position: { x: 100, y: 250 + index * 200 },
      data: { 
        label: `Email ${index + 1}`, 
        triggerType: 'Send Email'
      }
    });
  });

  return nodes;
}

function generateDefaultEdges(emails: any[]): any[] {
  const edges: any[] = [];
  let lastNodeId = 'trigger-1';

  emails.forEach((email, index) => {
    if (index > 0) {
      const delayId = `delay-${index}`;
      edges.push({
        id: `edge-${lastNodeId}-${delayId}`,
        source: lastNodeId,
        target: delayId
      });
      lastNodeId = delayId;
    }

    const emailId = `email-${index + 1}`;
    edges.push({
      id: `edge-${lastNodeId}-${emailId}`,
      source: lastNodeId,
      target: emailId
    });
    lastNodeId = emailId;
  });

  return edges;
}

function generateFlowPreview(flowData: any): string {
  const emails = flowData.emails || [];
  const emailPreviews = emails.map((email: any, index: number) => 
    `<div style="margin: 10px 0; padding: 10px; border-left: 3px solid #3B82F6;">
      <h4>Email ${index + 1}: ${email.subject}</h4>
      <p><strong>Timing:</strong> ${email.delay || 'Immediate'}</p>
      <p>${email.content?.body?.sections?.[0]?.content?.substring(0, 100) || ''}...</p>
    </div>`
  ).join('');

  return `
    <div style="font-family: Arial, sans-serif;">
      <h3>${flowData.name || 'Email Flow'}</h3>
      <p>${flowData.description || ''}</p>
      <div style="margin: 20px 0;">
        <h4>Flow Sequence:</h4>
        ${emailPreviews}
      </div>
      <div style="background: #F3F4F6; padding: 10px; border-radius: 5px;">
        <strong>Expected Results:</strong>
        <p>${flowData.expectedResults?.conversionGoals || 'Increased engagement and conversions'}</p>
      </div>
    </div>
  `;
}