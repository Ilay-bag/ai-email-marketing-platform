import { 
  users, campaigns, emails, chatMessages, integrations,
  flows, flowNodes, flowEdges, flowExecutions, flowEvents,
  contacts, emailLists, contactListMemberships, emailTemplates,
  campaignAnalytics, abTests, automations, automationSteps, automationExecutions, assets,
  type User, type InsertUser,
  type Campaign, type InsertCampaign,
  type Email, type InsertEmail,
  type ChatMessage, type InsertChatMessage,
  type Integration, type InsertIntegration,
  type Flow, type InsertFlow,
  type FlowNode, type InsertFlowNode,
  type FlowEdge, type InsertFlowEdge,
  type FlowExecution, type InsertFlowExecution,
  type FlowEvent, type InsertFlowEvent,
  type Contact, type InsertContact,
  type EmailList, type InsertEmailList,
  type EmailTemplate, type InsertEmailTemplate,
  type CampaignAnalytics, type InsertCampaignAnalytics,
  type ABTest, type Automation, type InsertAutomation,
  type AutomationStep, type AutomationExecution, type Asset, type InsertAsset
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Campaign operations
  getCampaign(id: number): Promise<Campaign | undefined>;
  getCampaignsByUser(userId: number): Promise<Campaign[]>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, campaign: Partial<Campaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: number): Promise<boolean>;

  // Email operations
  getEmail(id: number): Promise<Email | undefined>;
  getEmailsByCampaign(campaignId: number): Promise<Email[]>;
  getEmailsLibrary(): Promise<Email[]>;
  createEmail(email: InsertEmail): Promise<Email>;
  updateEmail(id: number, email: Partial<Email>): Promise<Email | undefined>;
  deleteEmail(id: number): Promise<boolean>;

  // Chat message operations
  getChatMessagesByCampaign(campaignId: number): Promise<ChatMessage[]>;
  getChatMessagesByUser(userId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearChatMessages(userId: number): Promise<boolean>;

  // Integration operations
  getIntegrationsByUser(userId: number): Promise<Integration[]>;
  getIntegrationByProvider(userId: number, provider: string): Promise<Integration | undefined>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, integration: Partial<Integration>): Promise<Integration | undefined>;
  deleteIntegration(id: number): Promise<boolean>;

  // Flow operations
  getFlowsByUser(userId: number): Promise<Flow[]>;
  getFlow(id: string): Promise<Flow | undefined>;
  createFlow(flow: InsertFlow): Promise<Flow>;
  updateFlow(id: string, flow: Partial<Flow>): Promise<Flow | undefined>;
  deleteFlow(id: string): Promise<boolean>;

  // Flow Node operations
  getFlowNodes(flowId: string): Promise<FlowNode[]>;
  createFlowNode(node: InsertFlowNode): Promise<FlowNode>;
  updateFlowNode(id: string, node: Partial<FlowNode>): Promise<FlowNode | undefined>;
  deleteFlowNode(id: string): Promise<boolean>;

  // Flow Edge operations
  getFlowEdges(flowId: string): Promise<FlowEdge[]>;
  createFlowEdge(edge: InsertFlowEdge): Promise<FlowEdge>;
  deleteFlowEdge(id: string): Promise<boolean>;

  // Flow Execution operations
  getFlowExecutions(flowId: string): Promise<FlowExecution[]>;
  createFlowExecution(execution: InsertFlowExecution): Promise<FlowExecution>;
  updateFlowExecution(id: string, execution: Partial<FlowExecution>): Promise<FlowExecution | undefined>;

  // Flow Event operations
  createFlowEvent(event: InsertFlowEvent): Promise<FlowEvent>;
  getFlowEvents(userId: number): Promise<FlowEvent[]>;

  // Contact operations
  getContact(id: number): Promise<Contact | undefined>;
  getContactByEmail(userId: number, email: string): Promise<Contact | undefined>;
  getContactsByUser(userId: number): Promise<Contact[]>;
  getContactsByList(listId: number): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, contact: Partial<Contact>): Promise<Contact | undefined>;
  deleteContact(id: number): Promise<boolean>;
  removeContactFromAllLists(contactId: number): Promise<void>;

  // Email List operations
  getEmailList(id: number): Promise<EmailList | undefined>;
  getEmailListsByUser(userId: number): Promise<EmailList[]>;
  createEmailList(list: InsertEmailList): Promise<EmailList>;
  updateEmailList(id: number, list: Partial<EmailList>): Promise<EmailList | undefined>;
  deleteEmailList(id: number): Promise<boolean>;
  addContactToList(contactId: number, listId: number): Promise<void>;
  removeContactFromList(contactId: number, listId: number): Promise<void>;
  getListSubscriberCount(listId: number): Promise<number>;
  getContactLists(contactId: number): Promise<EmailList[]>;

  // Email Template operations
  getEmailTemplate(id: number): Promise<EmailTemplate | undefined>;
  getEmailTemplatesByUser(userId: number): Promise<EmailTemplate[]>;
  getPublicEmailTemplates(): Promise<EmailTemplate[]>;
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  updateEmailTemplate(id: number, template: Partial<EmailTemplate>): Promise<EmailTemplate | undefined>;
  deleteEmailTemplate(id: number): Promise<boolean>;

  // Campaign Analytics operations
  createCampaignAnalytics(analytics: InsertCampaignAnalytics): Promise<CampaignAnalytics>;
  getCampaignAnalytics(campaignId: number): Promise<CampaignAnalytics[]>;
  getContactAnalytics(contactId: number): Promise<CampaignAnalytics[]>;
  getAllAnalyticsByUser(userId: number): Promise<CampaignAnalytics[]>;
  getABTestAnalytics(testId: number, variant: string): Promise<CampaignAnalytics[]>;

  // A/B Test operations
  getABTest(id: number): Promise<ABTest | undefined>;
  createABTest(test: any): Promise<ABTest>;
  updateABTest(id: number, test: Partial<ABTest>): Promise<ABTest | undefined>;

  // Automation operations
  getAutomation(id: number): Promise<Automation | undefined>;
  getAutomationsByUser(userId: number): Promise<Automation[]>;
  getAutomationsByTrigger(triggerType: string): Promise<Automation[]>;
  createAutomation(automation: InsertAutomation): Promise<Automation>;
  updateAutomation(id: number, automation: Partial<Automation>): Promise<Automation | undefined>;
  deleteAutomation(id: number): Promise<boolean>;

  // Automation Step operations
  getAutomationSteps(automationId: number): Promise<AutomationStep[]>;
  getAutomationStep(id: number): Promise<AutomationStep | undefined>;
  createAutomationStep(step: any): Promise<AutomationStep>;
  updateAutomationStep(id: number, step: Partial<AutomationStep>): Promise<AutomationStep | undefined>;

  // Automation Execution operations
  getAutomationExecution(id: number): Promise<AutomationExecution | undefined>;
  getAutomationExecutions(automationId: number): Promise<AutomationExecution[]>;
  getActiveAutomationExecution(automationId: number, contactId: number): Promise<AutomationExecution | undefined>;
  createAutomationExecution(execution: any): Promise<AutomationExecution>;
  updateAutomationExecution(id: number, execution: Partial<AutomationExecution>): Promise<AutomationExecution | undefined>;
  pauseAutomationExecutions(automationId: number): Promise<void>;
  resumeAutomationExecutions(automationId: number): Promise<void>;

  // Asset operations
  createAsset(asset: InsertAsset): Promise<Asset>;
  getAssetsByUser(userId: number): Promise<Asset[]>;
  deleteAsset(id: number): Promise<boolean>;

  // Utility operations
  getAllCampaigns(): Promise<Campaign[]>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Create a demo user if not exists
    this.ensureDemoUser();
  }

  private async ensureDemoUser() {
    try {
      const existingUser = await this.getUserByEmail("demo@example.com");
      if (!existingUser) {
        await this.createUser({
          username: "demo",
          email: "demo@example.com",
          password: "password123"
        });
      }
    } catch (error) {
      console.error("Error creating demo user:", error);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Campaign operations
  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async getCampaignsByUser(userId: number): Promise<Campaign[]> {
    return await db.select().from(campaigns).where(eq(campaigns.userId, userId));
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const [campaign] = await db
      .insert(campaigns)
      .values(insertCampaign)
      .returning();
    return campaign;
  }

  async updateCampaign(id: number, updates: Partial<Campaign>): Promise<Campaign | undefined> {
    // Filter out undefined values and ensure proper timestamp handling
    const filteredUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );
    
    const [campaign] = await db
      .update(campaigns)
      .set({ ...filteredUpdates, updatedAt: new Date() })
      .where(eq(campaigns.id, id))
      .returning();
    return campaign || undefined;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    const result = await db.delete(campaigns).where(eq(campaigns.id, id));
    return result.rowCount > 0;
  }

  // Chat message operations
  async getChatMessagesByCampaign(campaignId: number): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages).where(eq(chatMessages.campaignId, campaignId));
  }

  async getChatMessagesByUser(userId: number): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages).where(eq(chatMessages.userId, userId));
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chatMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async clearChatMessages(userId: number): Promise<boolean> {
    try {
      await db.delete(chatMessages).where(eq(chatMessages.userId, userId));
      return true;
    } catch (error) {
      console.error("Error clearing chat messages:", error);
      return false;
    }
  }

  // Integration operations
  async getIntegrationsByUser(userId: number): Promise<Integration[]> {
    return await db.select().from(integrations).where(eq(integrations.userId, userId));
  }

  async getIntegrationByProvider(userId: number, provider: string): Promise<Integration | undefined> {
    const [integration] = await db
      .select()
      .from(integrations)
      .where(and(eq(integrations.userId, userId), eq(integrations.provider, provider)));
    return integration || undefined;
  }

  async createIntegration(insertIntegration: InsertIntegration): Promise<Integration> {
    const [integration] = await db
      .insert(integrations)
      .values(insertIntegration)
      .returning();
    return integration;
  }

  async updateIntegration(id: number, updates: Partial<Integration>): Promise<Integration | undefined> {
    const [integration] = await db
      .update(integrations)
      .set(updates)
      .where(eq(integrations.id, id))
      .returning();
    return integration || undefined;
  }

  async deleteIntegration(id: number): Promise<boolean> {
    const result = await db.delete(integrations).where(eq(integrations.id, id));
    return result.rowCount > 0;
  }

  // Email operations
  async getEmail(id: number): Promise<Email | undefined> {
    const [email] = await db.select().from(emails).where(eq(emails.id, id));
    return email || undefined;
  }

  async getEmailsByCampaign(campaignId: number): Promise<Email[]> {
    return await db.select().from(emails).where(eq(emails.campaignId, campaignId));
  }

  async getEmailsLibrary(): Promise<Email[]> {
    return await db.select().from(emails);
  }

  async createEmail(insertEmail: InsertEmail): Promise<Email> {
    const [email] = await db
      .insert(emails)
      .values(insertEmail)
      .returning();
    return email;
  }

  async updateEmail(id: number, updates: Partial<Email>): Promise<Email | undefined> {
    // Filter out undefined values and ensure proper timestamp handling
    const filteredUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );
    
    const [email] = await db
      .update(emails)
      .set({ ...filteredUpdates, updatedAt: new Date() })
      .where(eq(emails.id, id))
      .returning();
    return email || undefined;
  }

  async deleteEmail(id: number): Promise<boolean> {
    const result = await db.delete(emails).where(eq(emails.id, id));
    return result.rowCount > 0;
  }

  // Flow operations
  async getFlowsByUser(userId: number): Promise<Flow[]> {
    try {
      const results = await db.select().from(flows).where(eq(flows.userId, userId));
      return results;
    } catch (error) {
      console.error("Error getting flows:", error);
      return [];
    }
  }

  async getFlow(id: string): Promise<Flow | undefined> {
    try {
      const [flow] = await db.select().from(flows).where(eq(flows.id, id));
      if (!flow) return undefined;

      // Get nodes and edges
      const nodes = await this.getFlowNodes(id);
      const edges = await this.getFlowEdges(id);

      return {
        ...flow,
        nodes,
        edges
      } as Flow & { nodes: FlowNode[], edges: FlowEdge[] };
    } catch (error) {
      console.error("Error getting flow:", error);
      return undefined;
    }
  }

  async createFlow(insertFlow: InsertFlow): Promise<Flow> {
    try {
      const [flow] = await db.insert(flows).values(insertFlow).returning();
      return flow;
    } catch (error) {
      console.error("Error creating flow:", error);
      throw error;
    }
  }

  async updateFlow(id: string, updates: Partial<Flow>): Promise<Flow | undefined> {
    try {
      const [flow] = await db.update(flows).set(updates).where(eq(flows.id, id)).returning();
      return flow;
    } catch (error) {
      console.error("Error updating flow:", error);
      return undefined;
    }
  }

  async deleteFlow(id: string): Promise<boolean> {
    try {
      // Delete related data first
      await db.delete(flowNodes).where(eq(flowNodes.flowId, id));
      await db.delete(flowEdges).where(eq(flowEdges.flowId, id));
      await db.delete(flowExecutions).where(eq(flowExecutions.flowId, id));
      await db.delete(flows).where(eq(flows.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting flow:", error);
      return false;
    }
  }

  // Flow Node operations
  async getFlowNodes(flowId: string): Promise<FlowNode[]> {
    try {
      const results = await db.select().from(flowNodes).where(eq(flowNodes.flowId, flowId));
      return results;
    } catch (error) {
      console.error("Error getting flow nodes:", error);
      return [];
    }
  }

  async createFlowNode(insertNode: InsertFlowNode): Promise<FlowNode> {
    try {
      const [node] = await db.insert(flowNodes).values(insertNode).returning();
      return node;
    } catch (error) {
      console.error("Error creating flow node:", error);
      throw error;
    }
  }

  async updateFlowNode(id: string, updates: Partial<FlowNode>): Promise<FlowNode | undefined> {
    try {
      const [node] = await db.update(flowNodes).set(updates).where(eq(flowNodes.id, id)).returning();
      return node;
    } catch (error) {
      console.error("Error updating flow node:", error);
      return undefined;
    }
  }

  async deleteFlowNode(id: string): Promise<boolean> {
    try {
      await db.delete(flowNodes).where(eq(flowNodes.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting flow node:", error);
      return false;
    }
  }

  // Flow Edge operations
  async getFlowEdges(flowId: string): Promise<FlowEdge[]> {
    try {
      const results = await db.select().from(flowEdges).where(eq(flowEdges.flowId, flowId));
      return results;
    } catch (error) {
      console.error("Error getting flow edges:", error);
      return [];
    }
  }

  async createFlowEdge(insertEdge: InsertFlowEdge): Promise<FlowEdge> {
    try {
      const [edge] = await db.insert(flowEdges).values(insertEdge).returning();
      return edge;
    } catch (error) {
      console.error("Error creating flow edge:", error);
      throw error;
    }
  }

  async deleteFlowEdge(id: string): Promise<boolean> {
    try {
      await db.delete(flowEdges).where(eq(flowEdges.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting flow edge:", error);
      return false;
    }
  }

  // Flow Execution operations
  async getFlowExecutions(flowId: string): Promise<FlowExecution[]> {
    try {
      const results = await db.select().from(flowExecutions).where(eq(flowExecutions.flowId, flowId));
      return results;
    } catch (error) {
      console.error("Error getting flow executions:", error);
      return [];
    }
  }

  async createFlowExecution(insertExecution: InsertFlowExecution): Promise<FlowExecution> {
    try {
      const [execution] = await db.insert(flowExecutions).values(insertExecution).returning();
      return execution;
    } catch (error) {
      console.error("Error creating flow execution:", error);
      throw error;
    }
  }

  async updateFlowExecution(id: string, updates: Partial<FlowExecution>): Promise<FlowExecution | undefined> {
    try {
      const [execution] = await db.update(flowExecutions).set(updates).where(eq(flowExecutions.id, id)).returning();
      return execution;
    } catch (error) {
      console.error("Error updating flow execution:", error);
      return undefined;
    }
  }

  // Flow Event operations
  async createFlowEvent(insertEvent: InsertFlowEvent): Promise<FlowEvent> {
    try {
      const [event] = await db.insert(flowEvents).values(insertEvent).returning();
      return event;
    } catch (error) {
      console.error("Error creating flow event:", error);
      throw error;
    }
  }

  async getFlowEvents(userId: number): Promise<FlowEvent[]> {
    try {
      const results = await db.select().from(flowEvents).where(eq(flowEvents.userId, userId));
      return results;
    } catch (error) {
      console.error("Error getting flow events:", error);
      return [];
    }
  }

  // Contact operations
  async getContact(id: number): Promise<Contact | undefined> {
    const [contact] = await db.select().from(contacts).where(eq(contacts.id, id));
    return contact || undefined;
  }

  async getContactByEmail(userId: number, email: string): Promise<Contact | undefined> {
    const [contact] = await db.select().from(contacts)
      .where(and(eq(contacts.userId, userId), eq(contacts.email, email)));
    return contact || undefined;
  }

  async getContactsByUser(userId: number): Promise<Contact[]> {
    return await db.select().from(contacts).where(eq(contacts.userId, userId));
  }

  async getContactsByList(listId: number): Promise<Contact[]> {
    return await db.select({
      id: contacts.id,
      userId: contacts.userId,
      email: contacts.email,
      firstName: contacts.firstName,
      lastName: contacts.lastName,
      phone: contacts.phone,
      organization: contacts.organization,
      tags: contacts.tags,
      customFields: contacts.customFields,
      isSubscribed: contacts.isSubscribed,
      consentTimestamp: contacts.consentTimestamp,
      engagementScore: contacts.engagementScore,
      lastActivityAt: contacts.lastActivityAt,
      createdAt: contacts.createdAt,
      updatedAt: contacts.updatedAt
    })
    .from(contacts)
    .innerJoin(contactListMemberships, eq(contacts.id, contactListMemberships.contactId))
    .where(eq(contactListMemberships.listId, listId));
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }

  async updateContact(id: number, contact: Partial<Contact>): Promise<Contact | undefined> {
    const [updatedContact] = await db.update(contacts)
      .set({ ...contact, updatedAt: new Date() })
      .where(eq(contacts.id, id))
      .returning();
    return updatedContact || undefined;
  }

  async deleteContact(id: number): Promise<boolean> {
    const result = await db.delete(contacts).where(eq(contacts.id, id));
    return result.rowCount > 0;
  }

  async removeContactFromAllLists(contactId: number): Promise<void> {
    await db.delete(contactListMemberships).where(eq(contactListMemberships.contactId, contactId));
  }

  // Email List operations
  async getEmailList(id: number): Promise<EmailList | undefined> {
    const [list] = await db.select().from(emailLists).where(eq(emailLists.id, id));
    return list || undefined;
  }

  async getEmailListsByUser(userId: number): Promise<EmailList[]> {
    return await db.select().from(emailLists).where(eq(emailLists.userId, userId));
  }

  async createEmailList(list: InsertEmailList): Promise<EmailList> {
    const [newList] = await db.insert(emailLists).values(list).returning();
    return newList;
  }

  async updateEmailList(id: number, list: Partial<EmailList>): Promise<EmailList | undefined> {
    const [updatedList] = await db.update(emailLists)
      .set({ ...list, updatedAt: new Date() })
      .where(eq(emailLists.id, id))
      .returning();
    return updatedList || undefined;
  }

  async deleteEmailList(id: number): Promise<boolean> {
    // Remove all memberships first
    await db.delete(contactListMemberships).where(eq(contactListMemberships.listId, id));
    const result = await db.delete(emailLists).where(eq(emailLists.id, id));
    return result.rowCount > 0;
  }

  async addContactToList(contactId: number, listId: number): Promise<void> {
    await db.insert(contactListMemberships).values({ contactId, listId });
  }

  async removeContactFromList(contactId: number, listId: number): Promise<void> {
    await db.delete(contactListMemberships)
      .where(and(
        eq(contactListMemberships.contactId, contactId),
        eq(contactListMemberships.listId, listId)
      ));
  }

  async getListSubscriberCount(listId: number): Promise<number> {
    const result = await db.select().from(contactListMemberships)
      .where(eq(contactListMemberships.listId, listId));
    return result.length;
  }

  async getContactLists(contactId: number): Promise<EmailList[]> {
    return await db.select({
      id: emailLists.id,
      userId: emailLists.userId,
      name: emailLists.name,
      description: emailLists.description,
      type: emailLists.type,
      segmentRules: emailLists.segmentRules,
      isActive: emailLists.isActive,
      subscriberCount: emailLists.subscriberCount,
      createdAt: emailLists.createdAt,
      updatedAt: emailLists.updatedAt
    })
    .from(emailLists)
    .innerJoin(contactListMemberships, eq(emailLists.id, contactListMemberships.listId))
    .where(eq(contactListMemberships.contactId, contactId));
  }

  // Email Template operations
  async getEmailTemplate(id: number): Promise<EmailTemplate | undefined> {
    const [template] = await db.select().from(emailTemplates).where(eq(emailTemplates.id, id));
    return template || undefined;
  }

  async getEmailTemplatesByUser(userId: number): Promise<EmailTemplate[]> {
    return await db.select().from(emailTemplates).where(eq(emailTemplates.userId, userId));
  }

  async getPublicEmailTemplates(): Promise<EmailTemplate[]> {
    return await db.select().from(emailTemplates).where(eq(emailTemplates.isPublic, true));
  }

  async createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate> {
    const [newTemplate] = await db.insert(emailTemplates).values(template).returning();
    return newTemplate;
  }

  async updateEmailTemplate(id: number, template: Partial<EmailTemplate>): Promise<EmailTemplate | undefined> {
    const [updatedTemplate] = await db.update(emailTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(emailTemplates.id, id))
      .returning();
    return updatedTemplate || undefined;
  }

  async deleteEmailTemplate(id: number): Promise<boolean> {
    const result = await db.delete(emailTemplates).where(eq(emailTemplates.id, id));
    return result.rowCount > 0;
  }

  // Campaign Analytics operations
  async createCampaignAnalytics(analytics: InsertCampaignAnalytics): Promise<CampaignAnalytics> {
    const [newAnalytics] = await db.insert(campaignAnalytics).values(analytics).returning();
    return newAnalytics;
  }

  async getCampaignAnalytics(campaignId: number): Promise<CampaignAnalytics[]> {
    return await db.select().from(campaignAnalytics).where(eq(campaignAnalytics.campaignId, campaignId));
  }

  async getContactAnalytics(contactId: number): Promise<CampaignAnalytics[]> {
    return await db.select().from(campaignAnalytics).where(eq(campaignAnalytics.contactId, contactId));
  }

  async getAllAnalyticsByUser(userId: number): Promise<CampaignAnalytics[]> {
    return await db.select({
      id: campaignAnalytics.id,
      campaignId: campaignAnalytics.campaignId,
      emailId: campaignAnalytics.emailId,
      contactId: campaignAnalytics.contactId,
      eventType: campaignAnalytics.eventType,
      eventData: campaignAnalytics.eventData,
      userAgent: campaignAnalytics.userAgent,
      ipAddress: campaignAnalytics.ipAddress,
      createdAt: campaignAnalytics.createdAt
    })
    .from(campaignAnalytics)
    .innerJoin(campaigns, eq(campaignAnalytics.campaignId, campaigns.id))
    .where(eq(campaigns.userId, userId));
  }

  async getABTestAnalytics(testId: number, variant: string): Promise<CampaignAnalytics[]> {
    // This would need additional logic to link AB tests to analytics
    return await db.select().from(campaignAnalytics)
      .where(eq(campaignAnalytics.eventData, { abTestId: testId, variant }));
  }

  // A/B Test operations
  async getABTest(id: number): Promise<ABTest | undefined> {
    const [test] = await db.select().from(abTests).where(eq(abTests.id, id));
    return test || undefined;
  }

  async createABTest(test: any): Promise<ABTest> {
    const [newTest] = await db.insert(abTests).values(test).returning();
    return newTest;
  }

  async updateABTest(id: number, test: Partial<ABTest>): Promise<ABTest | undefined> {
    const [updatedTest] = await db.update(abTests)
      .set(test)
      .where(eq(abTests.id, id))
      .returning();
    return updatedTest || undefined;
  }

  // Automation operations
  async getAutomation(id: number): Promise<Automation | undefined> {
    const [automation] = await db.select().from(automations).where(eq(automations.id, id));
    return automation || undefined;
  }

  async getAutomationsByUser(userId: number): Promise<Automation[]> {
    return await db.select().from(automations).where(eq(automations.userId, userId));
  }

  async getAutomationsByTrigger(triggerType: string): Promise<Automation[]> {
    return await db.select().from(automations)
      .where(and(eq(automations.triggerType, triggerType as any), eq(automations.isActive, true)));
  }

  async createAutomation(automation: InsertAutomation): Promise<Automation> {
    const [newAutomation] = await db.insert(automations).values(automation).returning();
    return newAutomation;
  }

  async updateAutomation(id: number, automation: Partial<Automation>): Promise<Automation | undefined> {
    const [updatedAutomation] = await db.update(automations)
      .set({ ...automation, updatedAt: new Date() })
      .where(eq(automations.id, id))
      .returning();
    return updatedAutomation || undefined;
  }

  async deleteAutomation(id: number): Promise<boolean> {
    // Delete related data first
    await db.delete(automationSteps).where(eq(automationSteps.automationId, id));
    await db.delete(automationExecutions).where(eq(automationExecutions.automationId, id));
    const result = await db.delete(automations).where(eq(automations.id, id));
    return result.rowCount > 0;
  }

  // Automation Step operations
  async getAutomationSteps(automationId: number): Promise<AutomationStep[]> {
    return await db.select().from(automationSteps)
      .where(eq(automationSteps.automationId, automationId))
      .orderBy(automationSteps.stepOrder);
  }

  async getAutomationStep(id: number): Promise<AutomationStep | undefined> {
    const [step] = await db.select().from(automationSteps).where(eq(automationSteps.id, id));
    return step || undefined;
  }

  async createAutomationStep(step: any): Promise<AutomationStep> {
    const [newStep] = await db.insert(automationSteps).values(step).returning();
    return newStep;
  }

  async updateAutomationStep(id: number, step: Partial<AutomationStep>): Promise<AutomationStep | undefined> {
    const [updatedStep] = await db.update(automationSteps)
      .set(step)
      .where(eq(automationSteps.id, id))
      .returning();
    return updatedStep || undefined;
  }

  // Automation Execution operations
  async getAutomationExecution(id: number): Promise<AutomationExecution | undefined> {
    const [execution] = await db.select().from(automationExecutions).where(eq(automationExecutions.id, id));
    return execution || undefined;
  }

  async getAutomationExecutions(automationId: number): Promise<AutomationExecution[]> {
    return await db.select().from(automationExecutions)
      .where(eq(automationExecutions.automationId, automationId));
  }

  async getActiveAutomationExecution(automationId: number, contactId: number): Promise<AutomationExecution | undefined> {
    const [execution] = await db.select().from(automationExecutions)
      .where(and(
        eq(automationExecutions.automationId, automationId),
        eq(automationExecutions.contactId, contactId),
        eq(automationExecutions.status, 'active')
      ));
    return execution || undefined;
  }

  async createAutomationExecution(execution: any): Promise<AutomationExecution> {
    const [newExecution] = await db.insert(automationExecutions).values(execution).returning();
    return newExecution;
  }

  async updateAutomationExecution(id: number, execution: Partial<AutomationExecution>): Promise<AutomationExecution | undefined> {
    const [updatedExecution] = await db.update(automationExecutions)
      .set(execution)
      .where(eq(automationExecutions.id, id))
      .returning();
    return updatedExecution || undefined;
  }

  async pauseAutomationExecutions(automationId: number): Promise<void> {
    await db.update(automationExecutions)
      .set({ status: 'paused' })
      .where(and(
        eq(automationExecutions.automationId, automationId),
        eq(automationExecutions.status, 'active')
      ));
  }

  async resumeAutomationExecutions(automationId: number): Promise<void> {
    await db.update(automationExecutions)
      .set({ status: 'active' })
      .where(and(
        eq(automationExecutions.automationId, automationId),
        eq(automationExecutions.status, 'paused')
      ));
  }

  // Asset operations
  async createAsset(asset: InsertAsset): Promise<Asset> {
    const [newAsset] = await db.insert(assets).values(asset).returning();
    return newAsset;
  }

  async getAssetsByUser(userId: number): Promise<Asset[]> {
    return await db.select().from(assets).where(eq(assets.userId, userId));
  }

  async deleteAsset(id: number): Promise<boolean> {
    const result = await db.delete(assets).where(eq(assets.id, id));
    return result.rowCount > 0;
  }

  // Utility operations
  async getAllCampaigns(): Promise<Campaign[]> {
    return await db.select().from(campaigns);
  }
}

export const storage = new DatabaseStorage();
