export const emailExamples = [
  {
    name: "Welcome Email",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Platform</title>
    <style>
        @media screen and (max-width: 480px) {
            .container { width: 100% !important; }
            .content { padding: 20px !important; }
            .button { width: 100% !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4;">
        <tr>
            <td align="center" style="padding: 20px 0;">
                <table class="container" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <tr>
                        <td class="content" style="padding: 40px;">
                            <h1 style="color: #333333; font-size: 28px; margin: 0 0 20px 0; text-align: center;">Welcome, {{first_name}}!</h1>
                            <p style="color: #666666; font-size: 16px; line-height: 24px; margin: 0 0 20px 0;">
                                Thank you for joining our platform. We're excited to have you on board!
                            </p>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{{cta_link}}" class="button" style="background-color: #007bff; color: #ffffff; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                                    Get Started
                                </a>
                            </div>
                            <p style="color: #666666; font-size: 14px; line-height: 20px; margin: 20px 0 0 0; text-align: center;">
                                If you have any questions, feel free to reach out to our support team.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>`
  },
  {
    name: "Product Promotion",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Special Offer - 20% Off</title>
    <style>
        @media screen and (max-width: 480px) {
            .container { width: 100% !important; }
            .content { padding: 20px !important; }
            .product-grid { width: 100% !important; }
            .product-item { width: 100% !important; margin-bottom: 20px !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f8f9fa;">
    <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center" style="padding: 20px 0;">
                <table class="container" width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff;">
                    <tr>
                        <td style="background-color: #FF6F61; padding: 20px; text-align: center;">
                            <h1 style="color: #ffffff; font-size: 32px; margin: 0;">20% OFF SALE</h1>
                            <p style="color: #ffffff; font-size: 18px; margin: 10px 0 0 0;">Limited Time Offer</p>
                        </td>
                    </tr>
                    <tr>
                        <td class="content" style="padding: 40px;">
                            <p style="color: #333333; font-size: 16px; line-height: 24px; margin: 0 0 20px 0;">
                                Hi {{first_name}},
                            </p>
                            <p style="color: #666666; font-size: 16px; line-height: 24px; margin: 0 0 30px 0;">
                                Don't miss out on our biggest sale of the year! Get 20% off on all products.
                            </p>
                            <table class="product-grid" width="100%" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td class="product-item" width="48%" style="padding: 20px; background-color: #f8f9fa; border-radius: 8px; margin-right: 4%;">
                                        <img src="{{product_image_1}}" width="100%" style="border-radius: 4px; margin-bottom: 15px;" alt="Product 1">
                                        <h3 style="color: #333333; font-size: 18px; margin: 0 0 10px 0;">{{product_name_1}}</h3>
                                        <p style="color: #FF6F61; font-size: 20px; font-weight: bold; margin: 0;">{{product_price_1}}</p>
                                    </td>
                                    <td class="product-item" width="48%" style="padding: 20px; background-color: #f8f9fa; border-radius: 8px;">
                                        <img src="{{product_image_2}}" width="100%" style="border-radius: 4px; margin-bottom: 15px;" alt="Product 2">
                                        <h3 style="color: #333333; font-size: 18px; margin: 0 0 10px 0;">{{product_name_2}}</h3>
                                        <p style="color: #FF6F61; font-size: 20px; font-weight: bold; margin: 0;">{{product_price_2}}</p>
                                    </td>
                                </tr>
                            </table>
                            <div style="text-align: center; margin: 40px 0;">
                                <a href="{{shop_link}}" style="background-color: #FF6F61; color: #ffffff; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 16px; display: inline-block;">
                                    Shop Now
                                </a>
                            </div>
                            <p style="color: #999999; font-size: 14px; text-align: center; margin: 0;">
                                *Offer valid until {{expiry_date}}. Terms and conditions apply.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>`
  },
  {
    name: "Newsletter",
    html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Newsletter</title>
    <style>
        @media screen and (max-width: 480px) {
            .container { width: 100% !important; }
            .content { padding: 20px !important; }
            .article { margin-bottom: 30px !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; font-family: Georgia, serif; background-color: #ffffff;">
    <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center" style="padding: 20px 0;">
                <table class="container" width="600" cellpadding="0" cellspacing="0" style="border: 1px solid #e0e0e0;">
                    <tr>
                        <td style="background-color: #333333; padding: 30px; text-align: center;">
                            <h1 style="color: #ffffff; font-size: 24px; margin: 0; font-weight: normal;">Weekly Insights</h1>
                            <p style="color: #cccccc; font-size: 14px; margin: 10px 0 0 0;">{{current_date}}</p>
                        </td>
                    </tr>
                    <tr>
                        <td class="content" style="padding: 40px;">
                            <div class="article" style="margin-bottom: 40px; padding-bottom: 30px; border-bottom: 1px solid #e0e0e0;">
                                <h2 style="color: #333333; font-size: 22px; margin: 0 0 15px 0; font-weight: normal;">{{article_title_1}}</h2>
                                <p style="color: #666666; font-size: 16px; line-height: 26px; margin: 0 0 15px 0;">
                                    {{article_excerpt_1}}
                                </p>
                                <a href="{{article_link_1}}" style="color: #007bff; text-decoration: none; font-weight: bold;">Read More →</a>
                            </div>
                            <div class="article" style="margin-bottom: 40px; padding-bottom: 30px; border-bottom: 1px solid #e0e0e0;">
                                <h2 style="color: #333333; font-size: 22px; margin: 0 0 15px 0; font-weight: normal;">{{article_title_2}}</h2>
                                <p style="color: #666666; font-size: 16px; line-height: 26px; margin: 0 0 15px 0;">
                                    {{article_excerpt_2}}
                                </p>
                                <a href="{{article_link_2}}" style="color: #007bff; text-decoration: none; font-weight: bold;">Read More →</a>
                            </div>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{{website_link}}" style="color: #007bff; text-decoration: none; font-weight: bold; font-size: 16px;">
                                    Visit Our Website
                                </a>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #f8f9fa; padding: 20px; text-align: center;">
                            <p style="color: #999999; font-size: 14px; margin: 0 0 10px 0;">
                                You're receiving this because you subscribed to our newsletter.
                            </p>
                            <a href="{{unsubscribe_link}}" style="color: #999999; font-size: 12px; text-decoration: underline;">Unsubscribe</a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>`
  }
];