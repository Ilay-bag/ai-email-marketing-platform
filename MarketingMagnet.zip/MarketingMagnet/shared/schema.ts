import { pgTable, text, serial, integer, boolean, timestamp, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  type: text("type", { enum: ["abandoned_cart", "welcome", "promo", "product_launch", "re_engagement"] }).notNull(),
  triggers: jsonb("triggers").default([]), // Array of { event: string, delay: string }
  status: text("status", { enum: ["draft", "scheduled", "sent", "active"] }).notNull().default("draft"),
  description: text("description"),
  scheduledAt: timestamp("scheduled_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const emails = pgTable("emails", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id"),
  subject: text("subject").notNull(),
  html: text("html").notNull(),
  json: jsonb("json").notNull(), // Unlayer design JSON
  sequenceOrder: integer("sequence_order").default(0), // Order in campaign sequence
  delay: text("delay"), // e.g. "1h", "24h", "72h"
  isTemplate: boolean("is_template").default(false), // Standalone template
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  campaignId: integer("campaign_id"),
  role: text("role", { enum: ["user", "assistant"] }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const integrations = pgTable("integrations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  provider: text("provider").notNull(), // klaviyo, mailchimp, shopify, etc.
  apiKey: text("api_key"), // for API key based auth
  accessToken: text("access_token"), // for OAuth
  refreshToken: text("refresh_token"), // for OAuth
  expiresAt: timestamp("expires_at"), // token expiration
  accountEmail: text("account_email"), // connected account email
  accountId: text("account_id"), // platform account ID
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  connectedAt: timestamp("connected_at").defaultNow(),
});

// Flow-based campaign builder tables
export const flows = pgTable("flows", {
  id: text("id").primaryKey(), // UUID as text
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  status: text("status", { enum: ["active", "paused", "draft"] }).notNull().default("draft"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const flowNodes = pgTable("flow_nodes", {
  id: text("id").primaryKey(), // UUID as text
  flowId: text("flow_id").notNull(),
  type: text("type", { enum: ["trigger", "delay", "filter", "action", "split"] }).notNull(),
  x: integer("x").notNull().default(0),
  y: integer("y").notNull().default(0),
  settings: jsonb("settings").notNull().default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const flowEdges = pgTable("flow_edges", {
  id: text("id").primaryKey(), // UUID as text
  flowId: text("flow_id").notNull(),
  sourceNode: text("source_node").notNull(),
  targetNode: text("target_node").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const flowExecutions = pgTable("flow_executions", {
  id: text("id").primaryKey(), // UUID as text
  flowId: text("flow_id").notNull(),
  nodeId: text("node_id").notNull(),
  userId: integer("user_id").notNull(),
  status: text("status", { enum: ["pending", "running", "completed", "failed", "scheduled"] }).notNull(),
  eventData: jsonb("event_data"),
  scheduledAt: timestamp("scheduled_at"),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const flowEvents = pgTable("flow_events", {
  id: text("id").primaryKey(), // UUID as text
  userId: integer("user_id").notNull(),
  eventType: text("event_type").notNull(), // cart.abandoned, user.signup, order.placed
  payload: jsonb("payload").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Advanced ESP-compatible tables for comprehensive email marketing

// Contact/Subscriber management
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  email: text("email").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  phone: text("phone"),
  organization: text("organization"),
  tags: jsonb("tags").default([]), // Array of tag strings
  customFields: jsonb("custom_fields").default({}), // Key-value pairs for custom data
  isSubscribed: boolean("is_subscribed").default(true),
  consentTimestamp: timestamp("consent_timestamp"),
  engagementScore: integer("engagement_score").default(0),
  lastActivityAt: timestamp("last_activity_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Email lists and segments
export const emailLists = pgTable("email_lists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type", { enum: ["static", "dynamic"] }).notNull().default("static"),
  segmentRules: jsonb("segment_rules").default({}), // For dynamic segments
  isActive: boolean("is_active").default(true),
  subscriberCount: integer("subscriber_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Contact-List relationships
export const contactListMemberships = pgTable("contact_list_memberships", {
  id: serial("id").primaryKey(),
  contactId: integer("contact_id").notNull(),
  listId: integer("list_id").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Email templates library
export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  category: text("category").default("custom"),
  thumbnail: text("thumbnail"), // Base64 or URL
  subject: text("subject"),
  preheader: text("preheader"),
  content: jsonb("content").notNull(), // Modular email components
  isPublic: boolean("is_public").default(false),
  usageCount: integer("usage_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaign analytics and tracking
export const campaignAnalytics = pgTable("campaign_analytics", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  emailId: integer("email_id"),
  contactId: integer("contact_id"),
  eventType: text("event_type", { 
    enum: ["sent", "delivered", "opened", "clicked", "bounced", "unsubscribed", "marked_spam"] 
  }).notNull(),
  eventData: jsonb("event_data"), // Additional context (link clicked, device, location)
  userAgent: text("user_agent"),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at").defaultNow(),
});

// A/B Testing campaigns
export const abTests = pgTable("ab_tests", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  testType: text("test_type", { enum: ["subject", "content", "send_time", "from_name"] }).notNull(),
  variantA: jsonb("variant_a").notNull(),
  variantB: jsonb("variant_b").notNull(),
  splitPercentage: integer("split_percentage").default(50), // 0-100
  winningVariant: text("winning_variant"), // 'A' or 'B'
  status: text("status", { enum: ["running", "completed", "paused"] }).default("running"),
  startedAt: timestamp("started_at").defaultNow(),
  endedAt: timestamp("ended_at"),
});

// Automation workflows (enhanced flows)
export const automations = pgTable("automations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  triggerType: text("trigger_type", { 
    enum: ["list_signup", "cart_abandoned", "purchase_completed", "birthday", "custom_event", "tag_added"] 
  }).notNull(),
  triggerSettings: jsonb("trigger_settings").default({}),
  isActive: boolean("is_active").default(false),
  totalEntered: integer("total_entered").default(0),
  totalCompleted: integer("total_completed").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Automation steps/emails in sequence
export const automationSteps = pgTable("automation_steps", {
  id: serial("id").primaryKey(),
  automationId: integer("automation_id").notNull(),
  stepOrder: integer("step_order").notNull(),
  stepType: text("step_type", { 
    enum: ["email", "delay", "condition", "tag_action", "webhook", "sms"] 
  }).notNull(),
  stepSettings: jsonb("step_settings").notNull(),
  emailTemplateId: integer("email_template_id"), // If step is email
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Automation execution tracking
export const automationExecutions = pgTable("automation_executions", {
  id: serial("id").primaryKey(),
  automationId: integer("automation_id").notNull(),
  contactId: integer("contact_id").notNull(),
  currentStepId: integer("current_step_id"),
  status: text("status", { enum: ["active", "completed", "paused", "failed"] }).notNull(),
  enteredAt: timestamp("entered_at").defaultNow(),
  lastStepAt: timestamp("last_step_at"),
  completedAt: timestamp("completed_at"),
  metadata: jsonb("metadata").default({}),
});

// Asset management for images, documents, etc.
export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  fileSize: integer("file_size").notNull(),
  url: text("url").notNull(),
  category: text("category").default("general"), // image, document, logo
  tags: jsonb("tags").default([]),
  isPublic: boolean("is_public").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailSchema = createInsertSchema(emails).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertIntegrationSchema = createInsertSchema(integrations).omit({
  id: true,
  createdAt: true,
});

export const insertFlowSchema = createInsertSchema(flows).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertFlowNodeSchema = createInsertSchema(flowNodes).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertFlowEdgeSchema = createInsertSchema(flowEdges).omit({
  createdAt: true,
});

export const insertFlowExecutionSchema = createInsertSchema(flowExecutions).omit({
  createdAt: true,
});

export const insertFlowEventSchema = createInsertSchema(flowEvents).omit({
  createdAt: true,
});

// Additional insert schemas for new ESP tables
export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailListSchema = createInsertSchema(emailLists).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailTemplateSchema = createInsertSchema(emailTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCampaignAnalyticsSchema = createInsertSchema(campaignAnalytics).omit({
  id: true,
  createdAt: true,
});

export const insertAutomationSchema = createInsertSchema(automations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAssetSchema = createInsertSchema(assets).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;

export type Email = typeof emails.$inferSelect;
export type InsertEmail = z.infer<typeof insertEmailSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;

export type Flow = typeof flows.$inferSelect;
export type InsertFlow = z.infer<typeof insertFlowSchema>;

export type FlowNode = typeof flowNodes.$inferSelect;
export type InsertFlowNode = z.infer<typeof insertFlowNodeSchema>;

export type FlowEdge = typeof flowEdges.$inferSelect;
export type InsertFlowEdge = z.infer<typeof insertFlowEdgeSchema>;

export type FlowExecution = typeof flowExecutions.$inferSelect;
export type InsertFlowExecution = z.infer<typeof insertFlowExecutionSchema>;

export type FlowEvent = typeof flowEvents.$inferSelect;
export type InsertFlowEvent = z.infer<typeof insertFlowEventSchema>;

// Email content structure
export const emailContentSchema = z.object({
  subject: z.string(),
  header: z.object({
    title: z.string(),
    subtitle: z.string().optional(),
    image: z.string().optional(),
    backgroundColor: z.string().optional(),
  }),
  body: z.object({
    sections: z.array(z.object({
      type: z.enum(["text", "image", "button", "features"]),
      content: z.any(),
    })),
  }),
  cta: z.object({
    text: z.string(),
    url: z.string().optional(),
    backgroundColor: z.string().optional(),
  }),
  htmlContent: z.string().optional(),
});

export type EmailContent = z.infer<typeof emailContentSchema>;

// Campaign Flow Schema for Klaviyo-style flows
export const campaignFlowSchema = z.object({
  id: z.number(),
  title: z.string(),
  type: z.enum(["abandoned_cart", "welcome", "promo", "product_launch", "re_engagement"]),
  triggers: z.array(z.object({
    event: z.string(),
    delay: z.string(),
  })),
  status: z.enum(["draft", "scheduled", "sent", "active"]),
  description: z.string().optional(),
  emails: z.array(z.object({
    id: z.number(),
    subject: z.string(),
    sequenceOrder: z.number(),
    delay: z.string().optional(),
    html: z.string(),
    json: z.any(),
  })),
});

export type CampaignFlow = z.infer<typeof campaignFlowSchema>;

// Additional types for new ESP tables
export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

export type EmailList = typeof emailLists.$inferSelect;
export type InsertEmailList = z.infer<typeof insertEmailListSchema>;

export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;

export type CampaignAnalytics = typeof campaignAnalytics.$inferSelect;
export type InsertCampaignAnalytics = z.infer<typeof insertCampaignAnalyticsSchema>;

export type ABTest = typeof abTests.$inferSelect;

export type Automation = typeof automations.$inferSelect;
export type InsertAutomation = z.infer<typeof insertAutomationSchema>;

export type AutomationStep = typeof automationSteps.$inferSelect;
export type AutomationExecution = typeof automationExecutions.$inferSelect;

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;

// Enhanced email content schema with merge tags and personalization
export const enhancedEmailContentSchema = z.object({
  subject: z.string(),
  preheader: z.string().optional(),
  fromName: z.string().optional(),
  replyTo: z.string().optional(),
  components: z.array(z.object({
    id: z.string(),
    type: z.string(),
    content: z.any(),
    styles: z.record(z.any()),
  })),
  globalStyles: z.object({
    backgroundColor: z.string(),
    fontFamily: z.string(),
    fontSize: z.string(),
    color: z.string(),
    maxWidth: z.string(),
  }),
  mergeTagMapping: z.record(z.string()).optional(), // For personalization
  utmParams: z.object({
    source: z.string(),
    medium: z.string(),
    campaign: z.string(),
    term: z.string().optional(),
    content: z.string().optional(),
  }).optional(),
});

export type EnhancedEmailContent = z.infer<typeof enhancedEmailContentSchema>;
