import React, { useState, useCallback, useEffect } from 'react';
import { Link, useRoute } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import ReactFlow, { 
  Node, 
  Edge, 
  Controls, 
  Background, 
  useNodesState, 
  useEdgesState, 
  addEdge,
  Connection,
  ReactFlowProvider,
  Panel,
  MiniMap,
  SelectionMode,
  BackgroundVariant,
  useReactFlow,
  NodeTypes,
  NodeChange,
  EdgeChange,
  applyNodeChanges,
  applyEdgeChanges,
} from 'reactflow';
import { v4 as uuidv4 } from 'uuid';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { 
  Play, 
  Pause, 
  Save, 
  Eye, 
  Plus, 
  ArrowLeft, 
  Settings, 
  Trash2,
  Clock,
  Filter,
  Send,
  GitBranch,
  Zap,
  Timer,
  FileText,
  Target,
  Split,
  Mail,
  CheckCircle,
  XCircle,
  AlertCircle,
  Users,
  ShoppingCart,
  LogIn,
  Package,
  Heart,
  BarChart3,
  Calendar,
  Globe,
  Smartphone,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Flow, FlowNode, FlowEdge, InsertFlow } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import 'reactflow/dist/style.css';

// Custom Node Components
const TriggerNode = ({ data }: { data: any }) => (
  <div className="px-4 py-2 bg-blue-100 border-2 border-blue-300 rounded-lg min-w-[150px]">
    <div className="flex items-center gap-2">
      <Zap className="w-4 h-4 text-blue-600" />
      <span className="font-medium text-blue-800">{data.label}</span>
    </div>
    <div className="text-xs text-blue-600 mt-1">{data.triggerType}</div>
  </div>
);

const DelayNode = ({ data }: { data: any }) => (
  <div className="px-4 py-2 bg-orange-100 border-2 border-orange-300 rounded-lg min-w-[150px]">
    <div className="flex items-center gap-2">
      <Timer className="w-4 h-4 text-orange-600" />
      <span className="font-medium text-orange-800">{data.label}</span>
    </div>
    <div className="text-xs text-orange-600 mt-1">{data.delayTime}</div>
  </div>
);

const FilterNode = ({ data }: { data: any }) => (
  <div className="px-4 py-2 bg-purple-100 border-2 border-purple-300 rounded-lg min-w-[150px]">
    <div className="flex items-center gap-2">
      <Filter className="w-4 h-4 text-purple-600" />
      <span className="font-medium text-purple-800">{data.label}</span>
    </div>
    <div className="text-xs text-purple-600 mt-1">{data.filterType}</div>
  </div>
);

const ActionNode = ({ data }: { data: any }) => (
  <div className="px-4 py-2 bg-green-100 border-2 border-green-300 rounded-lg min-w-[150px]">
    <div className="flex items-center gap-2">
      <Mail className="w-4 h-4 text-green-600" />
      <span className="font-medium text-green-800">{data.label}</span>
    </div>
    <div className="text-xs text-green-600 mt-1">{data.actionType}</div>
  </div>
);

const SplitNode = ({ data }: { data: any }) => (
  <div className="px-4 py-2 bg-yellow-100 border-2 border-yellow-300 rounded-lg min-w-[150px]">
    <div className="flex items-center gap-2">
      <GitBranch className="w-4 h-4 text-yellow-600" />
      <span className="font-medium text-yellow-800">{data.label}</span>
    </div>
    <div className="text-xs text-yellow-600 mt-1">{data.splitType}</div>
  </div>
);

const nodeTypes: NodeTypes = {
  trigger: TriggerNode,
  delay: DelayNode,
  filter: FilterNode,
  action: ActionNode,
  split: SplitNode,
};

// Node palette items
const nodeTemplates = [
  {
    type: 'trigger',
    label: 'Trigger',
    icon: Zap,
    color: 'blue',
    description: 'Start your flow',
    defaultData: { label: 'New Trigger', triggerType: 'Cart Abandoned' },
  },
  {
    type: 'delay',
    label: 'Delay',
    icon: Timer,
    color: 'orange',
    description: 'Wait before next step',
    defaultData: { label: 'Wait', delayTime: '1 hour' },
  },
  {
    type: 'filter',
    label: 'Filter',
    icon: Filter,
    color: 'purple',
    description: 'Filter your audience',
    defaultData: { label: 'Filter', filterType: 'Total spent > $50' },
  },
  {
    type: 'action',
    label: 'Send Email',
    icon: Mail,
    color: 'green',
    description: 'Send an email',
    defaultData: { label: 'Send Email', actionType: 'AI Generated' },
  },
  {
    type: 'split',
    label: 'Split Test',
    icon: GitBranch,
    color: 'yellow',
    description: 'A/B test paths',
    defaultData: { label: 'A/B Split', splitType: '50/50' },
  },
];

interface FlowBuilderProps {
  flowId?: string;
}

function FlowCanvas({ flowId }: FlowBuilderProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [flowName, setFlowName] = useState('New Flow');
  const [flowStatus, setFlowStatus] = useState<'draft' | 'active' | 'paused'>('draft');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const reactFlowInstance = useReactFlow();

  // Fetch flow data
  const { data: flowData, isLoading } = useQuery({
    queryKey: ['/api/flows', flowId],
    enabled: !!flowId,
  });

  // Load flow data into canvas
  useEffect(() => {
    if (flowData) {
      setFlowName(flowData.name);
      setFlowStatus(flowData.status);
      
      const flowNodes = flowData.nodes?.map((node: any) => ({
        id: node.id,
        type: node.type,
        position: { x: node.x, y: node.y },
        data: node.settings,
      })) || [];
      
      const flowEdges = flowData.edges?.map((edge: any) => ({
        id: edge.id,
        source: edge.sourceNode,
        target: edge.targetNode,
      })) || [];
      
      setNodes(flowNodes);
      setEdges(flowEdges);
    }
  }, [flowData, setNodes, setEdges]);

  // Save flow mutation
  const saveFlowMutation = useMutation({
    mutationFn: async (flowData: any) => {
      const method = flowId ? 'PUT' : 'POST';
      const url = flowId ? `/api/flows/${flowId}` : '/api/flows';
      return apiRequest(url, { method, body: flowData });
    },
    onSuccess: () => {
      toast({ title: 'Flow saved successfully!' });
      queryClient.invalidateQueries({ queryKey: ['/api/flows'] });
    },
  });

  const onConnect = useCallback((params: Connection) => {
    setEdges((eds) => addEdge(params, eds));
  }, [setEdges]);

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    const nodeType = event.dataTransfer.getData('application/reactflow');
    if (!nodeType) return;

    const position = reactFlowInstance.screenToFlowPosition({
      x: event.clientX,
      y: event.clientY,
    });

    const template = nodeTemplates.find(t => t.type === nodeType);
    if (!template) return;

    const newNode: Node = {
      id: uuidv4(),
      type: nodeType,
      position,
      data: template.defaultData,
    };

    setNodes((nds) => nds.concat(newNode));
  }, [reactFlowInstance, setNodes]);

  const handleNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  const handleSaveFlow = () => {
    const flowData = {
      id: flowId || uuidv4(),
      name: flowName,
      status: flowStatus,
      userId: 1, // Demo user
      nodes: nodes.map(node => ({
        id: node.id,
        type: node.type,
        x: node.position.x,
        y: node.position.y,
        settings: node.data,
      })),
      edges: edges.map(edge => ({
        id: edge.id,
        sourceNode: edge.source,
        targetNode: edge.target,
      })),
    };

    saveFlowMutation.mutate(flowData);
  };

  const handleDeleteNode = (nodeId: string) => {
    setNodes((nds) => nds.filter((node) => node.id !== nodeId));
    setEdges((eds) => eds.filter((edge) => edge.source !== nodeId && edge.target !== nodeId));
    setSelectedNode(null);
  };

  const handleUpdateNode = (nodeId: string, newData: any) => {
    setNodes((nds) =>
      nds.map((node) => (node.id === nodeId ? { ...node, data: { ...node.data, ...newData } } : node))
    );
  };

  const handleRunFlow = () => {
    // Implement flow execution
    toast({ title: 'Flow started!', description: 'Your flow is now running.' });
    setFlowStatus('active');
  };

  const handlePauseFlow = () => {
    setFlowStatus('paused');
    toast({ title: 'Flow paused', description: 'Your flow has been paused.' });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading flow...</div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar - Node Palette */}
      <div className="w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto">
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-4">Flow Elements</h3>
          <div className="space-y-2">
            {nodeTemplates.map((template) => (
              <div
                key={template.type}
                className={`p-3 rounded-lg border cursor-move hover:shadow-md transition-shadow bg-${template.color}-50 border-${template.color}-200`}
                draggable
                onDragStart={(event) => {
                  event.dataTransfer.setData('application/reactflow', template.type);
                  event.dataTransfer.effectAllowed = 'move';
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <template.icon className={`w-4 h-4 text-${template.color}-600`} />
                  <span className={`font-medium text-${template.color}-800`}>{template.label}</span>
                </div>
                <div className={`text-xs text-${template.color}-600`}>{template.description}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Canvas */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/flows">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Flows
                </Button>
              </Link>
              <Input
                value={flowName}
                onChange={(e) => setFlowName(e.target.value)}
                className="font-semibold text-lg border-none shadow-none p-0 h-auto"
                placeholder="Flow Name"
              />
              <Badge variant={flowStatus === 'active' ? 'default' : flowStatus === 'paused' ? 'secondary' : 'outline'}>
                {flowStatus}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSaveFlow}
                disabled={saveFlowMutation.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
              {flowStatus === 'active' ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePauseFlow}
                >
                  <Pause className="w-4 h-4 mr-2" />
                  Pause
                </Button>
              ) : (
                <Button
                  size="sm"
                  onClick={handleRunFlow}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Run Flow
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* React Flow Canvas */}
        <div className="flex-1 relative">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onDrop={onDrop}
            onDragOver={onDragOver}
            onNodeClick={handleNodeClick}
            nodeTypes={nodeTypes}
            fitView
            selectOnClick
            selectionMode={SelectionMode.Partial}
          >
            <Background variant={BackgroundVariant.Dots} gap={20} size={1} />
            <Controls />
            <MiniMap />
            <Panel position="top-right">
              <div className="bg-white p-2 rounded-lg border border-gray-200 shadow-sm">
                <div className="text-sm text-gray-600">
                  Drag elements from the sidebar to create your flow
                </div>
              </div>
            </Panel>
          </ReactFlow>
        </div>
      </div>

      {/* Properties Panel */}
      {selectedNode && (
        <div className="w-80 bg-white border-l border-gray-200 p-4 overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Properties</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleDeleteNode(selectedNode.id)}
            >
              <Trash2 className="w-4 h-4 text-red-600" />
            </Button>
          </div>
          
          <NodePropertiesPanel
            node={selectedNode}
            onUpdate={(newData) => handleUpdateNode(selectedNode.id, newData)}
          />
        </div>
      )}
    </div>
  );
}

function NodePropertiesPanel({ node, onUpdate }: { node: Node; onUpdate: (data: any) => void }) {
  const [data, setData] = useState(node.data);

  const handleChange = (key: string, value: any) => {
    const newData = { ...data, [key]: value };
    setData(newData);
    onUpdate(newData);
  };

  switch (node.type) {
    case 'trigger':
      return (
        <div className="space-y-4">
          <div>
            <Label htmlFor="label">Label</Label>
            <Input
              id="label"
              value={data.label}
              onChange={(e) => handleChange('label', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="triggerType">Trigger Type</Label>
            <Select value={data.triggerType} onValueChange={(value) => handleChange('triggerType', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select trigger" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cart.abandoned">Cart Abandoned</SelectItem>
                <SelectItem value="user.signup">User Signup</SelectItem>
                <SelectItem value="order.placed">Order Placed</SelectItem>
                <SelectItem value="product.viewed">Product Viewed</SelectItem>
                <SelectItem value="subscription.cancelled">Subscription Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      );

    case 'delay':
      return (
        <div className="space-y-4">
          <div>
            <Label htmlFor="label">Label</Label>
            <Input
              id="label"
              value={data.label}
              onChange={(e) => handleChange('label', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="delayTime">Delay Time</Label>
            <Select value={data.delayTime} onValueChange={(value) => handleChange('delayTime', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select delay" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15 minutes">15 minutes</SelectItem>
                <SelectItem value="1 hour">1 hour</SelectItem>
                <SelectItem value="4 hours">4 hours</SelectItem>
                <SelectItem value="1 day">1 day</SelectItem>
                <SelectItem value="3 days">3 days</SelectItem>
                <SelectItem value="1 week">1 week</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      );

    case 'filter':
      return (
        <div className="space-y-4">
          <div>
            <Label htmlFor="label">Label</Label>
            <Input
              id="label"
              value={data.label}
              onChange={(e) => handleChange('label', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="filterType">Filter Type</Label>
            <Select value={data.filterType} onValueChange={(value) => handleChange('filterType', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Total spent > $50">Total spent {'>'} $50</SelectItem>
                <SelectItem value="Total spent > $100">Total spent {'>'} $100</SelectItem>
                <SelectItem value="Has tag VIP">Has tag VIP</SelectItem>
                <SelectItem value="Location = US">Location = US</SelectItem>
                <SelectItem value="Signup date < 30 days">Signup date {'<'} 30 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      );

    case 'action':
      return (
        <div className="space-y-4">
          <div>
            <Label htmlFor="label">Label</Label>
            <Input
              id="label"
              value={data.label}
              onChange={(e) => handleChange('label', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="actionType">Action Type</Label>
            <Select value={data.actionType} onValueChange={(value) => handleChange('actionType', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Send Email">Send Email</SelectItem>
                <SelectItem value="AI Generated">AI Generated Email</SelectItem>
                <SelectItem value="Template">Use Template</SelectItem>
                <SelectItem value="Custom">Custom Email</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="subject">Email Subject</Label>
            <Input
              id="subject"
              value={data.subject || ''}
              onChange={(e) => handleChange('subject', e.target.value)}
              placeholder="Enter email subject"
            />
          </div>
          <div>
            <Label htmlFor="tone">Tone</Label>
            <Select value={data.tone || 'friendly'} onValueChange={(value) => handleChange('tone', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select tone" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="casual">Casual</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      );

    case 'split':
      return (
        <div className="space-y-4">
          <div>
            <Label htmlFor="label">Label</Label>
            <Input
              id="label"
              value={data.label}
              onChange={(e) => handleChange('label', e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="splitType">Split Type</Label>
            <Select value={data.splitType} onValueChange={(value) => handleChange('splitType', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select split" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="50/50">50/50</SelectItem>
                <SelectItem value="70/30">70/30</SelectItem>
                <SelectItem value="80/20">80/20</SelectItem>
                <SelectItem value="90/10">90/10</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      );

    default:
      return <div>Select a node to edit its properties</div>;
  }
}

export default function FlowBuilder() {
  const [, params] = useRoute('/flows/:flowId');
  const flowId = params?.flowId !== 'new' ? params?.flowId : undefined;

  return (
    <ReactFlowProvider>
      <FlowCanvas flowId={flowId} />
    </ReactFlowProvider>
  );
}