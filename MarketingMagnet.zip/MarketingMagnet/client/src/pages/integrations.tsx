import { IntegrationManager } from "@/components/integration-manager";

export default function Integrations() {
  // Hard-coded demo user ID (in production, this would come from auth context)
  const userId = 1;

  return (
    <div className="container mx-auto p-6">
      <IntegrationManager userId={userId} />
    </div>
  );
}