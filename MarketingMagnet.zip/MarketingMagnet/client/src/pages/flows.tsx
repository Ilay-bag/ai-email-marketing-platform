import React, { useState } from 'react';
import { Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Plus, 
  Search, 
  Filter, 
  Play, 
  Pause, 
  Edit, 
  Trash2, 
  Copy, 
  MoreVertical,
  GitBranch,
  Zap,
  Users,
  Mail,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  BarChart3,
  Calendar,
  Eye,
  Settings,
} from 'lucide-react';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { Flow } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

export default function Flows() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch flows
  const { data: flows, isLoading } = useQuery({
    queryKey: ['/api/flows'],
    queryFn: () => apiRequest('/api/flows'),
  });

  // Delete flow mutation
  const deleteFlowMutation = useMutation({
    mutationFn: (flowId: string) => apiRequest(`/api/flows/${flowId}`, { method: 'DELETE' }),
    onSuccess: () => {
      toast({ title: 'Flow deleted successfully' });
      queryClient.invalidateQueries({ queryKey: ['/api/flows'] });
    },
  });

  // Toggle flow status mutation
  const toggleFlowMutation = useMutation({
    mutationFn: ({ flowId, status }: { flowId: string; status: string }) =>
      apiRequest(`/api/flows/${flowId}`, { 
        method: 'PUT', 
        body: { status } 
      }),
    onSuccess: () => {
      toast({ title: 'Flow status updated' });
      queryClient.invalidateQueries({ queryKey: ['/api/flows'] });
    },
  });

  // Duplicate flow mutation
  const duplicateFlowMutation = useMutation({
    mutationFn: (flowId: string) => apiRequest(`/api/flows/${flowId}/duplicate`, { method: 'POST' }),
    onSuccess: () => {
      toast({ title: 'Flow duplicated successfully' });
      queryClient.invalidateQueries({ queryKey: ['/api/flows'] });
    },
  });

  // Filter flows
  const filteredFlows = flows?.filter((flow: Flow) => {
    const matchesSearch = flow.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || flow.status === statusFilter;
    return matchesSearch && matchesStatus;
  }) || [];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'paused':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      case 'draft':
        return <XCircle className="w-4 h-4 text-gray-600" />;
      default:
        return <XCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleToggleStatus = (flowId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';
    toggleFlowMutation.mutate({ flowId, status: newStatus });
  };

  const handleDeleteFlow = (flowId: string) => {
    if (confirm('Are you sure you want to delete this flow?')) {
      deleteFlowMutation.mutate(flowId);
    }
  };

  const handleDuplicateFlow = (flowId: string) => {
    duplicateFlowMutation.mutate(flowId);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">Loading flows...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Campaign Flows</h1>
          <p className="text-gray-600">Create automated email sequences with triggers and conditions</p>
        </div>
        <Link href="/flows/new">
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Flow
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 bg-white p-4 rounded-lg border">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search flows..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Flow Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Flows</p>
                <p className="text-2xl font-bold">{flows?.length || 0}</p>
              </div>
              <GitBranch className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Flows</p>
                <p className="text-2xl font-bold text-green-600">
                  {flows?.filter((f: Flow) => f.status === 'active').length || 0}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Paused Flows</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {flows?.filter((f: Flow) => f.status === 'paused').length || 0}
                </p>
              </div>
              <AlertCircle className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Draft Flows</p>
                <p className="text-2xl font-bold text-gray-600">
                  {flows?.filter((f: Flow) => f.status === 'draft').length || 0}
                </p>
              </div>
              <XCircle className="w-8 h-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Flows List */}
      <div className="space-y-4">
        {filteredFlows.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <GitBranch className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No flows found</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || statusFilter !== 'all' 
                  ? 'No flows match your current filters.'
                  : 'Create your first automated email flow to get started.'
                }
              </p>
              <Link href="/flows/new">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Flow
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          filteredFlows.map((flow: Flow) => (
            <Card key={flow.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(flow.status)}
                      <Badge className={getStatusColor(flow.status)}>
                        {flow.status}
                      </Badge>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{flow.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(flow.createdAt).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {new Date(flow.updatedAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Link href={`/flows/${flow.id}`}>
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                    </Link>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleStatus(flow.id, flow.status)}
                      disabled={toggleFlowMutation.isPending}
                    >
                      {flow.status === 'active' ? (
                        <>
                          <Pause className="w-4 h-4 mr-2" />
                          Pause
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Activate
                        </>
                      )}
                    </Button>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => handleDuplicateFlow(flow.id)}>
                          <Copy className="w-4 h-4 mr-2" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Eye className="w-4 h-4 mr-2" />
                          View Analytics
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Settings className="w-4 h-4 mr-2" />
                          Settings
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteFlow(flow.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}