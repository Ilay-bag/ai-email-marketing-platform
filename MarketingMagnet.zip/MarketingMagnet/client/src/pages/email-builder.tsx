import React from 'react';
import { EmailBuilder } from '@/components/email-builder/email-builder';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export default function EmailBuilderPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get email ID from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const emailId = urlParams.get('emailId');
  const campaignId = urlParams.get('campaignId');

  // Get initial content from localStorage or API
  const getInitialContent = () => {
    const storedData = localStorage.getItem('emailBuilderData');
    if (storedData) {
      try {
        const parsedData = JSON.parse(storedData);
        localStorage.removeItem('emailBuilderData'); // Clear after use
        return parsedData;
      } catch (error) {
        console.error('Error parsing stored email data:', error);
      }
    }
    return null;
  };

  // Fetch existing email content if editing
  const { data: emailContent, isLoading } = useQuery({
    queryKey: ['/api/emails', emailId],
    queryFn: () => emailId ? apiRequest('GET', `/api/emails/${emailId}`) : null,
    enabled: !!emailId,
  });

  // Use stored data if available, otherwise use fetched content
  const storedContent = getInitialContent();
  const initialContent = storedContent || (emailContent ? {
    components: emailContent.json?.components || [],
    globalStyles: emailContent.json?.globalStyles || {},
    subject: emailContent.subject || '',
    html: emailContent.html || ''
  } : null);

  // Save email content
  const saveEmail = useMutation({
    mutationFn: async (content: any) => {
      const emailData = {
        subject: content.subject || 'New Email',
        html: content.html || '',
        json: {
          components: content.components || [],
          globalStyles: content.globalStyles || {}
        },
        userId: 1, // Demo user ID
      };

      if (emailId) {
        // Update existing email
        return apiRequest('PUT', `/api/emails/${emailId}`, emailData);
      } else {
        // Create new email
        return apiRequest('POST', '/api/emails', {
          ...emailData,
          campaignId: campaignId || null,
        });
      }
    },
    onSuccess: (data) => {
      toast({
        title: 'Email Saved',
        description: 'Your email has been saved successfully!',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/emails'] });
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Save Failed',
        description: error.message || 'Failed to save email',
        variant: 'destructive',
      });
    },
  });

  const handleSave = (content: any) => {
    saveEmail.mutate(content);
  };

  const handlePreview = (content: any) => {
    // Open preview in new window
    const previewWindow = window.open('', '_blank', 'width=800,height=600');
    if (previewWindow) {
      previewWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Email Preview</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 0; 
              padding: 20px; 
              background-color: #f5f5f5; 
            }
            .email-container { 
              max-width: 600px; 
              margin: 0 auto; 
              background-color: white; 
              box-shadow: 0 2px 4px rgba(0,0,0,0.1); 
            }
          </style>
        </head>
        <body>
          <div class="email-container">
            <div style="padding: 20px;">
              <h2>Email Preview</h2>
              <p>This is a preview of your email template.</p>
              <pre>${JSON.stringify(content, null, 2)}</pre>
            </div>
          </div>
        </body>
        </html>
      `);
      previewWindow.document.close();
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading email builder...</p>
        </div>
      </div>
    );
  }

  return (
    <EmailBuilder
      initialContent={initialContent}
      onSave={handleSave}
      onPreview={handlePreview}
    />
  );
}