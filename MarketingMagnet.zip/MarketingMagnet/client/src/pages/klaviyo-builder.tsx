import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { KlaviyoChatInterface } from "@/components/klaviyo-chat-interface";
import { UnlayerEditor } from "@/components/unlayer-editor";
import { useToast } from "@/hooks/use-toast";
import { 
  Zap, 
  Code, 
  Eye, 
  Save, 
  ArrowLeft, 
  Sparkles,
  Mail,
  Settings,
  Monitor
} from "lucide-react";

interface KlaviyoEmailDesign {
  subject: string;
  preheader?: string;
  modules: any[];
  globalSettings: any;
  personalization: any;
  utmParameters: any;
}

interface UnlayerDesign {
  displayMode: string;
  counters: any;
  body: any;
  schemaVersion: number;
}

export default function KlaviyoBuilderPage() {
  const [currentKlaviyoDesign, setCurrentKlaviyoDesign] = useState<KlaviyoEmailDesign | null>(null);
  const [currentUnlayerDesign, setCurrentUnlayerDesign] = useState<UnlayerDesign | null>(null);
  const [currentCampaign, setCurrentCampaign] = useState<any>(null);
  const [currentEmail, setCurrentEmail] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"chat" | "editor">("chat");
  const [showPreview, setShowPreview] = useState(false);
  const [previewHtml, setPreviewHtml] = useState<string>("");
  const { toast } = useToast();

  const handleEmailGenerated = (
    klaviyoDesign: KlaviyoEmailDesign,
    unlayerDesign: UnlayerDesign,
    campaign?: any,
    email?: any
  ) => {
    setCurrentKlaviyoDesign(klaviyoDesign);
    setCurrentUnlayerDesign(unlayerDesign);
    setCurrentCampaign(campaign);
    setCurrentEmail(email);
    setActiveTab("editor");
    
    toast({
      title: "Email Generated Successfully",
      description: `${klaviyoDesign.subject} is ready for visual editing!`
    });
  };

  const handleSave = (design: any, html: string) => {
    // Here you would typically save to your backend
    console.log("Saving design:", design);
    console.log("Generated HTML:", html);
    
    toast({
      title: "Design Saved",
      description: "Your email design has been saved successfully!"
    });
  };

  const handlePreview = (html: string) => {
    setPreviewHtml(html);
    setShowPreview(true);
  };

  const handleBackToHome = () => {
    window.location.href = "/";
  };

  const featuredModules = [
    { name: "Dynamic Products", icon: "🛍️", description: "Auto-populate product recommendations" },
    { name: "Personalization", icon: "👤", description: "Custom content for each recipient" },
    { name: "Countdown Timer", icon: "⏰", description: "Create urgency with live timers" },
    { name: "A/B Testing", icon: "🧪", description: "Test different content variations" },
    { name: "Social Proof", icon: "⭐", description: "Reviews and testimonials" },
    { name: "Conditional Display", icon: "🔄", description: "Show/hide content based on data" },
    { name: "UTM Tracking", icon: "📊", description: "Track campaign performance" },
    { name: "Responsive Design", icon: "📱", description: "Optimized for all devices" }
  ];

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b shadow-sm">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={handleBackToHome}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Klaviyo Email Builder</h1>
              <p className="text-sm text-gray-600">AI-powered email design with advanced modules</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {currentKlaviyoDesign && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <Mail className="h-3 w-3 mr-1" />
              {currentKlaviyoDesign.subject}
            </Badge>
          )}
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        {!currentKlaviyoDesign ? (
          // Initial state - show chat interface and features
          <div className="h-full flex">
            {/* Chat Interface */}
            <div className="flex-1 flex flex-col">
              <KlaviyoChatInterface onEmailGenerated={handleEmailGenerated} />
            </div>
            
            {/* Feature Sidebar */}
            <div className="w-80 border-l bg-white overflow-y-auto">
              <div className="p-4">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Advanced Features
                </h3>
                <div className="space-y-3">
                  {featuredModules.map((module, index) => (
                    <Card key={index} className="p-3">
                      <div className="flex items-start gap-3">
                        <span className="text-xl">{module.icon}</span>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{module.name}</h4>
                          <p className="text-xs text-gray-600 mt-1">{module.description}</p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          // Email generated - show tabs with chat and editor
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "chat" | "editor")} className="h-full flex flex-col">
            {/* Tab Navigation */}
            <div className="border-b bg-white px-4">
              <TabsList className="grid w-full max-w-md grid-cols-2">
                <TabsTrigger value="chat" className="flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  AI Chat
                </TabsTrigger>
                <TabsTrigger value="editor" className="flex items-center gap-2">
                  <Code className="h-4 w-4" />
                  Visual Editor
                </TabsTrigger>
              </TabsList>
            </div>
            
            {/* Tab Content */}
            <div className="flex-1 overflow-hidden">
              <TabsContent value="chat" className="h-full m-0">
                <KlaviyoChatInterface onEmailGenerated={handleEmailGenerated} />
              </TabsContent>
              
              <TabsContent value="editor" className="h-full m-0">
                {currentUnlayerDesign && (
                  <UnlayerEditor
                    initialDesign={currentUnlayerDesign}
                    onSave={handleSave}
                    onPreview={handlePreview}
                    className="h-full"
                  />
                )}
              </TabsContent>
            </div>
          </Tabs>
        )}
      </div>

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-semibold flex items-center gap-2">
                <Eye className="h-4 w-4" />
                Email Preview
              </h3>
              <Button variant="ghost" size="sm" onClick={() => setShowPreview(false)}>
                ✕
              </Button>
            </div>
            <div className="p-4 overflow-y-auto max-h-[calc(90vh-120px)]">
              <div className="border rounded-lg overflow-hidden">
                <div 
                  className="bg-white"
                  dangerouslySetInnerHTML={{ __html: previewHtml }}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}