import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Sparkles, 
  MessageSquare, 
  Send, 
  Edit, 
  Eye, 
  Save, 
  ArrowLeft, 
  Target, 
  Mail, 
  Workflow, 
  Zap,
  Settings,
  Plus,
  RefreshCw,
  Bot,
  Wand2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

type BuilderMode = 'campaign' | 'flow' | 'email';
type GenerationType = 'single_email' | 'email_sequence' | 'automation_flow';

interface AIRequest {
  prompt: string;
  type: GenerationType;
  context?: any;
}

interface GeneratedContent {
  type: GenerationType;
  content: any;
  preview: string;
  campaign?: any;
  flow?: any;
  emails?: any[];
}

export default function AIBuilderPage() {
  const [location, navigate] = useLocation();
  const [mode, setMode] = useState<BuilderMode>('campaign');
  const [prompt, setPrompt] = useState('');
  const [generationType, setGenerationType] = useState<GenerationType>('single_email');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Load chat history
  const { data: messages = [] } = useQuery({
    queryKey: ['/api/chat/messages', 1],
  });

  useEffect(() => {
    setChatHistory(Array.isArray(messages) ? messages : []);
  }, [messages]);

  // Generate content based on type
  const generateContent = useMutation({
    mutationFn: async (request: AIRequest) => {
      let endpoint = '/api/chat/generate';
      let payload: any = {
        prompt: request.prompt,
        userId: 1,
        campaignType: 'promo'
      };

      if (request.type === 'automation_flow') {
        endpoint = '/api/chat/generate-flow';
        payload = {
          prompt: request.prompt,
          userId: 1,
          flowType: request.context?.flowType || 'welcome_series'
        };
      } else if (request.type === 'email_sequence') {
        payload.creationType = 'campaign';
        payload.campaignType = 'sequence';
      }

      return apiRequest('POST', endpoint, payload);
    },
    onSuccess: (data) => {
      setGeneratedContent({
        type: generationType,
        content: data.content,
        preview: data.preview || data.content?.htmlContent || '',
        campaign: data.campaign,
        flow: data.flow,
        emails: data.emails,
      });

      // Update chat history
      queryClient.invalidateQueries({ queryKey: ['/api/chat/messages', 1] });

      toast({
        title: 'Content Generated Successfully',
        description: `Your ${generationType.replace('_', ' ')} has been created!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Generation Failed',
        description: error.message || 'Failed to generate content',
        variant: 'destructive',
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    generateContent.mutate(
      { prompt, type: generationType },
      {
        onSettled: () => setIsGenerating(false),
      }
    );
  };

  const handleEditInBuilder = () => {
    if (!generatedContent) return;

    const data = {
      content: generatedContent.content,
      campaign: generatedContent.campaign,
      flow: generatedContent.flow,
      emails: generatedContent.emails,
    };

    localStorage.setItem('aiBuilderData', JSON.stringify(data));

    switch (generatedContent.type) {
      case 'automation_flow':
        navigate(`/flows/${generatedContent.flow?.id || 'new'}`);
        break;
      case 'email_sequence':
        navigate(`/campaigns/${generatedContent.campaign?.id || 'new'}/edit`);
        break;
      default:
        navigate(`/email-builder?emailId=${generatedContent.emails?.[0]?.id || 'new'}`);
    }
  };

  const resetChat = useMutation({
    mutationFn: () => apiRequest('POST', '/api/chat/reset', { userId: 1 }),
    onSuccess: () => {
      setChatHistory([]);
      setGeneratedContent(null);
      setPrompt('');
      queryClient.invalidateQueries({ queryKey: ['/api/chat/messages', 1] });
      toast({
        title: 'Chat Reset',
        description: 'Starting fresh conversation',
      });
    },
  });

  const suggestedPrompts = {
    single_email: [
      'Create a welcome email for new subscribers with a 20% discount',
      'Design a product launch announcement email',
      'Generate an abandoned cart recovery email',
    ],
    email_sequence: [
      'Create a 5-email welcome series for new customers',
      'Design a re-engagement campaign for inactive subscribers',
      'Build a product education sequence',
    ],
    automation_flow: [
      'Create an abandoned cart recovery flow with 3 emails',
      'Design a welcome automation with personalized content',
      'Build a win-back campaign for churned customers',
    ],
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/')}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <Separator orientation="vertical" className="h-6" />
              <div>
                <h1 className="text-2xl font-semibold text-gray-900 flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#a855f7] to-[#ec4899] rounded-lg flex items-center justify-center">
                    <Wand2 className="h-5 w-5 text-white" />
                  </div>
                  AI Builder
                </h1>
                <p className="text-sm text-gray-600 mt-1">
                  Generate campaigns, flows, and emails with advanced AI
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => resetChat.mutate()}
              disabled={resetChat.isPending}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Reset Chat
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* AI Generation Panel */}
            <div className="lg:col-span-2 space-y-6">
              {/* Generation Type Selector */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-[#a855f7]" />
                    What would you like to create?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button
                      variant={generationType === 'single_email' ? 'default' : 'outline'}
                      className={generationType === 'single_email' ? 'bg-[#a855f7] hover:bg-[#9333ea]' : ''}
                      onClick={() => setGenerationType('single_email')}
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Single Email
                    </Button>
                    <Button
                      variant={generationType === 'email_sequence' ? 'default' : 'outline'}
                      className={generationType === 'email_sequence' ? 'bg-[#a855f7] hover:bg-[#9333ea]' : ''}
                      onClick={() => setGenerationType('email_sequence')}
                    >
                      <Sparkles className="h-4 w-4 mr-2" />
                      Email Sequence
                    </Button>
                    <Button
                      variant={generationType === 'automation_flow' ? 'default' : 'outline'}
                      className={generationType === 'automation_flow' ? 'bg-[#a855f7] hover:bg-[#9333ea]' : ''}
                      onClick={() => setGenerationType('automation_flow')}
                    >
                      <Workflow className="h-4 w-4 mr-2" />
                      Automation Flow
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* AI Prompt */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-[#a855f7]" />
                    Describe your {generationType.replace('_', ' ')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder={`Describe your ${generationType.replace('_', ' ')}... Be specific about your target audience, goals, and desired tone.`}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[120px]"
                    disabled={isGenerating}
                  />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        onClick={handleGenerate}
                        disabled={!prompt.trim() || isGenerating}
                        className="bg-[#a855f7] hover:bg-[#9333ea]"
                      >
                        {isGenerating ? (
                          <>
                            <Bot className="h-4 w-4 mr-2 animate-pulse" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Wand2 className="h-4 w-4 mr-2" />
                            Generate with AI
                          </>
                        )}
                      </Button>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {generationType.replace('_', ' ').toUpperCase()}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Generated Content Preview */}
              {generatedContent && (
                <Card className="border-0 shadow-sm">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Eye className="h-5 w-5 text-green-600" />
                        Generated Content
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={handleEditInBuilder}
                          className="bg-[#a855f7] hover:bg-[#9333ea]"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit in Builder
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="prose prose-sm max-w-none">
                        <div dangerouslySetInnerHTML={{ __html: generatedContent.preview }} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Chat History */}
              {chatHistory.length > 0 && (
                <Card className="border-0 shadow-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-blue-600" />
                      Conversation History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-64">
                      <div className="space-y-4">
                        {chatHistory.map((message, index) => (
                          <div key={index} className="flex items-start gap-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              message.role === 'user' 
                                ? 'bg-blue-100 text-blue-600' 
                                : 'bg-purple-100 text-purple-600'
                            }`}>
                              {message.role === 'user' ? (
                                <MessageSquare className="h-3 w-3" />
                              ) : (
                                <Bot className="h-3 w-3" />
                              )}
                            </div>
                            <div className="flex-1 text-sm">
                              <div className="font-medium capitalize mb-1">{message.role}</div>
                              <div className="text-gray-600">{message.content}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <Card className="bg-gradient-to-br from-[#a855f7] to-[#ec4899] text-white border-0">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    Quick Actions
                  </h3>
                  <div className="space-y-3">
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-white hover:bg-white/20 h-8"
                      onClick={() => navigate('/email-builder')}
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Manual Email Builder
                    </Button>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-white hover:bg-white/20 h-8"
                      onClick={() => navigate('/flows')}
                    >
                      <Workflow className="h-4 w-4 mr-2" />
                      Flow Builder
                    </Button>
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start text-white hover:bg-white/20 h-8"
                      onClick={() => navigate('/campaigns')}
                    >
                      <Target className="h-4 w-4 mr-2" />
                      View Campaigns
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Suggested Prompts */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-base">💡 Suggested Prompts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {suggestedPrompts[generationType].map((suggestion, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="w-full text-left justify-start text-xs h-auto py-2 px-3"
                        onClick={() => setPrompt(suggestion)}
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* AI Tips */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-base">🚀 AI Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm text-gray-600 space-y-2">
                    <li>• Be specific about your target audience</li>
                    <li>• Include your main call-to-action</li>
                    <li>• Mention your brand tone and style</li>
                    <li>• Specify timing and triggers for flows</li>
                    <li>• Use "Edit in Builder" to customize further</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}