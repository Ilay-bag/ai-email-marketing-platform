import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Mail, 
  Search, 
  Filter, 
  Plus, 
  Edit, 
  Copy, 
  Trash2, 
  Download,
  MoreHorizontal,
  Eye,
  Calendar
} from "lucide-react";

export default function EmailsLibrary() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [campaignFilter, setCampaignFilter] = useState("all");

  const { data: emails = [], isLoading } = useQuery({
    queryKey: ['/api/emails/library'],
    queryFn: () => apiRequest('GET', '/api/emails/library')
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ['/api/campaigns/user/1'],
    queryFn: () => apiRequest('GET', '/api/campaigns/user/1')
  });

  const deleteEmail = useMutation({
    mutationFn: async (emailId: number) => {
      return apiRequest('DELETE', `/api/emails/${emailId}`);
    },
    onSuccess: () => {
      toast({ title: "Email Deleted", description: "Email has been removed from library." });
      queryClient.invalidateQueries({ queryKey: ['/api/emails/library'] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Delete Failed", 
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const duplicateEmail = useMutation({
    mutationFn: async (email: any) => {
      return apiRequest('POST', '/api/emails', {
        ...email,
        subject: `Copy of ${email.subject}`,
        campaignId: null,
        isTemplate: true
      });
    },
    onSuccess: () => {
      toast({ title: "Email Duplicated", description: "A copy has been created in your library." });
      queryClient.invalidateQueries({ queryKey: ['/api/emails/library'] });
    }
  });

  const filteredEmails = emails.filter((email: any) => {
    const matchesSearch = email.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "template" && email.isTemplate) ||
      (statusFilter === "campaign" && !email.isTemplate);
    const matchesCampaign = campaignFilter === "all" || 
      (campaignFilter === "unassigned" && !email.campaignId) ||
      (email.campaignId && email.campaignId.toString() === campaignFilter);
    
    return matchesSearch && matchesStatus && matchesCampaign;
  });

  const handleCreateEmail = () => {
    // Create a new template email
    const newEmailData = {
      subject: 'New Email Template',
      html: '',
      json: {
        displayMode: 'email',
        counters: { u_row: 1, u_column: 1, u_content_text: 1 },
        body: {
          id: 'body',
          rows: [{
            id: 'row_1',
            cells: [1],
            columns: [{
              id: 'column_1',
              contents: [{
                id: 'text_1',
                type: 'text',
                values: {
                  text: '<p>Start designing your email...</p>',
                  fontSize: '16px',
                  textAlign: 'left',
                  lineHeight: '140%'
                }
              }],
              values: { backgroundColor: '#ffffff' }
            }],
            values: { backgroundColor: '#ffffff' }
          }],
          values: {
            backgroundColor: '#ffffff',
            contentWidth: '600px'
          }
        }
      },
      isTemplate: true
    };

    // Create the email and then navigate to editor
    apiRequest('POST', '/api/emails', newEmailData)
      .then((response) => {
        navigate(`/email-builder?emailId=${response.id}&template=true`);
      })
      .catch((error) => {
        toast({
          title: "Creation Failed",
          description: error.message,
          variant: "destructive"
        });
      });
  };

  const getCampaignName = (campaignId: number) => {
    const campaign = campaigns.find((c: any) => c.id === campaignId);
    return campaign ? campaign.title : 'Unknown Campaign';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Email Library</h1>
          <p className="text-gray-600">Manage all your email templates and designs</p>
        </div>
        <Button onClick={handleCreateEmail}>
          <Plus className="h-4 w-4 mr-2" />
          Create Email
        </Button>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search emails..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="template">Templates</SelectItem>
                <SelectItem value="campaign">Campaign Emails</SelectItem>
              </SelectContent>
            </Select>
            <Select value={campaignFilter} onValueChange={setCampaignFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Campaigns</SelectItem>
                <SelectItem value="unassigned">Unassigned</SelectItem>
                {campaigns.map((campaign: any) => (
                  <SelectItem key={campaign.id} value={campaign.id.toString()}>
                    {campaign.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Email List */}
      <Card>
        <CardHeader>
          <CardTitle>
            {filteredEmails.length} Email{filteredEmails.length !== 1 ? 's' : ''}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-100 animate-pulse rounded"></div>
              ))}
            </div>
          ) : filteredEmails.length === 0 ? (
            <div className="text-center py-12">
              <Mail className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No emails found</h3>
              <p className="text-gray-500 mb-4">
                {searchTerm ? "Try adjusting your search terms." : "Start by creating your first email template."}
              </p>
              <Button onClick={handleCreateEmail}>
                <Plus className="h-4 w-4 mr-2" />
                Create Email
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead>Campaign</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Last Modified</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmails.map((email: any) => (
                  <TableRow key={email.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span className="font-medium">{email.subject}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {email.campaignId ? (
                        <Badge variant="secondary">
                          {getCampaignName(email.campaignId)}
                        </Badge>
                      ) : (
                        <span className="text-gray-500">Unassigned</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={email.isTemplate ? "default" : "outline"}>
                        {email.isTemplate ? "Template" : "Campaign Email"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Calendar className="h-4 w-4" />
                        {formatDate(email.updatedAt)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/email-builder?emailId=${email.id}`)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => duplicateEmail.mutate(email)}>
                            <Copy className="h-4 w-4 mr-2" />
                            Duplicate
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => deleteEmail.mutate(email.id)}>
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}