import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { CampaignFlowEditor } from "@/components/campaign-flow-editor";
import { ArrowLeft } from "lucide-react";

export default function CampaignEditor() {
  const params = useParams();
  const [, navigate] = useLocation();
  const campaignId = parseInt(params.id || '0');

  if (!campaignId) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign Not Found</h2>
          <p className="text-gray-600 mb-4">The campaign you're looking for doesn't exist.</p>
          <Button onClick={() => navigate('/')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b bg-white">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Campaign Flow Editor</h1>
          </div>
        </div>

        {/* Campaign Flow Editor */}
        <CampaignFlowEditor 
          campaignId={campaignId}
          onClose={() => navigate('/')}
        />
      </div>
    </div>
  );
}