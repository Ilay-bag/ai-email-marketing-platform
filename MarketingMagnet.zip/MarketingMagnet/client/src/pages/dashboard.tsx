import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { Plus, MessageSquare, BookOpen, Edit, Send, BarChart, Target, Mail, Sparkles, Bot, GitBranch, ExternalLink, Workflow } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EnhancedChatInterface } from "@/components/enhanced-chat-interface";
import { EmailPreview } from "@/components/email-preview";
import { CampaignCard } from "@/components/campaign-card";
// import { Sidebar } from "@/components/sidebar"; // Now handled in App.tsx
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Campaign {
  id: number;
  title: string;
  type: "abandoned_cart" | "welcome" | "promo" | "product_launch" | "re_engagement";
  status: "draft" | "scheduled" | "sent";
  createdAt: Date;
  userId: number;
  updatedAt: Date;
}

export default function Dashboard() {
  const [currentCampaign, setCurrentCampaign] = useState<any>(null);
  const [isCreatingCampaign, setIsCreatingCampaign] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location, navigate] = useLocation();
  const userId = 1; // Demo user ID

  const { data: campaigns = [], isLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns/user", userId],
  });

  const { data: emails = [], isLoading: emailsLoading } = useQuery({
    queryKey: ["/api/emails/library"],
  });

  // Auto-reset chat when component mounts
  useEffect(() => {
    const resetChat = async () => {
      try {
        await apiRequest('POST', '/api/chat/reset', { userId });
        queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", userId] });
      } catch (error) {
        console.error("Failed to reset chat:", error);
      }
    };

    resetChat();
  }, [userId, queryClient]);

  const createCampaign = useMutation({
    mutationFn: async (campaignData: any) => {
      return await apiRequest("POST", "/api/campaigns", campaignData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      setIsCreatingCampaign(false);
      toast({
        title: "Campaign Saved",
        description: "Your campaign has been saved successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCampaignGenerated = (content: any, campaign?: any, email?: any) => {
    setCurrentCampaign({ ...content, campaignId: campaign?.id, emailId: email?.id });
    setIsCreatingCampaign(true);
  };

  const handleSaveCampaign = (content: any) => {
    const campaignData = {
      userId,
      name: content.subject || "Untitled Campaign",
      subject: content.subject,
      content,
      status: "draft" as const,
    };

    createCampaign.mutate(campaignData);
  };

  const handleEditCampaign = (campaign: Campaign) => {
    setCurrentCampaign({ 
      subject: campaign.title, 
      campaignId: campaign.id,
      type: campaign.type 
    });
    setIsCreatingCampaign(true);
  };

  const handleNewCampaign = () => {
    setCurrentCampaign(null);
    setIsCreatingCampaign(false);
  };

  const flows = [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-600 mt-1">Welcome back! Here's what's happening with your campaigns.</p>
          </div>
          <Button 
            onClick={handleNewCampaign}
            className="bg-[#a855f7] hover:bg-[#9333ea] text-white px-4 py-2 rounded-md font-medium"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Campaign
          </Button>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="p-8">
          <div className="space-y-8">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Mail className="h-8 w-8 text-[#a855f7]" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-600">Total Campaigns</div>
                      <div className="text-2xl font-bold text-gray-900">{campaigns.length}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Send className="h-8 w-8 text-green-500" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-600">Sent This Month</div>
                      <div className="text-2xl font-bold text-gray-900">{campaigns.filter(c => c.status === 'sent').length}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <BarChart className="h-8 w-8 text-blue-500" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-600">Open Rate</div>
                      <div className="text-2xl font-bold text-gray-900">24.8%</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Target className="h-8 w-8 text-orange-500" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-600">Click Rate</div>
                      <div className="text-2xl font-bold text-gray-900">4.2%</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="flex items-center justify-between mb-6">
                <TabsList className="grid grid-cols-3 w-[400px] bg-gray-100">
                  <TabsTrigger 
                    value="chat" 
                    className="data-[state=active]:bg-white data-[state=active]:text-[#a855f7] data-[state=active]:shadow-sm"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    AI Assistant
                  </TabsTrigger>
                  <TabsTrigger 
                    value="campaigns"
                    className="data-[state=active]:bg-white data-[state=active]:text-[#a855f7] data-[state=active]:shadow-sm"
                  >
                    <Workflow className="h-4 w-4 mr-2" />
                    Campaigns & Flows
                  </TabsTrigger>
                  <TabsTrigger 
                    value="emails"
                    className="data-[state=active]:bg-white data-[state=active]:text-[#a855f7] data-[state=active]:shadow-sm"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Email Library
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="chat" className="space-y-6">
                <Card className="border-0 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-2 text-lg font-semibold text-gray-900">
                      <div className="w-8 h-8 bg-gradient-to-r from-[#a855f7] to-[#ec4899] rounded-lg flex items-center justify-center">
                        <MessageSquare className="h-4 w-4 text-white" />
                      </div>
                      AI Campaign Assistant
                    </CardTitle>
                    <p className="text-sm text-gray-600">
                      Create powerful email campaigns with AI. Describe your campaign and let our AI generate professional content and designs for you.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="w-full">
                      <EnhancedChatInterface
                        onCampaignGenerated={handleCampaignGenerated}
                        onSaveCampaign={handleSaveCampaign}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="campaigns">
                <Card className="border-0 shadow-sm">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
                    <div>
                      <CardTitle className="text-lg font-semibold text-gray-900">Your Campaigns & Flows</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">
                        Manage your email campaigns and automated marketing flows
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={handleNewCampaign}
                        variant="outline"
                        className="text-[#a855f7] border-[#a855f7] hover:bg-[#a855f7] hover:text-white"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        New Campaign
                      </Button>
                      <Link href="/flows/new">
                        <Button className="bg-[#a855f7] hover:bg-[#9333ea] text-white">
                          <Workflow className="h-4 w-4 mr-2" />
                          New Flow
                        </Button>
                      </Link>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <div className="text-gray-500">Loading campaigns and flows...</div>
                      </div>
                    ) : campaigns.length === 0 ? (
                      <div className="text-center py-12">
                        <div className="flex justify-center items-center gap-4 mb-4">
                          <Mail className="h-8 w-8 text-gray-400" />
                          <Workflow className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No campaigns or flows yet</h3>
                        <p className="text-gray-600 mb-6">Get started by creating your first email campaign or automated flow with AI assistance.</p>
                        <div className="flex justify-center gap-3">
                          <Button 
                            onClick={() => setActiveTab('chat')}
                            variant="outline"
                            className="text-[#a855f7] border-[#a855f7] hover:bg-[#a855f7] hover:text-white"
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Create Campaign
                          </Button>
                          <Link href="/flows/new">
                            <Button className="bg-[#a855f7] hover:bg-[#9333ea] text-white">
                              <Workflow className="h-4 w-4 mr-2" />
                              Create Flow
                            </Button>
                          </Link>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {/* Quick Actions */}
                        <div className="flex justify-between items-center">
                          <div className="flex gap-4 text-sm text-gray-600">
                            <span>{campaigns.length} campaigns</span>
                            <span>•</span>
                            <span>0 active flows</span>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">All</Button>
                            <Button size="sm" variant="ghost">Campaigns</Button>
                            <Button size="sm" variant="ghost">Flows</Button>
                          </div>
                        </div>
                        
                        {/* Campaigns Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                          {campaigns.map((campaign) => (
                            <div key={campaign.id} className="relative">
                              <CampaignCard
                                campaign={campaign}
                                onEdit={() => handleEditCampaign(campaign)}
                              />
                              <div className="absolute top-2 right-2">
                                <Badge variant="secondary" className="text-xs">
                                  Campaign
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="emails">
                <Card className="border-0 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900">Email Library</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">
                      Browse and manage your email templates
                    </p>
                  </CardHeader>
                  <CardContent>
                    {emailsLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <div className="text-gray-500">Loading templates...</div>
                      </div>
                    ) : (emails as any[]).length === 0 ? (
                      <div className="text-center py-12">
                        <Edit className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No templates yet</h3>
                        <p className="text-gray-600 mb-6">Start building your email template library by creating campaigns.</p>
                        <Button 
                          onClick={() => setActiveTab('chat')}
                          className="bg-[#a855f7] hover:bg-[#9333ea] text-white"
                        >
                          Create First Template
                        </Button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {(emails as any[]).map((email: any) => (
                          <Card key={email.id} className="border border-gray-200 hover:shadow-md transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <h4 className="font-medium text-gray-900 mb-2">{email.subject}</h4>
                              <p className="text-sm text-gray-600 mb-4">
                                {email.isTemplate ? 'Template' : 'Campaign Email'}
                              </p>
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-gray-500">
                                  {new Date(email.createdAt).toLocaleDateString()}
                                </span>
                                <div className="flex gap-1">
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => {
                                      setActiveTab('chat');
                                      // Pass editing context to chat interface
                                      window.scrollTo(0, 0);
                                    }}
                                  >
                                    <Edit className="h-3 w-3 mr-1" />
                                    Edit with AI
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="ghost"
                                    onClick={() => window.open(`/email-builder?emailId=${email.id}`, '_blank')}
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
    </div>
  );
}