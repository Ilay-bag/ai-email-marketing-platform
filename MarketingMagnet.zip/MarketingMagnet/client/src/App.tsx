import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/sidebar";
import Dashboard from "@/pages/dashboard";
import CampaignLibrary from "@/pages/campaign-library";
import Integrations from "@/pages/integrations";
import EmailBuilderPage from "@/pages/email-builder";
import UnifiedFlowBuilder from "@/pages/unified-flow-builder";
import SentCampaigns from "@/pages/sent";
import Analytics from "@/pages/analytics";
import SettingsPage from "@/pages/settings";
import CampaignEditor from "@/pages/campaign-editor";
import EmailsLibrary from "@/pages/emails-library";
import Flows from "@/pages/flows";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/email-builder">
        {/* Email builder gets full screen */}
        <EmailBuilderPage />
      </Route>
      <Route path="/flow-builder">
        {/* Unified Flow builder gets full screen */}
        <UnifiedFlowBuilder />
      </Route>
      <Route path="/flows">
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <Dashboard />
          </div>
        </div>
      </Route>
      <Route path="/flows/:flowId">
        <UnifiedFlowBuilder />
      </Route>
      <Route path="/">
        {/* Main dashboard with integrated navigation */}
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <Dashboard />
          </div>
        </div>
      </Route>
      <Route path="/campaigns">
        {/* Campaigns page with sidebar */}
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <Dashboard />
          </div>
        </div>
      </Route>
      <Route path="/campaigns/:id/edit">
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <CampaignEditor />
          </div>
        </div>
      </Route>
      <Route path="/emails">
        {/* Email library page with sidebar */}
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <EmailsLibrary />
          </div>
        </div>
      </Route>
      <Route path="/integrations">
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <Integrations />
          </div>
        </div>
      </Route>
      <Route path="/sent">
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <SentCampaigns />
          </div>
        </div>
      </Route>
      <Route path="/analytics">
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <Analytics />
          </div>
        </div>
      </Route>
      <Route path="/settings">
        <div className="flex min-h-screen bg-gray-50">
          <Sidebar />
          <div className="flex-1 ml-64">
            <SettingsPage />
          </div>
        </div>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gray-50">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;