import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Edit, Trash2, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Campaign {
  id: number;
  title: string;
  type: "abandoned_cart" | "welcome" | "promo" | "product_launch" | "re_engagement";
  status: "draft" | "scheduled" | "sent";
  createdAt: Date;
  userId: number;
  updatedAt: Date;
}

interface CampaignCardProps {
  campaign: Campaign;
  onEdit: (campaign: Campaign) => void;
}

const statusColors = {
  draft: "bg-gray-100 text-gray-700",
  scheduled: "bg-blue-50 text-blue-700",
  sent: "bg-green-50 text-green-700",
};

const statusIcons = {
  draft: "📝",
  scheduled: "⏰",
  sent: "✅",
};

const typeColors = {
  abandoned_cart: "bg-orange-50 text-orange-700 border-orange-200",
  welcome: "bg-green-50 text-green-700 border-green-200",
  promo: "bg-purple-50 text-purple-700 border-purple-200",
  product_launch: "bg-blue-50 text-blue-700 border-blue-200",
  re_engagement: "bg-yellow-50 text-yellow-700 border-yellow-200",
};

export function CampaignCard({ campaign, onEdit }: CampaignCardProps) {
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteCampaign = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/campaigns/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Campaign Deleted",
        description: "The campaign has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDelete = async () => {
    setIsDeleting(true);
    await deleteCampaign.mutateAsync(campaign.id);
    setIsDeleting(false);
  };

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (d.toDateString() === today.toDateString()) {
      return "Today";
    } else if (d.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return d.toLocaleDateString();
    }
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-200 border-0 shadow-sm bg-white group">
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#a855f7] to-[#ec4899] rounded-lg flex items-center justify-center text-white font-semibold">
              {statusIcons[campaign.status]}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 text-sm line-clamp-2 mb-1">
                {campaign.title}
              </h3>
              <p className="text-xs text-gray-500">
                {campaign.type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </p>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => onEdit(campaign)}>
                <Edit className="mr-2 h-4 w-4" />
                Edit Campaign
              </DropdownMenuItem>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <DropdownMenuItem
                    className="text-red-600 focus:text-red-600"
                    onSelect={(e) => e.preventDefault()}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Campaign
                  </DropdownMenuItem>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Campaign</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete "{campaign.title}"? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDelete}
                      disabled={isDeleting}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      {isDeleting ? "Deleting..." : "Delete"}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Status Badge */}
        <div className="mb-4">
          <Badge className={`text-xs font-medium border ${statusColors[campaign.status]}`}>
            {statusIcons[campaign.status]} {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
          </Badge>
        </div>

        {/* Stats */}
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Created</span>
            <span className="text-gray-900 font-medium">{formatDate(campaign.createdAt)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Last Updated</span>
            <span className="text-gray-900 font-medium">{formatDate(campaign.updatedAt)}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 mt-4 border-t border-gray-100">
          <Button 
            onClick={() => onEdit(campaign)}
            variant="outline"
            className="w-full font-medium h-9 hover:bg-[#a855f7] hover:text-white hover:border-[#a855f7] transition-colors"
          >
            <Edit className="mr-2 h-4 w-4" />
            Edit Campaign
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
