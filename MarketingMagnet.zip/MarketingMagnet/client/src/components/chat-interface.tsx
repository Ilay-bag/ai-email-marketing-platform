import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Send, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

interface ChatInterfaceProps {
  onCampaignGenerated: (content: any, campaign?: any, email?: any) => void;
}

export function ChatInterface({ onCampaignGenerated }: ChatInterfaceProps) {
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const userId = 1; // Demo user ID

  const { data: messages = [], refetch } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages", userId],
  });

  const generateCampaign = useMutation({
    mutationFn: async (prompt: string) => {
      return await apiRequest("POST", "/api/chat/generate", {
        prompt,
        userId,
      });
    },
    onSuccess: (data) => {
      onCampaignGenerated(data.content, data.campaign, data.email);
      refetch();
      toast({
        title: "Campaign Generated",
        description: "Your email campaign has been created successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    generateCampaign.mutate(input);
    setInput("");
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <Card className="h-fit">
      <CardHeader className="border-b border-slate-200">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-secondary to-primary rounded-lg flex items-center justify-center">
            <Bot className="text-white" size={16} />
          </div>
          <CardTitle>AI Campaign Assistant</CardTitle>
        </div>
        <p className="text-slate-600 text-sm">
          Describe your email campaign and let AI create it for you
        </p>
      </CardHeader>

      <CardContent className="p-6">
        {/* Chat Messages */}
        <div className="space-y-4 max-h-96 overflow-y-auto mb-4">
          {messages.length === 0 && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-secondary to-primary rounded-lg flex items-center justify-center flex-shrink-0">
                <Bot className="text-white" size={16} />
              </div>
              <div className="bg-slate-100 rounded-lg p-3 max-w-xs">
                <p className="text-sm text-slate-800">
                  Hi! I'm your AI email marketing assistant. Describe the
                  campaign you'd like to create and I'll generate the content
                  for you.
                </p>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.role === "user" ? "justify-end" : ""
              }`}
            >
              {message.role === "user" ? (
                <>
                  <div className="bg-primary text-white rounded-lg p-3 max-w-xs">
                    <p className="text-sm">{message.content}</p>
                  </div>
                  <div className="w-8 h-8 bg-slate-300 rounded-lg flex items-center justify-center flex-shrink-0">
                    <User className="text-slate-600" size={16} />
                  </div>
                </>
              ) : (
                <>
                  <div className="w-8 h-8 bg-gradient-to-br from-secondary to-primary rounded-lg flex items-center justify-center flex-shrink-0">
                    <Bot className="text-white" size={16} />
                  </div>
                  <div className="bg-slate-100 rounded-lg p-3 max-w-md">
                    <p className="text-sm text-slate-800">{message.content}</p>
                  </div>
                </>
              )}
            </div>
          ))}

          {generateCampaign.isPending && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-secondary to-primary rounded-lg flex items-center justify-center flex-shrink-0">
                <Bot className="text-white" size={16} />
              </div>
              <div className="bg-slate-100 rounded-lg p-3 max-w-xs">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <Input
            type="text"
            placeholder="Describe your email campaign..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={generateCampaign.isPending}
            className="flex-1"
          />
          <Button
            type="submit"
            disabled={generateCampaign.isPending || !input.trim()}
          >
            <Send size={16} />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
