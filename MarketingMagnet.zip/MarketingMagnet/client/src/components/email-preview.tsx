import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Monitor, Smartphone, Edit, Save, Eye, Send, ExternalLink, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface EmailPreviewProps {
  content: any;
  onSave: (content: any) => void;
  campaignId?: number;
}

export function EmailPreview({ content, onSave, campaignId }: EmailPreviewProps) {
  const [viewMode, setViewMode] = useState<"desktop" | "mobile">("desktop");
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(content);
  const [testEmail, setTestEmail] = useState("");
  const [selectedPlatform, setSelectedPlatform] = useState("");
  const { toast } = useToast();
  const userId = 1; // Hard-coded demo user ID

  const { data: integrations } = useQuery({
    queryKey: ['/api/integrations/user', userId],
    queryFn: () => apiRequest('GET', `/api/integrations/user/${userId}`)
  });

  const sendTestEmail = useMutation({
    mutationFn: async (email: string) => {
      return await apiRequest("POST", "/api/email/test", {
        to: email,
        content: editedContent,
      });
    },
    onSuccess: () => {
      toast({
        title: "Test Email Sent",
        description: "Check your inbox for the test email!",
      });
      setTestEmail("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const exportCampaign = useMutation({
    mutationFn: async ({ platform, options }: { platform: string; options?: any }) => {
      if (!campaignId) throw new Error("Campaign ID is required for export");
      
      const response = await apiRequest("POST", `/api/campaigns/${campaignId}/export`, {
        userId,
        platform,
        options: options || {}
      });
      return response;
    },
    onSuccess: (data) => {
      toast({
        title: "Campaign Exported",
        description: `Successfully exported to ${selectedPlatform}`,
      });
      setSelectedPlatform("");
    },
    onError: (error: any) => {
      toast({
        title: "Export Failed",
        description: error.message || "Failed to export campaign",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    onSave(editedContent);
    setIsEditing(false);
    toast({
      title: "Campaign Saved",
      description: "Your changes have been saved successfully!",
    });
  };

  const handleTestEmail = () => {
    if (!testEmail.trim()) return;
    sendTestEmail.mutate(testEmail);
  };

  const handleExport = () => {
    if (!selectedPlatform) return;
    exportCampaign.mutate({ platform: selectedPlatform });
  };

  const handleEditContent = () => {
    const emailId = content.emailId || campaignId;
    const campaignIdToUse = content.campaignId || campaignId;
    
    // Navigate to the new drag-and-drop email builder
    const builderUrl = `/email-builder?emailId=${emailId}&campaignId=${campaignIdToUse}`;
    // Use same window navigation for better user experience
    window.location.href = builderUrl;
  };

  const connectedIntegrations = Array.isArray(integrations) 
    ? integrations.filter((integration: any) => integration.isActive) 
    : [];
  const hasConnectedIntegrations = connectedIntegrations.length > 0;

  if (!content) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Edit className="text-slate-400" size={24} />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">
              No Campaign Selected
            </h3>
            <p className="text-slate-600">
              Generate a new campaign using the AI assistant to see the preview here.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="border-b border-slate-200">
        <div className="flex items-center justify-between">
          <CardTitle>Email Preview</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="flex bg-slate-100 rounded-lg p-1">
              <Button
                variant={viewMode === "desktop" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("desktop")}
              >
                <Monitor className="mr-1" size={14} />
                Desktop
              </Button>
              <Button
                variant={viewMode === "mobile" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("mobile")}
              >
                <Smartphone className="mr-1" size={14} />
                Mobile
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {/* Subject Line */}
        <div className="bg-slate-50 rounded-lg border border-slate-200 p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <Label className="text-sm font-medium text-slate-700">
              Subject Line:
            </Label>
            {isEditing && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsEditing(false)}
              >
                <Edit className="mr-1" size={14} />
                Edit
              </Button>
            )}
          </div>
          {isEditing ? (
            <Input
              value={editedContent.subject}
              onChange={(e) =>
                setEditedContent({
                  ...editedContent,
                  subject: e.target.value,
                })
              }
              className="font-medium"
            />
          ) : (
            <p className="text-slate-800 font-medium">{content.subject}</p>
          )}
        </div>

        {/* Email Body Preview */}
        <div
          className={`border border-slate-200 rounded-lg overflow-hidden transition-all duration-300 ${
            viewMode === "mobile" ? "max-w-sm mx-auto" : "w-full"
          }`}
        >
          {/* Check if we have HTML content to display */}
          {content.htmlContent ? (
            <div className="bg-white">
              <div className="flex items-center justify-between p-4 bg-gray-50 border-b">
                <span className="text-sm font-medium text-gray-700">HTML Email Preview</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    const htmlWindow = window.open('', '_blank');
                    htmlWindow?.document.write(content.htmlContent);
                    htmlWindow?.document.close();
                  }}
                >
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Open Full
                </Button>
              </div>
              <div className="relative" style={{ height: '600px' }}>
                <iframe
                  srcDoc={content.htmlContent}
                  className="w-full h-full border-0"
                  title="Email HTML Preview"
                  sandbox="allow-same-origin"
                />
              </div>
            </div>
          ) : (
            /* Fallback to structured content display */
            <>
              <div
                className="p-8 text-center text-white"
                style={{
                  background: content.header?.backgroundColor || "#3B82F6",
                }}
              >
                <h1 className="text-3xl font-bold mb-4">
                  {content.header?.title || "Welcome"}
                </h1>
                {content.header?.subtitle && (
                  <p className="text-lg opacity-90">{content.header.subtitle}</p>
                )}
                {content.header?.image && (
                  <img
                    src={content.header.image}
                    alt="Header"
                    className="rounded-lg mx-auto mb-4 w-full max-w-md mt-4"
                  />
                )}
              </div>

              <div className="p-8 bg-white">
                <div className="max-w-md mx-auto">
                  {content.body?.sections?.map((section: any, index: number) => (
                    <div key={index} className="mb-6">
                      {section.type === "text" && (
                        <p className="text-slate-600 leading-relaxed">
                          {section.content}
                        </p>
                      )}
                      {section.type === "features" && (
                        <ul className="space-y-3">
                          {section.content.map((feature: string, featureIndex: number) => (
                            <li key={featureIndex} className="flex items-center space-x-3">
                              <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center">
                                <span className="text-white text-xs font-bold">✓</span>
                              </div>
                              <span className="text-slate-700">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}

                  <div className="text-center">
                    <Button
                      className="text-white font-semibold px-8 py-3"
                      style={{
                        backgroundColor: content.cta?.backgroundColor || "#10B981",
                      }}
                    >
                      {content.cta?.text || "Learn More"}
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </CardContent>

      {/* Email Actions */}
      <div className="border-t border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={handleEditContent}
            >
              <Edit className="mr-2" size={16} />
              Edit Content
            </Button>
            {isEditing && (
              <Button onClick={handleSave}>
                <Save className="mr-2" size={16} />
                Save Changes
              </Button>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Eye className="mr-2" size={16} />
                  Test Email
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Send Test Email</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={testEmail}
                      onChange={(e) => setTestEmail(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={handleTestEmail}
                    disabled={sendTestEmail.isPending || !testEmail.trim()}
                    className="w-full"
                  >
                    {sendTestEmail.isPending ? "Sending..." : "Send Test Email"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            
            {/* Export Button */}
            {hasConnectedIntegrations && campaignId && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Upload className="mr-2" size={16} />
                    Export
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Export Campaign</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="platform">Select Platform</Label>
                      <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a platform" />
                        </SelectTrigger>
                        <SelectContent>
                          {connectedIntegrations.map((integration: any) => (
                            <SelectItem key={integration.id} value={integration.provider}>
                              <div className="flex items-center gap-2">
                                <span className="capitalize">{integration.provider}</span>
                                <Badge variant="secondary" className="text-xs">
                                  {integration.accountEmail}
                                </Badge>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      onClick={handleExport}
                      disabled={exportCampaign.isPending || !selectedPlatform}
                      className="w-full"
                    >
                      {exportCampaign.isPending ? "Exporting..." : "Export Campaign"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
            
            <Button className="bg-accent hover:bg-green-600">
              <Send className="mr-2" size={16} />
              Send Campaign
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
