import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  MessageCircle, 
  FolderOpen, 
  Send, 
  BarChart3, 
  Plug, 
  Settings, 
  Bot, 
  User,
  Edit3,
  Zap,
  Home,
  Users,
  Mail,
  Target,
  TrendingUp,
  Layers,
  Workflow,
  GitBranch
} from "lucide-react";
import { Button } from "@/components/ui/button"

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Campaigns", href: "/campaigns", icon: Mail },
  { name: "Flows", href: "/flows", icon: Workflow },
  { name: "Lists & Segments", href: "/emails", icon: Users },
  { name: "Analytics", href: "/analytics", icon: TrendingUp },
];

const aiTools = [
  { name: "Email Builder", href: "/email-builder", icon: Edit3 },
  { name: "Flow Builder", href: "/flows", icon: Workflow },
];

const integrations = [
  { name: "Integrations", href: "/integrations", icon: Plug },
  { name: "Settings", href: "/settings", icon: Settings },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-[#1f2937] shadow-lg z-50">
      {/* Logo */}
      <div className="flex items-center px-6 h-16 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-[#a855f7] to-[#ec4899] rounded-lg flex items-center justify-center">
            <Bot className="text-white" size={16} />
          </div>
          <span className="text-xl font-bold text-white">Klaviyo</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="pt-6">
        <div className="space-y-1 px-3">
          {navigation.map((item) => (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer",
                  location === item.href
                    ? "text-white bg-[#a855f7] shadow-lg"
                    : "text-gray-300 hover:text-white hover:bg-gray-700/50"
                )}
              >
                <item.icon className="mr-3" size={20} />
                {item.name}
              </div>
            </Link>
          ))}
        </div>

        <div className="px-6 mt-8 mb-3">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            AI Tools
          </h3>
        </div>
        <div className="space-y-1 px-3">
          {aiTools.map((item) => (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer",
                  location === item.href
                    ? "text-white bg-gradient-to-r from-[#a855f7] to-[#ec4899] shadow-lg"
                    : "text-gray-300 hover:text-white hover:bg-gray-700/50"
                )}
              >
                <item.icon className="mr-3" size={20} />
                {item.name}
                <Bot className="ml-auto text-xs" size={14} />
              </div>
            </Link>
          ))}
        </div>

        <div className="px-6 mt-8 mb-3">
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Settings
          </h3>
        </div>
        <div className="space-y-1 px-3">
          {integrations.map((item) => (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer",
                  location === item.href
                    ? "text-white bg-[#a855f7] shadow-lg"
                    : "text-gray-300 hover:text-white hover:bg-gray-700/50"
                )}
              >
                <item.icon className="mr-3" size={20} />
                {item.name}
              </div>
            </Link>
          ))}
        </div>

        <div className="space-y-1 px-3">
        <Link href="/campaigns">
          <Button
            variant={location.startsWith('/campaigns') || location.startsWith('/flows') ? 'secondary' : 'ghost'}
            className="w-full justify-start"
          >
            <GitBranch className="mr-2 h-4 w-4" />
            Campaigns & Flows
          </Button>
        </Link>
        </div>
      </nav>

      {/* User Profile */}
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-gradient-to-br from-[#a855f7] to-[#ec4899] rounded-full flex items-center justify-center">
            <User className="text-white" size={18} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">Demo User</p>
            <p className="text-xs text-gray-400 truncate">demo@example.com</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SidebarItem({ children, href, icon: Icon }) {
  const [location] = useLocation();
  return (
    <Link href={href}>
      <div
        className={cn(
          "flex items-center px-3 py-2.5 text-sm font-medium rounded-md transition-all duration-200 cursor-pointer",
          location === href
            ? "text-white bg-gradient-to-r from-[#a855f7] to-[#ec4899] shadow-lg"
            : "text-gray-300 hover:text-white hover:bg-gray-700/50"
        )}
      >
        {Icon && <Icon className="mr-3" size={20} />}
        {children}
      </div>
    </Link>
  );
}