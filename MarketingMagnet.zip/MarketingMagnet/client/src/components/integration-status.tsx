import { useQuery } from "@tanstack/react-query";
import { Bot, Mail, BarChart3, Megaphone, CheckCircle, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface IntegrationStatus {
  [key: string]: {
    connected: boolean;
    name: string;
    description: string;
  };
}

const integrationIcons = {
  openai: Bot,
  sendgrid: Mail,
  klaviyo: BarChart3,
  mailchimp: Megaphone,
};

const integrationColors = {
  openai: "bg-green-500",
  sendgrid: "bg-blue-500",
  klaviyo: "bg-purple-500",
  mailchimp: "bg-yellow-500",
};

export function IntegrationStatus() {
  // Hard-coded demo user ID (in production, this would come from auth context)
  const userId = 1;
  
  const { data: integrations, isLoading } = useQuery<IntegrationStatus>({
    queryKey: ["/api/integrations/status"],
    queryFn: () => fetch(`/api/integrations/status?userId=${userId}`).then(res => res.json())
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Integration Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-slate-200 rounded-lg"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Integration Status</CardTitle>
        <p className="text-slate-600 text-sm">Connected services and APIs</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {integrations &&
            Object.entries(integrations).map(([key, integration]) => {
              const Icon = integrationIcons[key as keyof typeof integrationIcons];
              const colorClass = integrationColors[key as keyof typeof integrationColors];

              return (
                <Card key={key} className="border border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <div className={`w-8 h-8 ${colorClass} rounded-lg flex items-center justify-center`}>
                          <Icon className="text-white" size={16} />
                        </div>
                        <span className="text-sm font-medium text-slate-800">
                          {integration.name}
                        </span>
                      </div>
                      <div className="flex items-center">
                        {integration.connected ? (
                          <CheckCircle className="text-accent" size={16} />
                        ) : (
                          <XCircle className="text-slate-400" size={16} />
                        )}
                      </div>
                    </div>
                    <p className="text-xs text-slate-500">
                      {integration.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
        </div>
      </CardContent>
    </Card>
  );
}
