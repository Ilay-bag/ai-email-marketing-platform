import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  Code, 
  Eye,
  Download,
  Wand2,
  Settings,
  Zap
} from "lucide-react";

interface ChatMessage {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

interface KlaviyoEmailDesign {
  subject: string;
  preheader?: string;
  modules: any[];
  globalSettings: any;
  personalization: any;
  utmParameters: any;
}

interface UnlayerDesign {
  displayMode: string;
  counters: any;
  body: any;
  schemaVersion: number;
}

interface KlaviyoChatInterfaceProps {
  onEmailGenerated: (klaviyoDesign: KlaviyoEmailDesign, unlayerDesign: UnlayerDesign, campaign?: any, email?: any) => void;
}

export function KlaviyoChatInterface({ onEmailGenerated }: KlaviyoChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [businessType, setBusinessType] = useState("E-commerce");
  const [campaignType, setCampaignType] = useState("promotional");
  const [isAdvancedMode, setIsAdvancedMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const userId = 1; // Demo user ID

  const { data: messages = [], isLoading: messagesLoading } = useQuery<ChatMessage[]>({
    queryKey: ['/api/chat/messages', userId],
    queryFn: () => apiRequest('GET', `/api/chat/messages/${userId}`),
    select: (data) => Array.isArray(data) ? data : [],
    staleTime: 0,
    refetchOnWindowFocus: false
  });

  const generateKlaviyoEmail = useMutation({
    mutationFn: async (data: { prompt: string; businessType: string; campaignType: string }) => {
      return apiRequest('POST', '/api/klaviyo/generate', {
        ...data,
        userId
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Klaviyo Email Generated",
        description: "Your advanced email design is ready for visual editing!"
      });
      onEmailGenerated(data.klaviyoDesign, data.unlayerDesign, data.campaign, data.email);
      queryClient.invalidateQueries({ queryKey: ['/api/chat/messages', userId] });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate Klaviyo email design",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    generateKlaviyoEmail.mutate({
      prompt: message,
      businessType,
      campaignType
    });
    setMessage("");
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const businessTypes = [
    "E-commerce",
    "SaaS",
    "Healthcare",
    "Education",
    "Real Estate",
    "Hospitality",
    "Financial Services",
    "Non-profit",
    "Retail",
    "Technology",
    "Fashion",
    "Food & Beverage"
  ];

  const campaignTypes = [
    "promotional",
    "welcome",
    "abandoned_cart",
    "product_launch",
    "re_engagement",
    "newsletter",
    "seasonal",
    "flash_sale",
    "cross_sell",
    "upsell",
    "review_request",
    "loyalty_program"
  ];

  const examplePrompts = [
    "Create a Black Friday flash sale email with countdown timer and dynamic product recommendations",
    "Design a welcome series email with personalization and social proof elements",
    "Build an abandoned cart recovery email with product images and urgency messaging",
    "Generate a product launch announcement with video content and social sharing",
    "Create a re-engagement campaign with dynamic offers based on user behavior"
  ];

  if (messagesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
            <Zap className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Klaviyo AI Email Generator</h2>
            <p className="text-sm text-gray-600">
              Advanced email design with all Klaviyo modules & features
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsAdvancedMode(!isAdvancedMode)}
        >
          <Settings className="h-4 w-4 mr-2" />
          {isAdvancedMode ? "Simple" : "Advanced"}
        </Button>
      </div>

      {/* Configuration Panel */}
      {isAdvancedMode && (
        <Card className="m-4">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              Campaign Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="businessType">Business Type</Label>
                <Select value={businessType} onValueChange={setBusinessType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select business type" />
                  </SelectTrigger>
                  <SelectContent>
                    {businessTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="campaignType">Campaign Type</Label>
                <Select value={campaignType} onValueChange={setCampaignType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select campaign type" />
                  </SelectTrigger>
                  <SelectContent>
                    {campaignTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Example Prompts */}
      <Card className="m-4">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Wand2 className="h-5 w-5" />
            Example Prompts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2">
            {examplePrompts.map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                className="h-auto p-3 text-left justify-start"
                onClick={() => setMessage(prompt)}
              >
                <div className="text-sm">{prompt}</div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Features Badge */}
      <div className="px-4 mb-4">
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Code className="h-4 w-4 text-purple-600" />
              <span className="font-semibold text-purple-800">Advanced Klaviyo Features</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Dynamic Products</Badge>
              <Badge variant="secondary">Personalization</Badge>
              <Badge variant="secondary">Countdown Timers</Badge>
              <Badge variant="secondary">A/B Testing</Badge>
              <Badge variant="secondary">Social Proof</Badge>
              <Badge variant="secondary">UTM Tracking</Badge>
              <Badge variant="secondary">Conditional Content</Badge>
              <Badge variant="secondary">Responsive Design</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 space-y-4">
        {Array.isArray(messages) && messages.length > 0 ? (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${
                msg.role === "assistant" ? "justify-start" : "justify-end"
              }`}
            >
              {msg.role === "assistant" && (
                <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
                  <Bot className="h-4 w-4 text-white" />
                </div>
              )}
              <div
                className={`max-w-[80%] p-3 rounded-lg ${
                  msg.role === "assistant"
                    ? "bg-gray-100 text-gray-800"
                    : "bg-primary text-primary-foreground"
                }`}
              >
                <p className="text-sm">{msg.content}</p>
                <p className="text-xs mt-1 opacity-70">
                  {new Date(msg.createdAt).toLocaleTimeString()}
                </p>
              </div>
              {msg.role === "user" && (
                <div className="p-2 bg-primary rounded-lg">
                  <User className="h-4 w-4 text-primary-foreground" />
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="flex items-center justify-center h-32 text-center">
            <div className="text-gray-500">
              <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Start a conversation to generate your Klaviyo email!</p>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <div className="p-4 border-t bg-white">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="flex-1">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Describe your email campaign... (e.g., 'Create a Black Friday email with countdown timer and product recommendations')"
              className="min-h-[60px] resize-none"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
          </div>
          <Button
            type="submit"
            disabled={!message.trim() || generateKlaviyoEmail.isPending}
            className="h-[60px] px-6"
          >
            {generateKlaviyoEmail.isPending ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
        <div className="mt-2 text-xs text-gray-500 text-center">
          Press Enter to send, Shift+Enter for new line
        </div>
      </div>
    </div>
  );
}