
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, Target, Users, Zap } from 'lucide-react';

export function PromptGuide() {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            איך לכתוב prompts טובים יותר
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Target className="w-4 h-4" />
            <AlertDescription>
              ככל שתתן יותר פרטים, כך ה-AI ייצור תוכן טוב יותר ומותאם יותר
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-green-600 mb-2">✅ Prompts טובים</h4>
              <div className="space-y-2 text-sm">
                <Badge variant="outline" className="w-full justify-start">
                  "צור welcome series ל-e-commerce של בגדים, קהל יעד נשים 25-45, סגנון חברותי ועליז"
                </Badge>
                <Badge variant="outline" className="w-full justify-start">
                  "abandoned cart flow עם 3 מיילים, הנחה הדרגתית, urgency באימייל האחרון"
                </Badge>
                <Badge variant="outline" className="w-full justify-start">
                  "post-purchase sequence עם תודה, cross-sell, ובקשה לביקורת"
                </Badge>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-red-600 mb-2">❌ Prompts לא טובים</h4>
              <div className="space-y-2 text-sm">
                <Badge variant="secondary" className="w-full justify-start">
                  "צור לי מייל"
                </Badge>
                <Badge variant="secondary" className="w-full justify-start">
                  "אני רוצה קמפיין"
                </Badge>
                <Badge variant="secondary" className="w-full justify-start">
                  "עשה לי משהו טוב"
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold flex items-center gap-2">
              <Users className="w-4 h-4" />
              מה לכלול ב-prompt:
            </h4>
            <ul className="space-y-1 text-sm">
              <li>• <strong>סוג העסק:</strong> e-commerce, SaaS, שירותים מקצועיים, וכו'</li>
              <li>• <strong>קהל יעד:</strong> גיל, מין, תחומי עניין, התנהגות</li>
              <li>• <strong>מטרת הקמפיין:</strong> מכירות, engagement, retention, וכו'</li>
              <li>• <strong>טון ואישיות:</strong> פורמלי, חברותי, מקצועי, משעשע</li>
              <li>• <strong>מוצרים/שירותים:</strong> מה אתה מוכר ומה הערך הייחודי</li>
              <li>• <strong>תזמונים:</strong> מתי לשלוח כל מייל ולמה</li>
            </ul>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-800 mb-2">דוגמה למסר מושלם:</h4>
            <p className="text-sm text-blue-700">
              "צור welcome series של 5 מיילים לחנות אופנה אונליין עבור נשים בגילאי 25-40. 
              המותג מתמחה בבגדי עבודה אלגנטיים במחירים נגישים. 
              הטון צריך להיות מקצועי אבל חם, עם דגש על איכות ונוחות. 
              המטרה: לחנך על המותג, להציג את הקולקציה הבסיסית, ולעודד רכישה ראשונה עם הנחה של 15%. 
              תזמון: מייל ראשון מיידי, שני אחרי 2 ימים, שלישי אחרי 5 ימים, רביעי אחרי שבוע, חמישי אחרי שבועיים."
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
