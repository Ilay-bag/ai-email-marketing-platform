import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Clock, 
  Mail, 
  Settings, 
  Edit, 
  Plus, 
  ArrowRight, 
  Trash2,
  Play,
  Pause,
  Save
} from 'lucide-react';

interface CampaignFlowEditorProps {
  campaignId: number;
  onClose?: () => void;
}

interface EmailFlow {
  id: number;
  subject: string;
  sequenceOrder: number;
  delay: string;
  html: string;
  json: any;
}

interface CampaignFlow {
  id: number;
  title: string;
  type: string;
  status: string;
  triggers: Array<{ event: string; delay: string }>;
  description?: string;
  emails: EmailFlow[];
}

const delayOptions = [
  { value: '0h', label: 'Immediately' },
  { value: '1h', label: '1 hour' },
  { value: '6h', label: '6 hours' },
  { value: '12h', label: '12 hours' },
  { value: '24h', label: '1 day' },
  { value: '48h', label: '2 days' },
  { value: '72h', label: '3 days' },
  { value: '168h', label: '1 week' },
  { value: '336h', label: '2 weeks' },
];

const triggerEvents = [
  { value: 'signup', label: 'User Signup' },
  { value: 'abandoned_cart', label: 'Abandoned Cart' },
  { value: 'purchase', label: 'Purchase Made' },
  { value: 'inactive', label: 'User Inactive' },
  { value: 'birthday', label: 'Birthday' },
  { value: 'anniversary', label: 'Anniversary' },
  { value: 'custom', label: 'Custom Event' },
];

export function CampaignFlowEditor({ campaignId, onClose }: CampaignFlowEditorProps) {
  const [campaign, setCampaign] = useState<CampaignFlow | null>(null);
  const [editingTrigger, setEditingTrigger] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch campaign data
  const { data: campaignData, isLoading } = useQuery({
    queryKey: ['/api/campaigns', campaignId],
    queryFn: () => apiRequest('GET', `/api/campaigns/${campaignId}`),
    enabled: !!campaignId,
  });

  // Fetch campaign emails
  const { data: campaignEmails = [] } = useQuery({
    queryKey: ['/api/campaigns', campaignId, 'emails'],
    queryFn: () => apiRequest('GET', `/api/campaigns/${campaignId}/emails`),
    enabled: !!campaignId,
  });

  useEffect(() => {
    if (campaignData && campaignEmails) {
      setCampaign({
        ...campaignData,
        emails: campaignEmails.sort((a: EmailFlow, b: EmailFlow) => a.sequenceOrder - b.sequenceOrder)
      });
    }
  }, [campaignData, campaignEmails]);

  // Update campaign mutation
  const updateCampaign = useMutation({
    mutationFn: (updates: Partial<CampaignFlow>) => 
      apiRequest('PUT', `/api/campaigns/${campaignId}`, updates),
    onSuccess: () => {
      toast({
        title: 'Campaign Updated',
        description: 'Your campaign flow has been updated successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns', campaignId] });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update campaign',
        variant: 'destructive',
      });
    },
  });

  // Update email mutation
  const updateEmail = useMutation({
    mutationFn: ({ emailId, updates }: { emailId: number; updates: Partial<EmailFlow> }) =>
      apiRequest('PUT', `/api/emails/${emailId}`, updates),
    onSuccess: () => {
      toast({
        title: 'Email Updated',
        description: 'Email in the flow has been updated successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns', campaignId, 'emails'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update email',
        variant: 'destructive',
      });
    },
  });

  const handleTriggerUpdate = (index: number, updates: { event?: string; delay?: string }) => {
    if (!campaign) return;
    
    const newTriggers = [...campaign.triggers];
    newTriggers[index] = { ...newTriggers[index], ...updates };
    
    setCampaign({ ...campaign, triggers: newTriggers });
    updateCampaign.mutate({ triggers: newTriggers });
  };

  const handleEmailDelayUpdate = (emailId: number, delay: string) => {
    updateEmail.mutate({ emailId, updates: { delay } });
  };

  const handleStatusToggle = () => {
    if (!campaign) return;
    
    const newStatus = campaign.status === 'active' ? 'draft' : 'active';
    setCampaign({ ...campaign, status: newStatus });
    updateCampaign.mutate({ status: newStatus });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { label: 'Draft', color: 'bg-gray-100 text-gray-700' },
      active: { label: 'Active', color: 'bg-green-100 text-green-700' },
      paused: { label: 'Paused', color: 'bg-yellow-100 text-yellow-700' },
      scheduled: { label: 'Scheduled', color: 'bg-blue-100 text-blue-700' },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;
    return <Badge className={config.color}>{config.label}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-2 text-gray-600">Loading campaign flow...</p>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="p-6 text-center">
        <p className="text-gray-600">Campaign not found</p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 space-y-6">
        {/* Campaign Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{campaign.title}</h1>
            <p className="text-gray-600 mt-1">{campaign.type.replace('_', ' ')} campaign flow</p>
          </div>
          <div className="flex items-center gap-3">
            {getStatusBadge(campaign.status)}
            <Button
              variant={campaign.status === 'active' ? 'outline' : 'default'}
              size="sm"
              onClick={handleStatusToggle}
            >
              {campaign.status === 'active' ? (
                <>
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Activate
                </>
              )}
            </Button>
            {onClose && (
              <Button variant="outline" size="sm" onClick={onClose}>
                Close
              </Button>
            )}
          </div>
        </div>

        {/* Campaign Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Flow Triggers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {campaign.triggers.map((trigger, index) => (
                <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                  <div className="flex-1">
                    <Label className="text-sm font-medium">Event</Label>
                    {editingTrigger === index ? (
                      <Select
                        value={trigger.event}
                        onValueChange={(value) => handleTriggerUpdate(index, { event: value })}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {triggerEvents.map((event) => (
                            <SelectItem key={event.value} value={event.value}>
                              {event.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="mt-1 text-sm text-gray-700">
                        {triggerEvents.find(e => e.value === trigger.event)?.label || trigger.event}
                      </p>
                    )}
                  </div>
                  <div className="flex-1">
                    <Label className="text-sm font-medium">Delay</Label>
                    {editingTrigger === index ? (
                      <Select
                        value={trigger.delay}
                        onValueChange={(value) => handleTriggerUpdate(index, { delay: value })}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {delayOptions.map((delay) => (
                            <SelectItem key={delay.value} value={delay.value}>
                              {delay.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="mt-1 text-sm text-gray-700">
                        {delayOptions.find(d => d.value === trigger.delay)?.label || trigger.delay}
                      </p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingTrigger(editingTrigger === index ? null : index)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Email Flow */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Email Sequence ({campaign.emails.length} emails)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {campaign.emails.map((email, index) => (
                <div key={email.id} className="flex items-center gap-4 p-4 border rounded-lg">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{email.subject}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <Select
                        value={email.delay || '0h'}
                        onValueChange={(value) => handleEmailDelayUpdate(email.id, value)}
                      >
                        <SelectTrigger className="w-32 h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {delayOptions.map((delay) => (
                            <SelectItem key={delay.value} value={delay.value}>
                              {delay.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        // Store email data for editing
                        const emailData = {
                          id: email.id,
                          subject: email.subject,
                          html: email.html,
                          json: email.json
                        };
                        localStorage.setItem('emailBuilderData', JSON.stringify(emailData));
                        window.open(`/email-builder?emailId=${email.id}`, '_blank');
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    {index < campaign.emails.length - 1 && (
                      <ArrowRight className="h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </div>
              ))}
              
              {campaign.emails.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Mail className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No emails in this flow yet</p>
                  <Button variant="outline" size="sm" className="mt-2">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Email
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Export Options */}
        <Card>
          <CardHeader>
            <CardTitle>Export to Platform</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm">
                Export to Klaviyo
              </Button>
              <Button variant="outline" size="sm">
                Export to Mailchimp
              </Button>
              <Button variant="outline" size="sm">
                Export to Shopify
              </Button>
              <Button variant="outline" size="sm">
                Export to ActiveCampaign
              </Button>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Export this campaign flow to your connected email marketing platform.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}