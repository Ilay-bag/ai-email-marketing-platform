import React, { useState } from 'react';
import { EmailComponent } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import { ChromePicker } from 'react-color';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Settings, Palette, Type, Layout } from 'lucide-react';

interface PropertyPanelProps {
  selectedComponent: EmailComponent | undefined;
  globalStyles: any;
  onUpdateComponent: (id: string, updates: Partial<EmailComponent>) => void;
  onUpdateGlobalStyles: (styles: any) => void;
}

export function PropertyPanel({
  selectedComponent,
  globalStyles,
  onUpdateComponent,
  onUpdateGlobalStyles,
}: PropertyPanelProps) {
  const [activeTab, setActiveTab] = useState('component');

  const handleComponentUpdate = (updates: Partial<EmailComponent>) => {
    if (selectedComponent) {
      onUpdateComponent(selectedComponent.id, updates);
    }
  };

  const handleContentUpdate = (contentUpdates: any) => {
    if (selectedComponent) {
      onUpdateComponent(selectedComponent.id, {
        content: { ...selectedComponent.content, ...contentUpdates },
      });
    }
  };

  const handleStyleUpdate = (styleUpdates: any) => {
    if (selectedComponent) {
      onUpdateComponent(selectedComponent.id, {
        styles: { ...selectedComponent.styles, ...styleUpdates },
      });
    }
  };

  const ColorPicker = ({ color, onChange, label }: { color: string; onChange: (color: string) => void; label: string }) => (
    <div className="space-y-2">
      <Label className="text-sm font-medium">{label}</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className="w-full justify-start text-left font-normal">
            <div className="w-4 h-4 rounded-sm border mr-2" style={{ backgroundColor: color }} />
            {color}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <ChromePicker color={color} onChange={(c) => onChange(c.hex)} />
        </PopoverContent>
      </Popover>
    </div>
  );

  const renderComponentProperties = () => {
    if (!selectedComponent) {
      return (
        <div className="text-center py-8 text-gray-500">
          <Settings className="w-8 h-8 mx-auto mb-2" />
          <p>Select a component to edit its properties</p>
        </div>
      );
    }

    const { type, content, styles } = selectedComponent;

    return (
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold mb-4 capitalize">{type} Properties</h3>
        </div>

        {/* Content Properties */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-base">
              <Type className="w-4 h-4 mr-2" />
              Content
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {type === 'text' || type === 'heading' ? (
              <>
                <div>
                  <Label htmlFor="text-content">Text</Label>
                  <Input
                    id="text-content"
                    value={content.text}
                    onChange={(e) => handleContentUpdate({ text: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="font-size">Font Size</Label>
                  <Select value={content.fontSize} onValueChange={(value) => handleContentUpdate({ fontSize: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="12px">12px</SelectItem>
                      <SelectItem value="14px">14px</SelectItem>
                      <SelectItem value="16px">16px</SelectItem>
                      <SelectItem value="18px">18px</SelectItem>
                      <SelectItem value="20px">20px</SelectItem>
                      <SelectItem value="24px">24px</SelectItem>
                      <SelectItem value="28px">28px</SelectItem>
                      <SelectItem value="32px">32px</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="text-align">Text Alignment</Label>
                  <Select value={content.textAlign} onValueChange={(value) => handleContentUpdate({ textAlign: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="left">Left</SelectItem>
                      <SelectItem value="center">Center</SelectItem>
                      <SelectItem value="right">Right</SelectItem>
                      <SelectItem value="justify">Justify</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <ColorPicker
                  color={content.color}
                  onChange={(color) => handleContentUpdate({ color })}
                  label="Text Color"
                />
              </>
            ) : null}

            {type === 'button' ? (
              <>
                <div>
                  <Label htmlFor="button-text">Button Text</Label>
                  <Input
                    id="button-text"
                    value={content.text}
                    onChange={(e) => handleContentUpdate({ text: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="button-link">Link URL</Label>
                  <Input
                    id="button-link"
                    value={content.link}
                    onChange={(e) => handleContentUpdate({ link: e.target.value })}
                    placeholder="https://example.com"
                  />
                </div>
                <ColorPicker
                  color={content.backgroundColor}
                  onChange={(color) => handleContentUpdate({ backgroundColor: color })}
                  label="Background Color"
                />
                <ColorPicker
                  color={content.color}
                  onChange={(color) => handleContentUpdate({ color })}
                  label="Text Color"
                />
              </>
            ) : null}

            {type === 'image' ? (
              <>
                <div>
                  <Label htmlFor="image-src">Image URL</Label>
                  <Input
                    id="image-src"
                    value={content.src}
                    onChange={(e) => handleContentUpdate({ src: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
                <div>
                  <Label htmlFor="image-alt">Alt Text</Label>
                  <Input
                    id="image-alt"
                    value={content.alt}
                    onChange={(e) => handleContentUpdate({ alt: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="image-width">Width</Label>
                  <Input
                    id="image-width"
                    value={content.width}
                    onChange={(e) => handleContentUpdate({ width: e.target.value })}
                    placeholder="100% or 300px"
                  />
                </div>
              </>
            ) : null}

            {type === 'divider' ? (
              <>
                <ColorPicker
                  color={content.color}
                  onChange={(color) => handleContentUpdate({ color })}
                  label="Divider Color"
                />
                <div>
                  <Label htmlFor="divider-height">Height</Label>
                  <Input
                    id="divider-height"
                    value={content.height}
                    onChange={(e) => handleContentUpdate({ height: e.target.value })}
                    placeholder="1px"
                  />
                </div>
              </>
            ) : null}

            {type === 'spacer' ? (
              <div>
                <Label htmlFor="spacer-height">Height</Label>
                <Input
                  id="spacer-height"
                  value={content.height}
                  onChange={(e) => handleContentUpdate({ height: e.target.value })}
                  placeholder="24px"
                />
              </div>
            ) : null}
          </CardContent>
        </Card>

        {/* Style Properties */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-base">
              <Layout className="w-4 h-4 mr-2" />
              Layout & Spacing
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="padding">Padding</Label>
              <Input
                id="padding"
                value={styles.padding}
                onChange={(e) => handleStyleUpdate({ padding: e.target.value })}
                placeholder="16px"
              />
            </div>
            <div>
              <Label htmlFor="margin">Margin</Label>
              <Input
                id="margin"
                value={styles.margin}
                onChange={(e) => handleStyleUpdate({ margin: e.target.value })}
                placeholder="8px 0"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderGlobalStyles = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Global Styles</h3>
        <p className="text-sm text-gray-600 mb-4">
          These styles apply to the entire email template
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-base">
            <Palette className="w-4 h-4 mr-2" />
            General
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ColorPicker
            color={globalStyles.backgroundColor}
            onChange={(color) => onUpdateGlobalStyles({ backgroundColor: color })}
            label="Background Color"
          />
          <div>
            <Label htmlFor="max-width">Max Width</Label>
            <Input
              id="max-width"
              value={globalStyles.maxWidth}
              onChange={(e) => onUpdateGlobalStyles({ maxWidth: e.target.value })}
              placeholder="600px"
            />
          </div>
          <div>
            <Label htmlFor="font-family">Font Family</Label>
            <Select 
              value={globalStyles.fontFamily} 
              onValueChange={(value) => onUpdateGlobalStyles({ fontFamily: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Arial, sans-serif">Arial</SelectItem>
                <SelectItem value="Georgia, serif">Georgia</SelectItem>
                <SelectItem value="'Times New Roman', serif">Times New Roman</SelectItem>
                <SelectItem value="Helvetica, sans-serif">Helvetica</SelectItem>
                <SelectItem value="'Courier New', monospace">Courier New</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="font-size">Default Font Size</Label>
            <Select 
              value={globalStyles.fontSize} 
              onValueChange={(value) => onUpdateGlobalStyles({ fontSize: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="14px">14px</SelectItem>
                <SelectItem value="16px">16px</SelectItem>
                <SelectItem value="18px">18px</SelectItem>
                <SelectItem value="20px">20px</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <ColorPicker
            color={globalStyles.color}
            onChange={(color) => onUpdateGlobalStyles({ color })}
            label="Default Text Color"
          />
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="h-full flex flex-col">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="component">Component</TabsTrigger>
          <TabsTrigger value="global">Global</TabsTrigger>
        </TabsList>
        <TabsContent value="component" className="flex-1 overflow-y-auto">
          {renderComponentProperties()}
        </TabsContent>
        <TabsContent value="global" className="flex-1 overflow-y-auto">
          {renderGlobalStyles()}
        </TabsContent>
      </Tabs>
    </div>
  );
}