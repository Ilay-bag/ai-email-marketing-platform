export interface EmailComponent {
  id: string;
  type: string;
  content: any;
  styles: Record<string, any>;
}

export interface EmailBuilderState {
  components: EmailComponent[];
  selectedComponentId: string | null;
  globalStyles: {
    backgroundColor: string;
    fontFamily: string;
    fontSize: string;
    color: string;
    maxWidth: string;
  };
  subject?: string;
  history: EmailComponent[][];
  historyIndex: number;
}

export interface ComponentPaletteItem {
  id: string;
  type: string;
  name: string;
  icon: React.ComponentType<any>;
  description: string;
  category: string;
}

export interface DragItem {
  id: string;
  type: string;
  componentType?: string;
}

export interface DropResult {
  type: string;
  index?: number;
}