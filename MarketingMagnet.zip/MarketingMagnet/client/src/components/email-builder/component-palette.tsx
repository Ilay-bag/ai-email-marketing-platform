import React from 'react';
import { useDraggable } from '@dnd-kit/core';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Type, 
  Heading, 
  MousePointer, 
  Image, 
  Minus, 
  Space,
  Columns,
  AlignLeft,
  List,
  Quote,
  Crown,
  FileText
} from 'lucide-react';
import { ComponentPaletteItem } from './types';

const paletteItems: ComponentPaletteItem[] = [
  {
    id: 'text',
    type: 'text',
    name: 'Text',
    icon: Type,
    description: 'Add text content',
    category: 'Content',
  },
  {
    id: 'heading',
    type: 'heading',
    name: 'Heading',
    icon: Heading,
    description: 'Add a heading',
    category: 'Content',
  },
  {
    id: 'button',
    type: 'button',
    name: 'Button',
    icon: MousePointer,
    description: 'Add a clickable button',
    category: 'Content',
  },
  {
    id: 'image',
    type: 'image',
    name: 'Image',
    icon: Image,
    description: 'Add an image',
    category: 'Media',
  },
  {
    id: 'divider',
    type: 'divider',
    name: 'Divider',
    icon: Minus,
    description: 'Add a horizontal line',
    category: 'Layout',
  },
  {
    id: 'spacer',
    type: 'spacer',
    name: 'Spacer',
    icon: Space,
    description: 'Add empty space',
    category: 'Layout',
  },
  {
    id: 'columns',
    type: 'columns',
    name: 'Columns',
    icon: Columns,
    description: 'Add column layout',
    category: 'Layout',
  },
  {
    id: 'header',
    type: 'header',
    name: 'Header',
    icon: Crown,
    description: 'Add email header with title',
    category: 'Structure',
  },
  {
    id: 'footer',
    type: 'footer',
    name: 'Footer',
    icon: FileText,
    description: 'Add email footer',
    category: 'Structure',
  },
  {
    id: 'list',
    type: 'list',
    name: 'List',
    icon: List,
    description: 'Add bullet or numbered list',
    category: 'Content',
  },
  {
    id: 'html',
    type: 'html',
    name: 'HTML',
    icon: AlignLeft,
    description: 'Add custom HTML content',
    category: 'Advanced',
  },
];

interface DraggableComponentProps {
  item: ComponentPaletteItem;
}

function DraggableComponent({ item }: DraggableComponentProps) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: item.id,
    data: {
      type: 'palette-item',
      componentType: item.type,
    },
  });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      }
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`cursor-grab active:cursor-grabbing ${isDragging ? 'opacity-50' : ''}`}
    >
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
              <item.icon className="w-4 h-4 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium text-sm">{item.name}</h3>
              <p className="text-xs text-gray-500">{item.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function ComponentPalette() {
  const categories = Array.from(new Set(paletteItems.map(item => item.category)));

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold mb-3">Components</h2>
        <p className="text-sm text-gray-600 mb-4">
          Drag components to the canvas to build your email
        </p>
      </div>

      {categories.map(category => (
        <div key={category}>
          <h3 className="text-sm font-medium text-gray-700 mb-2">{category}</h3>
          <div className="space-y-2">
            {paletteItems
              .filter(item => item.category === category)
              .map(item => (
                <DraggableComponent key={item.id} item={item} />
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}