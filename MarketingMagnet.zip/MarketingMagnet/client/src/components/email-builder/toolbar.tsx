import React from 'react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Undo, 
  Redo, 
  Save, 
  Eye, 
  Download, 
  Settings,
  Trash2,
  Copy,
  Paste,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

interface EmailBuilderToolbarProps {
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onSave: () => void;
  onPreview: () => void;
  onClear: () => void;
  onExport: () => void;
  onImport: () => void;
}

export function EmailBuilderToolbar({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onSave,
  onPreview,
  onClear,
  onExport,
  onImport,
}: EmailBuilderToolbarProps) {
  return (
    <div className="flex items-center space-x-2 p-2 bg-white border-b border-gray-200">
      {/* History Actions */}
      <div className="flex items-center space-x-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={onUndo}
          disabled={!canUndo}
          title="Undo"
        >
          <Undo className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onRedo}
          disabled={!canRedo}
          title="Redo"
        >
          <Redo className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-6" />

      {/* Main Actions */}
      <div className="flex items-center space-x-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={onSave}
          title="Save"
        >
          <Save className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onPreview}
          title="Preview"
        >
          <Eye className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onExport}
          title="Export HTML"
        >
          <Download className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-6" />

      {/* Utility Actions */}
      <div className="flex items-center space-x-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={onClear}
          title="Clear All"
          className="text-red-600 hover:text-red-700"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}