import React from 'react';
import { EmailComponent } from './types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Download, Send } from 'lucide-react';
import { RenderEmailComponent } from './render-email-component';

interface PreviewPanelProps {
  components: EmailComponent[];
  globalStyles: any;
  onClose: () => void;
}

export function PreviewPanel({ components, globalStyles, onClose }: PreviewPanelProps) {
  const generateHTML = () => {
    const componentHTML = components.map(component => {
      // Convert component to HTML string
      const div = document.createElement('div');
      // This is a simplified conversion - in a real app you'd want proper HTML generation
      return `<div style="padding: ${component.styles.padding || '16px'}; margin: ${component.styles.margin || '8px 0'};">
        ${component.content.text || component.content.src || ''}
      </div>`;
    }).join('');

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Email Preview</title>
  <style>
    body {
      font-family: ${globalStyles.fontFamily};
      font-size: ${globalStyles.fontSize};
      color: ${globalStyles.color};
      background-color: ${globalStyles.backgroundColor};
      margin: 0;
      padding: 0;
    }
    .email-container {
      max-width: ${globalStyles.maxWidth};
      margin: 0 auto;
      background-color: #ffffff;
    }
  </style>
</head>
<body>
  <div class="email-container">
    ${componentHTML}
  </div>
</body>
</html>`;
  };

  const handleDownload = () => {
    const html = generateHTML();
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'email-template.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Email Preview</span>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="w-4 h-4 mr-1" />
                Download HTML
              </Button>
              <Button variant="outline" size="sm" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto">
          <div className="bg-gray-100 p-4 rounded-lg">
            <div 
              className="bg-white mx-auto shadow-lg"
              style={{ 
                maxWidth: globalStyles.maxWidth,
                fontFamily: globalStyles.fontFamily,
                fontSize: globalStyles.fontSize,
                color: globalStyles.color,
              }}
            >
              {/* Email Header */}
              <div className="bg-gray-50 border-b border-gray-200 p-4">
                <div className="text-sm text-gray-600 space-y-1">
                  <div><strong>From:</strong> your-email@company.com</div>
                  <div><strong>Subject:</strong> Your Email Subject</div>
                  <div><strong>Preview:</strong> This is how your email will look...</div>
                </div>
              </div>
              
              {/* Email Body */}
              <div className="p-4">
                {components.map((component) => (
                  <RenderEmailComponent
                    key={component.id}
                    component={component}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}