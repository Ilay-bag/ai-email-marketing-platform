import React from 'react';
import { EmailComponent } from './types';

interface RenderEmailComponentProps {
  component: EmailComponent;
  onUpdate?: (updates: Partial<EmailComponent>) => void;
}

export function RenderEmailComponent({ component, onUpdate }: RenderEmailComponentProps) {
  const { type, content, styles } = component;

  const handleContentChange = (newContent: any) => {
    onUpdate?.({ content: { ...content, ...newContent } });
  };

  const renderComponent = () => {
    switch (type) {
      case 'text':
        return (
          <div
            style={{
              ...styles,
              fontSize: content.fontSize,
              color: content.color,
              fontFamily: content.fontFamily,
              textAlign: content.textAlign,
            }}
            contentEditable
            suppressContentEditableWarning
            onBlur={(e) => handleContentChange({ text: e.target.innerText })}
            dangerouslySetInnerHTML={{ __html: content.text }}
          />
        );

      case 'heading':
        return (
          <div
            style={{
              ...styles,
              fontSize: content.fontSize,
              color: content.color,
              fontFamily: content.fontFamily,
              textAlign: content.textAlign,
              fontWeight: content.fontWeight,
            }}
            contentEditable
            suppressContentEditableWarning
            onBlur={(e) => handleContentChange({ text: e.target.innerText })}
            dangerouslySetInnerHTML={{ __html: content.text }}
          />
        );

      case 'button':
        return (
          <div style={{ ...styles, textAlign: content.textAlign }}>
            <button
              style={{
                backgroundColor: content.backgroundColor,
                color: content.color,
                fontSize: content.fontSize,
                padding: content.padding,
                borderRadius: content.borderRadius,
                border: 'none',
                cursor: 'pointer',
                textDecoration: 'none',
                display: 'inline-block',
              }}
              contentEditable
              suppressContentEditableWarning
              onBlur={(e) => handleContentChange({ text: e.target.innerText })}
            >
              {content.text}
            </button>
          </div>
        );

      case 'image':
        return (
          <div style={styles}>
            <img
              src={content.src}
              alt={content.alt}
              style={{
                width: content.width,
                height: content.height,
                maxWidth: '100%',
                display: 'block',
              }}
            />
          </div>
        );

      case 'divider':
        return (
          <div style={styles}>
            <hr
              style={{
                border: 'none',
                height: content.height,
                backgroundColor: content.color,
                width: content.width,
                margin: '0 auto',
              }}
            />
          </div>
        );

      case 'spacer':
        return (
          <div
            style={{
              ...styles,
              height: content.height,
            }}
          />
        );

      case 'columns':
        return (
          <div style={styles}>
            <div style={{ display: 'flex', gap: '16px' }}>
              {content.columns.map((column: any, index: number) => (
                <div
                  key={index}
                  style={{
                    flex: column.width,
                    minHeight: '50px',
                    border: '1px dashed #ddd',
                    borderRadius: '4px',
                    padding: '8px',
                  }}
                >
                  {column.components.length === 0 ? (
                    <div style={{ color: '#999', fontSize: '14px', textAlign: 'center' }}>
                      Drop components here
                    </div>
                  ) : (
                    column.components.map((comp: EmailComponent) => (
                      <RenderEmailComponent key={comp.id} component={comp} />
                    ))
                  )}
                </div>
              ))}
            </div>
          </div>
        );

      case 'html':
        return (
          <div style={styles}>
            <div
              contentEditable
              suppressContentEditableWarning
              style={{
                minHeight: '50px',
                padding: '8px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontFamily: 'monospace',
                fontSize: '14px',
                backgroundColor: '#f9f9f9',
              }}
              onBlur={(e) => handleContentChange({ html: e.target.innerHTML })}
              dangerouslySetInnerHTML={{ __html: content.html }}
            />
          </div>
        );

      case 'header':
        return (
          <div style={styles}>
            <h1
              style={{
                margin: '0 0 8px 0',
                fontSize: '28px',
                fontWeight: 'bold',
                color: '#ffffff',
              }}
              contentEditable
              suppressContentEditableWarning
              onBlur={(e) => handleContentChange({ title: e.target.innerText })}
            >
              {content.title}
            </h1>
            {content.subtitle && (
              <p
                style={{
                  margin: '0',
                  fontSize: '18px',
                  opacity: '0.9',
                  color: '#ffffff',
                }}
                contentEditable
                suppressContentEditableWarning
                onBlur={(e) => handleContentChange({ subtitle: e.target.innerText })}
              >
                {content.subtitle}
              </p>
            )}
          </div>
        );

      case 'footer':
        return (
          <div style={styles}>
            <p
              style={{
                margin: '0 0 16px 0',
                fontSize: '14px',
              }}
              contentEditable
              suppressContentEditableWarning
              onBlur={(e) => handleContentChange({ text: e.target.innerText })}
            >
              {content.text}
            </p>
            <p style={{ margin: '0 0 8px 0', fontSize: '12px' }}>
              {content.companyInfo}
            </p>
            <p style={{ margin: '0', fontSize: '12px' }}>
              <a
                href={content.unsubscribeUrl || '#'}
                style={{ color: 'inherit', textDecoration: 'underline' }}
                contentEditable
                suppressContentEditableWarning
                onBlur={(e) => handleContentChange({ unsubscribeText: e.target.innerText })}
              >
                {content.unsubscribeText || 'Unsubscribe'}
              </a>
            </p>
          </div>
        );

      case 'list':
        return (
          <div style={styles}>
            <ul style={{ margin: '0', paddingLeft: '24px' }}>
              {(content.items || []).map((item: any, index: number) => (
                <li
                  key={index}
                  style={{ margin: '8px 0' }}
                  contentEditable
                  suppressContentEditableWarning
                  onBlur={(e) => {
                    const newItems = [...(content.items || [])];
                    newItems[index] = { ...item, text: e.target.innerText };
                    handleContentChange({ items: newItems });
                  }}
                >
                  {item.text}
                </li>
              ))}
            </ul>
          </div>
        );

      default:
        return (
          <div style={styles}>
            <div style={{ color: '#999', fontSize: '14px' }}>
              Unknown component type: {type}
            </div>
          </div>
        );
    }
  };

  return <div className="relative">{renderComponent()}</div>;
}