import React from 'react';
import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { SortableEmailComponent } from './sortable-email-component';
import { EmailComponent } from './types';
import { Card } from '@/components/ui/card';

interface EmailCanvasProps {
  components: EmailComponent[];
  selectedComponentId: string | null;
  viewMode: 'desktop' | 'mobile';
  onSelectComponent: (id: string) => void;
  onUpdateComponent: (id: string, updates: Partial<EmailComponent>) => void;
  onDeleteComponent: (id: string) => void;
}

export function EmailCanvas({
  components,
  selectedComponentId,
  viewMode,
  onSelectComponent,
  onUpdateComponent,
  onDeleteComponent,
}: EmailCanvasProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: 'email-canvas',
    data: {
      type: 'canvas',
    },
  });

  const canvasWidth = viewMode === 'desktop' ? '600px' : '320px';

  return (
    <div className="w-full h-full flex justify-center">
      <div
        ref={setNodeRef}
        className={`bg-white shadow-lg transition-all duration-300 ${
          isOver ? 'ring-2 ring-blue-500' : ''
        }`}
        style={{ width: canvasWidth, minHeight: '800px' }}
      >
        {/* Email Header */}
        <div className="bg-gray-50 border-b border-gray-200 p-4">
          <div className="text-sm text-gray-600 space-y-1">
            <div>From: your-email@company.com</div>
            <div>Subject: Your Email Subject</div>
          </div>
        </div>

        {/* Email Body */}
        <div className="p-4">
          {components.length === 0 ? (
            <div className="text-center py-20 text-gray-500">
              <div className="text-lg font-medium mb-2">Start building your email</div>
              <div className="text-sm">Drag components from the sidebar to get started</div>
            </div>
          ) : (
            <SortableContext items={components.map(c => c.id)} strategy={verticalListSortingStrategy}>
              <div className="space-y-2">
                {components.map((component) => (
                  <SortableEmailComponent
                    key={component.id}
                    component={component}
                    isSelected={component.id === selectedComponentId}
                    onSelect={onSelectComponent}
                    onUpdate={onUpdateComponent}
                    onDelete={onDeleteComponent}
                  />
                ))}
              </div>
            </SortableContext>
          )}
        </div>
      </div>
    </div>
  );
}