import { EmailBuilderState, EmailComponent } from './types';

export const initialState: EmailBuilderState = {
  components: [],
  selectedComponentId: null,
  globalStyles: {
    backgroundColor: '#ffffff',
    fontFamily: 'Arial, sans-serif',
    fontSize: '16px',
    color: '#333333',
    maxWidth: '600px',
  },
  history: [],
  historyIndex: -1,
};

export type EmailBuilderAction =
  | { type: 'ADD_COMPONENT'; payload: EmailComponent }
  | { type: 'UPDATE_COMPONENT'; payload: { id: string; updates: Partial<EmailComponent> } }
  | { type: 'DELETE_COMPONENT'; payload: string }
  | { type: 'SELECT_COMPONENT'; payload: string | null }
  | { type: 'REORDER_COMPONENTS'; payload: EmailComponent[] }
  | { type: 'INSERT_COMPONENT'; payload: { component: EmailComponent; index: number } }
  | { type: 'SET_COMPONENTS'; payload: EmailComponent[] }
  | { type: 'UPDATE_GLOBAL_STYLES'; payload: Partial<EmailBuilderState['globalStyles']> }
  | { type: 'SET_SUBJECT'; payload: string }
  | { type: 'UNDO' }
  | { type: 'REDO' }
  | { type: 'RESET' };

export function emailBuilderReducer(
  state: EmailBuilderState,
  action: EmailBuilderAction
): EmailBuilderState {
  const saveToHistory = (newState: EmailBuilderState) => {
    const newHistory = state.history.slice(0, state.historyIndex + 1);
    newHistory.push([...state.components]);
    return {
      ...newState,
      history: newHistory,
      historyIndex: newHistory.length - 1,
    };
  };

  switch (action.type) {
    case 'ADD_COMPONENT':
      return saveToHistory({
        ...state,
        components: [...state.components, action.payload],
      });

    case 'UPDATE_COMPONENT':
      return saveToHistory({
        ...state,
        components: state.components.map(component =>
          component.id === action.payload.id
            ? { ...component, ...action.payload.updates }
            : component
        ),
      });

    case 'DELETE_COMPONENT':
      return saveToHistory({
        ...state,
        components: state.components.filter(c => c.id !== action.payload),
        selectedComponentId: state.selectedComponentId === action.payload ? null : state.selectedComponentId,
      });

    case 'SELECT_COMPONENT':
      return {
        ...state,
        selectedComponentId: action.payload,
      };

    case 'REORDER_COMPONENTS':
      return saveToHistory({
        ...state,
        components: action.payload,
      });

    case 'INSERT_COMPONENT':
      const newComponents = [...state.components];
      newComponents.splice(action.payload.index, 0, action.payload.component);
      return saveToHistory({
        ...state,
        components: newComponents,
      });

    case 'SET_COMPONENTS':
      return saveToHistory({
        ...state,
        components: action.payload,
      });

    case 'UPDATE_GLOBAL_STYLES':
      return {
        ...state,
        globalStyles: { ...state.globalStyles, ...action.payload },
      };

    case 'SET_SUBJECT':
      return {
        ...state,
        subject: action.payload,
      };

    case 'UNDO':
      if (state.historyIndex > 0) {
        return {
          ...state,
          components: state.history[state.historyIndex - 1],
          historyIndex: state.historyIndex - 1,
        };
      }
      return state;

    case 'REDO':
      if (state.historyIndex < state.history.length - 1) {
        return {
          ...state,
          components: state.history[state.historyIndex + 1],
          historyIndex: state.historyIndex + 1,
        };
      }
      return state;

    case 'RESET':
      return initialState;

    default:
      return state;
  }
}