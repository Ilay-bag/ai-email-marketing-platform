import React, { useState, useCallback } from 'react';
import {
  DndContext,
  DragEndEvent,
  DragOverEvent,
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
  UniqueIdentifier,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { ComponentPalette } from './component-palette';
import { EmailCanvas } from './email-canvas';
import { PropertyPanel } from './property-panel';
import { PreviewPanel } from './preview-panel';
import { EmailBuilderToolbar } from './toolbar';
import { emailBuilderReducer, initialState } from './email-builder-state';
import { EmailComponent, EmailBuilderState } from './types';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Monitor, Smartphone, Save, Eye } from "lucide-react";

interface EmailBuilderProps {
  initialContent?: any;
  onSave?: (content: any) => void;
  onPreview?: (content: any) => void;
}

export function EmailBuilder({ initialContent, onSave, onPreview }: EmailBuilderProps) {
  const [state, dispatch] = React.useReducer(emailBuilderReducer, {
    ...initialState,
    components: initialContent?.components || initialState.components,
    globalStyles: initialContent?.globalStyles || initialState.globalStyles,
  });

  // Handle converting HTML content to components if needed
  React.useEffect(() => {
    if (initialContent?.html && (!initialContent?.components || initialContent.components.length === 0)) {
      // Convert HTML to basic text component
      const htmlComponent = {
        id: `html-${Date.now()}`,
        type: 'html',
        content: {
          html: initialContent.html,
        },
        styles: {
          padding: '16px',
          margin: '8px 0',
        },
      };
      dispatch({ type: 'SET_COMPONENTS', payload: [htmlComponent] });
    }
  }, [initialContent]);

  const [activeId, setActiveId] = useState<UniqueIdentifier | null>(null);
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [showPreview, setShowPreview] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id);
  }, []);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over) return;

    // Handle drag from palette to canvas
    if (active.data.current?.type === 'palette-item') {
      const componentType = active.data.current.componentType;
      const newComponent = createComponent(componentType);
      
      if (over.data.current?.type === 'canvas') {
        dispatch({ type: 'ADD_COMPONENT', payload: newComponent });
      } else if (over.data.current?.type === 'component') {
        const targetIndex = state.components.findIndex(c => c.id === over.id);
        dispatch({ 
          type: 'INSERT_COMPONENT', 
          payload: { component: newComponent, index: targetIndex + 1 } 
        });
      }
    }
    
    // Handle reordering within canvas
    else if (active.data.current?.type === 'component' && over.data.current?.type === 'component') {
      const oldIndex = state.components.findIndex(c => c.id === active.id);
      const newIndex = state.components.findIndex(c => c.id === over.id);
      
      if (oldIndex !== newIndex) {
        const newComponents = arrayMove(state.components, oldIndex, newIndex);
        dispatch({ type: 'REORDER_COMPONENTS', payload: newComponents });
      }
    }

    setActiveId(null);
  }, [state.components]);

  const createComponent = (type: string): EmailComponent => {
    const id = `${type}-${Date.now()}`;
    const baseComponent = {
      id,
      type,
      styles: {
        padding: '16px',
        margin: '8px 0',
      },
    };

    switch (type) {
      case 'text':
        return {
          ...baseComponent,
          content: {
            text: 'Enter your text here...',
            fontSize: '16px',
            color: '#333333',
            fontFamily: 'Arial, sans-serif',
            textAlign: 'left',
          },
        };
      case 'heading':
        return {
          ...baseComponent,
          content: {
            text: 'Your Heading',
            fontSize: '24px',
            color: '#333333',
            fontFamily: 'Arial, sans-serif',
            textAlign: 'center',
            fontWeight: 'bold',
          },
        };
      case 'button':
        return {
          ...baseComponent,
          content: {
            text: 'Click Here',
            backgroundColor: '#007bff',
            color: '#ffffff',
            fontSize: '16px',
            padding: '12px 24px',
            borderRadius: '4px',
            textAlign: 'center',
            link: '#',
          },
        };
      case 'image':
        return {
          ...baseComponent,
          content: {
            src: 'https://via.placeholder.com/600x200',
            alt: 'Image description',
            width: '100%',
            height: 'auto',
          },
        };
      case 'divider':
        return {
          ...baseComponent,
          content: {
            color: '#dddddd',
            height: '1px',
            width: '100%',
          },
        };
      case 'spacer':
        return {
          ...baseComponent,
          content: {
            height: '24px',
          },
        };
      case 'columns':
        return {
          ...baseComponent,
          content: {
            columns: [
              { width: '50%', components: [] },
              { width: '50%', components: [] },
            ],
          },
        };
      case 'html':
        return {
          ...baseComponent,
          content: {
            html: 'Enter your HTML content here...',
          },
        };
      default:
        return baseComponent as EmailComponent;
    }
  };

  const handleSelectComponent = (id: string) => {
    dispatch({ type: 'SELECT_COMPONENT', payload: id });
  };

  const handleUpdateComponent = (id: string, updates: Partial<EmailComponent>) => {
    dispatch({ type: 'UPDATE_COMPONENT', payload: { id, updates } });
  };

  const handleDeleteComponent = (id: string) => {
    dispatch({ type: 'DELETE_COMPONENT', payload: id });
  };

  const handleSave = () => {
    const content = {
      components: state.components,
      globalStyles: state.globalStyles,
      subject: state.subject || 'New Email',
      html: generateHTMLFromComponents(state.components),
    };
    onSave?.(content);
  };

  const generateHTMLFromComponents = (components: EmailComponent[]): string => {
    let html = '<div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">';
    
    components.forEach(component => {
      const styles = Object.entries(component.styles || {})
        .map(([key, value]) => `${key.replace(/([A-Z])/g, '-$1').toLowerCase()}: ${value}`)
        .join('; ');
      
      html += `<div style="${styles}">`;
      
      switch (component.type) {
        case 'text':
          html += `<p style="color: ${component.content.color}; font-size: ${component.content.fontSize}; text-align: ${component.content.textAlign};">${component.content.text}</p>`;
          break;
        case 'heading':
          html += `<h2 style="color: ${component.content.color}; font-size: ${component.content.fontSize}; text-align: ${component.content.textAlign}; font-weight: ${component.content.fontWeight};">${component.content.text}</h2>`;
          break;
        case 'button':
          html += `<div style="text-align: ${component.content.textAlign};">
            <a href="${component.content.link}" style="background-color: ${component.content.backgroundColor}; color: ${component.content.color}; padding: ${component.content.padding}; border-radius: ${component.content.borderRadius}; text-decoration: none; display: inline-block;">${component.content.text}</a>
          </div>`;
          break;
        case 'image':
          html += `<img src="${component.content.src}" alt="${component.content.alt}" style="width: ${component.content.width}; height: ${component.content.height};" />`;
          break;
        case 'divider':
          html += `<hr style="border: none; height: ${component.content.height}; background-color: ${component.content.color}; width: ${component.content.width};" />`;
          break;
        case 'spacer':
          html += `<div style="height: ${component.content.height};"></div>`;
          break;
        case 'html':
          html += component.content.html;
          break;
        default:
          html += `<div>Unknown component type: ${component.type}</div>`;
      }
      
      html += '</div>';
    });
    
    html += '</div>';
    return html;
  };

  const handlePreview = () => {
    const content = {
      components: state.components,
      globalStyles: state.globalStyles,
    };
    onPreview?.(content);
    setShowPreview(true);
  };

  const selectedComponent = state.components.find(c => c.id === state.selectedComponentId);

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Toolbar */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-semibold">Email Builder</h1>
            <div className="flex bg-gray-100 rounded-lg p-1">
              <Button
                variant={viewMode === 'desktop' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('desktop')}
              >
                <Monitor className="w-4 h-4 mr-1" />
                Desktop
              </Button>
              <Button
                variant={viewMode === 'mobile' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('mobile')}
              >
                <Smartphone className="w-4 h-4 mr-1" />
                Mobile
              </Button>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" onClick={handlePreview}>
              <Eye className="w-4 h-4 mr-1" />
              Preview
            </Button>
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-1" />
              Save
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          {/* Component Palette */}
          <div className="w-64 bg-white border-r border-gray-200 p-4 overflow-y-auto">
            <ComponentPalette />
          </div>

          {/* Canvas Area */}
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="max-w-4xl mx-auto">
              <EmailCanvas
                components={state.components}
                selectedComponentId={state.selectedComponentId}
                viewMode={viewMode}
                onSelectComponent={handleSelectComponent}
                onUpdateComponent={handleUpdateComponent}
                onDeleteComponent={handleDeleteComponent}
              />
            </div>
          </div>

          {/* Properties Panel */}
          <div className="w-80 bg-white border-l border-gray-200 p-4 overflow-y-auto">
            <PropertyPanel
              selectedComponent={selectedComponent}
              globalStyles={state.globalStyles}
              onUpdateComponent={handleUpdateComponent}
              onUpdateGlobalStyles={(styles) => 
                dispatch({ type: 'UPDATE_GLOBAL_STYLES', payload: styles })
              }
            />
          </div>
        </DndContext>
      </div>

      {/* Preview Modal */}
      {showPreview && (
        <PreviewPanel
          components={state.components}
          globalStyles={state.globalStyles}
          onClose={() => setShowPreview(false)}
        />
      )}
    </div>
  );
}