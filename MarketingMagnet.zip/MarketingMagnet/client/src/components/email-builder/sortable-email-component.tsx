import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { EmailComponent } from './types';
import { RenderEmailComponent } from './render-email-component';
import { Button } from '@/components/ui/button';
import { Trash2, Move } from 'lucide-react';

interface SortableEmailComponentProps {
  component: EmailComponent;
  isSelected: boolean;
  onSelect: (id: string) => void;
  onUpdate: (id: string, updates: Partial<EmailComponent>) => void;
  onDelete: (id: string) => void;
}

export function SortableEmailComponent({
  component,
  isSelected,
  onSelect,
  onUpdate,
  onDelete,
}: SortableEmailComponentProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: component.id,
    data: {
      type: 'component',
      component,
    },
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`relative group ${isDragging ? 'opacity-50' : ''}`}
    >
      <div
        className={`border-2 border-dashed rounded-lg p-2 transition-all ${
          isSelected 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-transparent hover:border-gray-300'
        }`}
        onClick={() => onSelect(component.id)}
      >
        {/* Component Controls */}
        <div className={`absolute top-0 right-0 -mt-2 -mr-2 flex space-x-1 ${
          isSelected || isDragging ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
        } transition-opacity`}>
          <Button
            size="sm"
            variant="secondary"
            className="w-8 h-8 p-0"
            {...attributes}
            {...listeners}
          >
            <Move className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="destructive"
            className="w-8 h-8 p-0"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(component.id);
            }}
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>

        {/* Component Content */}
        <RenderEmailComponent
          component={component}
          onUpdate={(updates) => onUpdate(component.id, updates)}
        />
      </div>
    </div>
  );
}