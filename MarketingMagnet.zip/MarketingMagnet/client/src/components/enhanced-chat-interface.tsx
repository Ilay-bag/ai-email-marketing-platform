import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  MessageCircle, 
  Send, 
  Sparkles, 
  RefreshCw, 
  Trash2, 
  Bot, 
  User, 
  Settings, 
  Copy,
  Download,
  Eye,
  Edit,
  Zap,
  ExternalLink
} from "lucide-react";

interface ChatMessage {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
  campaignId?: number;
}

interface ChatResponse {
  content: any;
  campaign: any;
  email: any;
  message: string;
}

const campaignTypes = [
  { value: "welcome", label: "Welcome Series", color: "bg-blue-100 text-blue-700" },
  { value: "abandoned_cart", label: "Abandoned Cart", color: "bg-orange-100 text-orange-700" },
  { value: "promo", label: "Promotional", color: "bg-purple-100 text-purple-700" },
  { value: "product_launch", label: "Product Launch", color: "bg-green-100 text-green-700" },
  { value: "re_engagement", label: "Re-engagement", color: "bg-yellow-100 text-yellow-700" }
];

const suggestedPrompts = [
  "Create a welcome email for new subscribers with a 20% discount offer",
  "Design a product launch email for a new tech gadget",
  "Build an abandoned cart recovery email with urgency messaging",
  "Create a re-engagement email for inactive subscribers",
  "Design a promotional email for a seasonal sale"
];

interface EnhancedChatInterfaceProps {
  onCampaignGenerated?: (content: any, campaign?: any, email?: any) => void;
  onSaveCampaign?: (content: any) => void;
  initialEditingContext?: {
    type: "email_edit" | "flow_edit";
    id: number;
    name?: string;
  };
}

export function EnhancedChatInterface({ onCampaignGenerated, onSaveCampaign, initialEditingContext }: EnhancedChatInterfaceProps = {}) {
  const [prompt, setPrompt] = useState("");
  const [campaignType, setCampaignType] = useState("promo");
  const [creationType, setCreationType] = useState<"single" | "campaign" | "flow">("single"); // Enhanced creation types
  const [editingContext, setEditingContext] = useState<{
    type: "email_edit" | "flow_edit" | null;
    id: number | null;
    name?: string;
  }>({ type: null, id: null });

  // Set initial editing context if provided
  useEffect(() => {
    if (initialEditingContext) {
      setEditingContext(initialEditingContext);
      setCreationType(initialEditingContext.type === "email_edit" ? "single" : "flow");
    }
  }, [initialEditingContext]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [lastGeneratedContent, setLastGeneratedContent] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const userId = 1; // Demo user ID

  // Query chat messages
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["/api/chat/messages", userId],
    queryFn: () => apiRequest('GET', `/api/chat/messages/${userId}`)
  });

  // Generate campaign mutation
  const generateCampaign = useMutation({
    mutationFn: async (data: { prompt: string; userId: number; campaignType: string; creationType: "single" | "campaign" | "flow"; editingContext?: any }) => {
      return apiRequest('POST', '/api/chat/generate', data);
    },
    onSuccess: (data: ChatResponse) => {
      setLastGeneratedContent(data);
      setIsGenerating(false);
      setPrompt("");

      // Call the callback if provided
      if (onCampaignGenerated) {
        onCampaignGenerated(data.content, data.campaign, data.email);
      }

      toast({
        title: "Campaign Generated!",
        description: `Created "${data.campaign?.title || 'campaign'}" successfully.`
      });
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", userId] });
    },
    onError: (error: any) => {
      setIsGenerating(false);
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate campaign",
        variant: "destructive"
      });
    }
  });

  // Reset chat mutation
  const resetChat = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/chat/reset', { userId });
    },
    onSuccess: () => {
      setLastGeneratedContent(null);
      toast({
        title: "Chat Reset",
        description: "Chat history cleared successfully."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages", userId] });
    },
    onError: (error: any) => {
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to reset chat",
        variant: "destructive"
      });
    }
  });

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsGenerating(true);
    generateCampaign.mutate({
      prompt: prompt.trim(),
      userId,
      campaignType,
      creationType,
      editingContext: editingContext.type ? {
        type: editingContext.type,
        emailId: editingContext.type === "email_edit" ? editingContext.id : undefined,
        flowId: editingContext.type === "flow_edit" ? editingContext.id : undefined
      } : null
    });
  };

  const handleReset = () => {
    resetChat.mutate();
  };

  const getSelectedCampaignType = () => {
    return campaignTypes.find(type => type.value === campaignType);
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const suggestedPrompts = [
    "Create a welcome email series for new subscribers",
    "Design an abandoned cart recovery campaign",
    "Build a product launch announcement email",
    "Create a re-engagement email for inactive users",
    "Design a promotional email for a seasonal sale"
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <Card className="flex-shrink-0 mb-4">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-blue-600" />
              AI Campaign Generator
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleReset}
                disabled={resetChat.isPending}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Reset Chat
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-4">
            {/* Creation Type Selection */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                What do you want to create?
              </label>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant={creationType === "single" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setCreationType("single");
                    setEditingContext({ type: null, id: null });
                  }}
                  className="flex-1"
                >
                  Single Email
                </Button>
                <Button
                  variant={creationType === "campaign" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setCreationType("campaign");
                    setEditingContext({ type: null, id: null });
                  }}
                  className="flex-1"
                >
                  Campaign Flow
                </Button>
                <Button
                  variant={creationType === "flow" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setCreationType("flow");
                    setEditingContext({ type: null, id: null });
                  }}
                  className="flex-1"
                >
                  Visual Flow
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {creationType === "single" 
                  ? "Creates a standalone email template that goes to your library"
                  : creationType === "campaign"
                  ? "Creates a multi-step email sequence with triggers and flows"
                  : "Creates a visual flow builder with connected nodes and actions"
                }
              </p>
            </div>

            {/* Editing Context Display */}
            {editingContext.type && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Edit className="h-4 w-4 text-amber-600" />
                  <span className="font-medium text-amber-800">
                    {editingContext.type === "email_edit" ? "Editing Email" : "Editing Flow"}
                  </span>
                </div>
                <p className="text-sm text-amber-700">
                  {editingContext.name || `ID: ${editingContext.id}`}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2"
                  onClick={() => setEditingContext({ type: null, id: null })}
                >
                  Cancel Editing
                </Button>
              </div>
            )}

            {/* Campaign Type Selection - Only show for campaigns */}
            {creationType === "campaign" && !editingContext.type && (
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Campaign Type
                  </label>
                  <Select value={campaignType} onValueChange={setCampaignType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {campaignTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-shrink-0">
                  <Badge className={getSelectedCampaignType()?.color}>
                    {getSelectedCampaignType()?.label}
                  </Badge>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Chat Messages */}
      <Card className="flex-1 flex flex-col">
        <CardHeader className="flex-shrink-0 pb-3">
          <CardTitle className="flex items-center justify-between">
            <span>Chat History</span>
            <span className="text-sm text-gray-500 font-normal">
              {messages.length} message{messages.length !== 1 ? 's' : ''}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col pt-0">
          <ScrollArea className="flex-1 pr-4">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-gray-200 rounded-full animate-pulse"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                      <div className="h-3 bg-gray-200 rounded w-3/4 animate-pulse"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : messages.length === 0 ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center py-8">
                  <MessageCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 mb-2">
                    Start Your First Campaign
                  </h3>
                  <p className="text-gray-500 mb-6">
                    Describe your email marketing campaign and I'll create it for you.
                  </p>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600 font-medium">Try these prompts:</p>
                    <div className="space-y-1">
                      {suggestedPrompts.slice(0, 3).map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => setPrompt(suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message: ChatMessage) => (
                  <div key={message.id} className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'user' 
                        ? 'bg-blue-100 text-blue-600' 
                        : 'bg-green-100 text-green-600'
                    }`}>
                      {message.role === 'user' ? (
                        <User className="h-4 w-4" />
                      ) : (
                        <Bot className="h-4 w-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">
                          {message.role === 'user' ? 'You' : 'AI Assistant'}
                        </span>
                        <span className="text-xs text-gray-500">
                          {formatTime(message.createdAt)}
                        </span>
                      </div>
                      <div className="text-sm text-gray-700 whitespace-pre-wrap">
                        {message.content}
                      </div>
                    </div>
                  </div>
                ))}
                {isGenerating && (
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">AI Assistant</span>
                        <span className="text-xs text-gray-500">now</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Sparkles className="h-4 w-4 animate-pulse" />
                        Generating your campaign...
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Input Form */}
      <Card className="flex-shrink-0 mt-4">
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe your email campaign... (e.g., 'Create a welcome email for new subscribers with a 20% discount offer')"
                className="min-h-[100px]"
                disabled={isGenerating}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  type="submit"
                  disabled={!prompt.trim() || isGenerating}
                  className="flex items-center gap-2"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="h-4 w-4 animate-pulse" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Generate Campaign
                    </>
                  )}
                </Button>
              </div>
              <div className="text-xs text-gray-500">
                Press Enter to send • Shift+Enter for new line
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Quick Actions for Generated Content */}
      {lastGeneratedContent && (
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-blue-500" />
              Generated Content
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="font-medium">{lastGeneratedContent.content?.subject}</p>
                <p className="text-sm text-gray-500">
                  Campaign: {lastGeneratedContent.campaign?.title || "Untitled Campaign"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    // Create email builder data structure for modular components
                    const emailBuilderData = {
                      subject: lastGeneratedContent.content?.subject || '',
                      html: lastGeneratedContent.content.htmlContent || '',
                      json: lastGeneratedContent.content,
                      components: lastGeneratedContent.components || [],
                      globalStyles: lastGeneratedContent.globalStyles || {
                        backgroundColor: '#ffffff',
                        fontFamily: 'Arial, Helvetica, sans-serif',
                        fontSize: '16px',
                        color: '#374151',
                        maxWidth: '600px',
                      }
                    };

                    // Store the modular email data in localStorage
                    localStorage.setItem('emailBuilderData', JSON.stringify(emailBuilderData));

                    // Open email builder with modular components
                    window.open(`/email-builder?emailId=${lastGeneratedContent.email.id}`, '_blank');
                  }}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
                {lastGeneratedContent.campaign && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(`/campaigns/${lastGeneratedContent.campaign.id}/edit`, '_blank')}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    View Campaign
                  </Button>
                )}
              </div>
            </div>

            {/* HTML Email Preview */}
            {lastGeneratedContent.content && lastGeneratedContent.content.htmlContent && (
              <div className="border rounded-lg p-4 bg-gray-50">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Email Preview</h4>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      const htmlWindow = window.open('', '_blank');
                      htmlWindow?.document.write(lastGeneratedContent.content.htmlContent);
                      htmlWindow?.document.close();
                    }}
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Open Full
                  </Button>
                </div>
                <div className="max-h-96 overflow-y-auto border border-gray-200 rounded bg-white">
                  <iframe
                    srcDoc={lastGeneratedContent.content.htmlContent}
                    className="w-full h-80"
                    title="Email Preview"
                    sandbox="allow-same-origin"
                  />
                </div>
              </div>
            )}

            {/* Email Content Summary */}
            {lastGeneratedContent.content && (
              <div className="border rounded-lg p-4 bg-blue-50">
                <h4 className="text-sm font-medium mb-2">Email Details</h4>
                <div className="space-y-2 text-sm">
                  <div><strong>Subject:</strong> {lastGeneratedContent.content.subject}</div>
                  {lastGeneratedContent.content.preheader && (
                    <div><strong>Preheader:</strong> {lastGeneratedContent.content.preheader}</div>
                  )}
                  {lastGeneratedContent.content.header && (
                    <div><strong>Header:</strong> {
                      typeof lastGeneratedContent.content.header === 'string' 
                        ? lastGeneratedContent.content.header 
                        : lastGeneratedContent.content.header.title || 'Header configured'
                    }</div>
                  )}
                  {(lastGeneratedContent.content.callToAction || lastGeneratedContent.content.cta) && (
                    <div><strong>Call to Action:</strong> {
                      (() => {
                        const cta = lastGeneratedContent.content.callToAction || lastGeneratedContent.content.cta;
                        return typeof cta === 'string' ? cta : cta.text || 'CTA configured';
                      })()
                    }</div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}