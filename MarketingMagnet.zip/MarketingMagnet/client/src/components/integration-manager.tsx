import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ExternalLink, Trash2, CheckCircle, AlertCircle } from "lucide-react";
import { Mail, ShoppingCart, Globe, Zap, Building } from "lucide-react";

interface Integration {
  id: number;
  provider: string;
  accountEmail?: string;
  accountId?: string;
  isActive: boolean;
  connectedAt: string;
  expiresAt?: string;
}

interface IntegrationManagerProps {
  userId: number;
}

const platformConfig = {
  mailchimp: {
    name: "Mailchimp",
    icon: Mail,
    color: "bg-yellow-500",
    authType: "oauth",
    description: "Email marketing platform"
  },
  klaviyo: {
    name: "Klaviyo",
    icon: Zap,
    color: "bg-purple-500",
    authType: "oauth",
    description: "Customer data platform"
  },
  shopify: {
    name: "Shopify",
    icon: ShoppingCart,
    color: "bg-green-500",
    authType: "oauth",
    description: "E-commerce platform"
  },
  wix: {
    name: "Wix",
    icon: Building,
    color: "bg-blue-500",
    authType: "oauth",
    description: "Website builder"
  },
  wordpress: {
    name: "WordPress",
    icon: Globe,
    color: "bg-blue-600",
    authType: "oauth",
    description: "Content management system"
  }
};

export function IntegrationManager({ userId }: IntegrationManagerProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: integrations, isLoading } = useQuery({
    queryKey: ['/api/integrations/user', userId],
    queryFn: () => apiRequest('GET', `/api/integrations/user/${userId}`)
  });



  const disconnectMutation = useMutation({
    mutationFn: async (integrationId: number) => {
      return apiRequest('DELETE', `/api/integrations/${integrationId}`);
    },
    onSuccess: () => {
      toast({
        title: "Integration disconnected",
        description: "Successfully disconnected integration"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/integrations/user', userId] });
    },
    onError: (error: any) => {
      toast({
        title: "Disconnection failed",
        description: error.message || "Failed to disconnect integration",
        variant: "destructive"
      });
    }
  });

  const handleOAuthConnect = async (platform: string) => {
    setIsConnecting(true);
    
    // Check if OAuth is properly configured for this platform
    try {
      const response = await fetch(`/api/auth/${platform}/status`);
      if (!response.ok) {
        throw new Error('OAuth not configured');
      }
      
      const authUrl = `/api/auth/${platform}?userId=${userId}`;
      window.location.href = authUrl;
    } catch (error) {
      setIsConnecting(false);
      toast({
        title: "Configuration Required",
        description: `${platform} OAuth integration requires API keys to be configured in settings. Please contact your administrator.`,
        variant: "destructive"
      });
    }
  };



  const getConnectedIntegration = (platform: string) => {
    return Array.isArray(integrations) ? integrations.find((integration: Integration) => 
      integration.provider === platform && integration.isActive
    ) : undefined;
  };

  const isTokenExpired = (integration: Integration) => {
    if (!integration.expiresAt) return false;
    return new Date() > new Date(integration.expiresAt);
  };

  // Check URL params for OAuth callback results
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const integrationResult = urlParams.get('integration');
    const platform = urlParams.get('platform');
    const error = urlParams.get('error');

    if (integrationResult === 'success' && platform) {
      toast({
        title: "Integration connected",
        description: `Successfully connected to ${platformConfig[platform as keyof typeof platformConfig]?.name}`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/integrations/user', userId] });
    } else if (integrationResult === 'error' && platform) {
      toast({
        title: "Connection failed",
        description: error || "Failed to connect integration",
        variant: "destructive"
      });
    }

    // Clean up URL params
    if (integrationResult) {
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast, queryClient, userId]);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-32 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-lg" />
        <div className="h-32 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-lg" />
        <div className="h-32 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Integrations</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Connect your marketing tools to export campaigns
          </p>
        </div>
      </div>

      <div className="grid gap-4">
        {Object.entries(platformConfig).map(([platform, config]) => {
          const connectedIntegration = getConnectedIntegration(platform);
          const isConnected = !!connectedIntegration;
          const isExpired = connectedIntegration ? isTokenExpired(connectedIntegration) : false;

          return (
            <Card key={platform} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${config.color} text-white`}>
                      <config.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{config.name}</CardTitle>
                      <CardDescription>{config.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isConnected && !isExpired && (
                      <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Connected
                      </Badge>
                    )}
                    {isExpired && (
                      <Badge variant="destructive">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        Expired
                      </Badge>
                    )}
                    {!isConnected && (
                      <Badge variant="outline">
                        Not connected
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isConnected && connectedIntegration ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Account:</span>
                      <span>{connectedIntegration.accountEmail || 'Connected'}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Connected:</span>
                      <span>{new Date(connectedIntegration.connectedAt).toLocaleDateString()}</span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-end gap-2">
                      {(isExpired || config.authType === 'oauth') && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOAuthConnect(platform)}
                          disabled={isConnecting}
                        >
                          <ExternalLink className="h-4 w-4 mr-2" />
                          {isExpired ? 'Reconnect' : 'Refresh'}
                        </Button>
                      )}
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => disconnectMutation.mutate(connectedIntegration.id)}
                        disabled={disconnectMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Disconnect
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Connect your {config.name} account to export campaigns
                    </p>
                    <Button
                      onClick={() => handleOAuthConnect(platform)}
                      disabled={isConnecting}
                      className="w-full"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Connect to {config.name}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}