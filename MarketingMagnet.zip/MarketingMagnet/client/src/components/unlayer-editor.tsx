import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Eye, 
  Code, 
  Download, 
  Save, 
  Monitor, 
  Smartphone,
  Settings,
  Mail,
  ExternalLink
} from "lucide-react";

interface UnlayerEditorProps {
  initialDesign?: any;
  onSave: (design: any, html: string) => void;
  onPreview: (html: string) => void;
  className?: string;
}

declare global {
  interface Window {
    unlayer: any;
  }
}

export function UnlayerEditor({ initialDesign, onSave, onPreview, className = "" }: UnlayerEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [currentDesign, setCurrentDesign] = useState(initialDesign);
  const [previewMode, setPreviewMode] = useState<"desktop" | "mobile">("desktop");
  const [exportedHtml, setExportedHtml] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    // Load Unlayer script
    const script = document.createElement('script');
    script.src = 'https://editor.unlayer.com/embed.js';
    script.async = true;
    script.onload = () => {
      initializeEditor();
    };
    document.head.appendChild(script);

    return () => {
      // Cleanup
      if (window.unlayer) {
        window.unlayer.destroy();
      }
    };
  }, []);

  const initializeEditor = () => {
    if (!editorRef.current) return;

    window.unlayer.init({
      id: 'editor',
      projectId: process.env.VITE_UNLAYER_PROJECT_ID || 'demo',
      displayMode: 'email',
      appearance: {
        theme: 'modern_light',
        panels: {
          tools: {
            dock: 'left'
          }
        }
      },
      features: {
        preview: true,
        export: true,
        import: true,
        history: true,
        stockImages: true,
        imageEditor: true,
        undoRedo: true,
        spellCheck: true,
        textEditor: {
          spellCheck: true,
          cleanPaste: true
        }
      },
      tools: {
        text: {
          enabled: true,
          properties: {
            fontSize: {
              value: '14px',
              options: ['12px', '13px', '14px', '15px', '16px', '18px', '20px', '24px', '28px', '32px', '36px', '48px']
            },
            fontFamily: {
              value: 'arial,helvetica,sans-serif',
              options: [
                { label: 'Arial', value: 'arial,helvetica,sans-serif' },
                { label: 'Georgia', value: 'georgia,times,serif' },
                { label: 'Helvetica', value: 'helvetica,arial,sans-serif' },
                { label: 'Times New Roman', value: 'times new roman,times,serif' },
                { label: 'Verdana', value: 'verdana,geneva,sans-serif' }
              ]
            },
            textAlign: {
              value: 'left',
              options: ['left', 'center', 'right', 'justify']
            },
            lineHeight: {
              value: '1.5',
              options: ['1', '1.2', '1.4', '1.5', '1.6', '1.8', '2', '2.5', '3']
            }
          }
        },
        image: {
          enabled: true,
          properties: {
            src: {
              value: ''
            },
            alt: {
              value: ''
            },
            title: {
              value: ''
            },
            width: {
              value: '100%'
            },
            height: {
              value: 'auto'
            }
          }
        },
        button: {
          enabled: true,
          properties: {
            text: {
              value: 'Click Here'
            },
            href: {
              value: ''
            },
            target: {
              value: '_blank'
            },
            backgroundColor: {
              value: '#3AAEE0'
            },
            textColor: {
              value: '#FFFFFF'
            },
            borderRadius: {
              value: '4px'
            },
            padding: {
              value: '15px 30px'
            }
          }
        },
        divider: {
          enabled: true,
          properties: {
            borderColor: {
              value: '#CCCCCC'
            },
            borderWidth: {
              value: '1px'
            },
            borderStyle: {
              value: 'solid'
            }
          }
        },
        html: {
          enabled: true
        },
        video: {
          enabled: true,
          properties: {
            src: {
              value: ''
            },
            thumbnailSrc: {
              value: ''
            },
            autoplay: {
              value: false
            },
            controls: {
              value: true
            }
          }
        },
        social: {
          enabled: true,
          properties: {
            icons: {
              value: [
                {
                  type: 'facebook',
                  url: 'https://www.facebook.com/'
                },
                {
                  type: 'twitter',
                  url: 'https://twitter.com/'
                },
                {
                  type: 'instagram',
                  url: 'https://www.instagram.com/'
                },
                {
                  type: 'linkedin',
                  url: 'https://www.linkedin.com/'
                }
              ]
            },
            iconSize: {
              value: '32px'
            },
            iconSpacing: {
              value: '10px'
            }
          }
        },
        spacer: {
          enabled: true,
          properties: {
            height: {
              value: '20px'
            }
          }
        }
      },
      mergeTags: {
        first_name: {
          name: 'First Name',
          value: '{{first_name}}'
        },
        last_name: {
          name: 'Last Name',
          value: '{{last_name}}'
        },
        email: {
          name: 'Email',
          value: '{{email}}'
        },
        company: {
          name: 'Company',
          value: '{{company}}'
        },
        product_name: {
          name: 'Product Name',
          value: '{{product_name}}'
        },
        product_price: {
          name: 'Product Price',
          value: '{{product_price}}'
        },
        coupon_code: {
          name: 'Coupon Code',
          value: '{{coupon_code}}'
        }
      },
      callbacks: {
        onReady: () => {
          setIsLoaded(true);
          if (initialDesign) {
            window.unlayer.loadDesign(initialDesign);
          }
        },
        onDesignLoad: (data: any) => {
          console.log('Design loaded:', data);
          setCurrentDesign(data);
        },
        onDesignUpdate: (data: any) => {
          setCurrentDesign(data);
        }
      }
    });
  };

  const handleSave = () => {
    window.unlayer.saveDesign((design: any) => {
      window.unlayer.exportHtml((data: any) => {
        const { html } = data;
        setExportedHtml(html);
        onSave(design, html);
        toast({
          title: "Design Saved",
          description: "Your email design has been saved successfully!"
        });
      });
    });
  };

  const handlePreview = () => {
    window.unlayer.exportHtml((data: any) => {
      const { html } = data;
      setExportedHtml(html);
      onPreview(html);
    });
  };

  const handleExport = () => {
    window.unlayer.exportHtml((data: any) => {
      const { html } = data;
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'email-design.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export Complete",
        description: "HTML file downloaded successfully!"
      });
    });
  };

  const handlePreviewMode = (mode: "desktop" | "mobile") => {
    setPreviewMode(mode);
    if (window.unlayer) {
      window.unlayer.setDisplayMode(mode);
    }
  };

  if (!isLoaded) {
    return (
      <div className={`flex flex-col items-center justify-center h-96 ${className}`}>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
        <p className="text-sm text-gray-600">Loading Unlayer Editor...</p>
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between p-4 border-b bg-white">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-purple-50 text-purple-700">
            <Mail className="h-3 w-3 mr-1" />
            Klaviyo + Unlayer
          </Badge>
          <Separator orientation="vertical" className="h-4" />
          <span className="text-sm text-gray-600">Visual Email Editor</span>
        </div>
        
        <div className="flex items-center gap-2">
          {/* Preview Mode Toggle */}
          <div className="flex items-center gap-1 border rounded-lg p-1">
            <Button
              variant={previewMode === "desktop" ? "default" : "ghost"}
              size="sm"
              onClick={() => handlePreviewMode("desktop")}
            >
              <Monitor className="h-4 w-4" />
            </Button>
            <Button
              variant={previewMode === "mobile" ? "default" : "ghost"}
              size="sm"
              onClick={() => handlePreviewMode("mobile")}
            >
              <Smartphone className="h-4 w-4" />
            </Button>
          </div>
          
          <Separator orientation="vertical" className="h-4" />
          
          {/* Action Buttons */}
          <Button variant="outline" size="sm" onClick={handlePreview}>
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button size="sm" onClick={handleSave}>
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
        </div>
      </div>

      {/* Editor Container */}
      <div className="flex-1 relative">
        <div ref={editorRef} id="editor" className="h-full w-full" />
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between p-2 border-t bg-gray-50 text-xs text-gray-600">
        <div className="flex items-center gap-4">
          <span>Responsive Design: ✓</span>
          <span>Klaviyo Compatible: ✓</span>
          <span>Personalization: ✓</span>
        </div>
        <div className="flex items-center gap-2">
          <ExternalLink className="h-3 w-3" />
          <span>Powered by Unlayer</span>
        </div>
      </div>
    </div>
  );
}